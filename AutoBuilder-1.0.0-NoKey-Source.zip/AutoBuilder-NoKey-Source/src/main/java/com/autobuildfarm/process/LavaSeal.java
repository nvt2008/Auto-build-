package com.autobuildfarm.process;

import com.autobuildfarm.plan.FinishTask;

public final class LavaSeal {
   private LavaSeal() {
   }

   public static boolean needsSealCheck(FinishProcess.Mode var0, FinishTask var1) {
      return var1 != null && var1.type() == FinishTask.Type.LAVA_SOURCE ? true : var0 == FinishProcess.Mode.OPPORTUNISTIC;
   }
}
