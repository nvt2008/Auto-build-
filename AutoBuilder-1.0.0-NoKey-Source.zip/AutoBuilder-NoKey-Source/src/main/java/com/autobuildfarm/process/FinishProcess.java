package com.autobuildfarm.process;

import baritone.api.BaritoneAPI;
import baritone.api.IBaritone;
import baritone.api.pathing.goals.Goal;
import baritone.api.pathing.goals.GoalBlock;
import baritone.api.pathing.goals.GoalNear;
import baritone.api.pathing.goals.GoalRunAway;
import baritone.api.process.IBaritoneProcess;
import baritone.api.process.PathingCommand;
import baritone.api.process.PathingCommandType;
import baritone.api.utils.BetterBlockPos;
import baritone.api.utils.IPlayerContext;
import baritone.api.utils.RayTraceUtils;
import baritone.api.utils.Rotation;
import baritone.api.utils.RotationUtils;
import baritone.api.utils.input.Input;
import com.autobuildfarm.AutoBuildFarm;
import com.autobuildfarm.AutoRejoinHandler;
import com.autobuildfarm.DebugLog;
import com.autobuildfarm.eat.AutoEatController;
import com.autobuildfarm.order.BucketDisposal;
import com.autobuildfarm.order.RestockController;
import com.autobuildfarm.place.InventoryHelper;
import com.autobuildfarm.plan.FinishTask;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.Map.Entry;
import java.util.function.Consumer;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1922;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2269;
import net.minecraft.class_2304;
import net.minecraft.class_2323;
import net.minecraft.class_2338;
import net.minecraft.class_2349;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2397;
import net.minecraft.class_2401;
import net.minecraft.class_2428;
import net.minecraft.class_243;
import net.minecraft.class_2533;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_746;
import net.minecraft.class_239.class_240;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;

public final class FinishProcess implements IBaritoneProcess {
   public static double REACH = 3.8;
   private static final int MAX_ATTEMPTS = 24;
   private static final int MAX_TRAVEL_TICKS = 200;
   private static final int MAX_PROBES_PER_TICK = 6;
   private static final int CHAT_BUDGET = 24;
   private static final int SNOOZE_TICKS = 40;
   private static final int NO_HOTBAR_SNOOZE_TICKS = 1200;
   private FinishTask dropped;
   private int reEngageRuns;
   private static final int UNPLACEABLE_LIMIT = 200;
   private int consecutiveFluidRollbacks = 0;
   private final Map<class_2338, Long> recentFluidPlacements = new HashMap<>();
   private final Map<class_2338, FinishTask> recentFluidTasks = new HashMap<>();
   private static final class_2350[] SUPPORT_ORDER = new class_2350[]{
      class_2350.field_11033, class_2350.field_11043, class_2350.field_11035, class_2350.field_11039, class_2350.field_11034, class_2350.field_11036
   };
   private static final class_2350[] SCAFFOLD_ORDER_FLUID = new class_2350[]{
      class_2350.field_11043, class_2350.field_11035, class_2350.field_11039, class_2350.field_11034, class_2350.field_11033, class_2350.field_11036
   };
   private static final class_2350[] SCAFFOLD_ORDER_WATERLOG = new class_2350[]{
      class_2350.field_11033, class_2350.field_11043, class_2350.field_11035, class_2350.field_11039, class_2350.field_11034, class_2350.field_11036
   };
   public static final class_1792[] SCAFFOLD_ITEMS = new class_1792[]{
      class_1802.field_8831,
      class_1802.field_8460,
      class_1802.field_28655,
      class_1802.field_8328,
      class_1802.field_20412,
      class_1802.field_29025,
      class_1802.field_20391,
      class_1802.field_20407,
      class_1802.field_20401,
      class_1802.field_20394,
      class_1802.field_27021,
      class_1802.field_28866,
      class_1802.field_23843,
      class_1802.field_8118
   };
   private static final int SCAFFOLD_BREAK_LIMIT = 200;
   private static final int HOLD_BUDGET = 200;
   private static final int DORMANT_TICKS = 300;
   private static final int LAYER_IDLE_LIMIT = 400;
   public static final int NO_CEILING = Integer.MAX_VALUE;
   private static final String[] SKIP_REASONS = new String[]{
      "out of reach", "snoozed", "lava would burn something", "would leak", "not ready", "no line of sight", "above this layer"
   };
   private final IBaritone baritone;
   private final IPlayerContext ctx;
   private final Deque<FinishTask> queue = new ArrayDeque<>();
   private FinishProcess.Mode mode = FinishProcess.Mode.OFF;
   private int ceiling = Integer.MAX_VALUE;
   private boolean suspended;
   private boolean clickHeld;
   private boolean breakHeld;
   private int cooldown;
   private int attempts;
   private int travelTicks;
   private int calcFailures;
   private int unplaceableTicks;
   private int layerIdleTicks;
   private int standUpTicks;
   private int unsettledTicks;
   private int stallTicks;
   private int stallReports;
   private int holdTicks;
   private int dormantUntil;
   private int tickCounter;
   private FinishTask engaged;
   private int engagedTicks;
   private final Set<class_2338> queuedTaskPositions = new HashSet<>();
   private final Set<class_2338> abandonedTaskPositions = new HashSet<>();
   private int[] skips;
   private FinishTask travelTarget;
   private class_2338 scaffoldPos;
   private FinishTask scaffoldFor;
   private int scaffoldBreakTicks;
   private final Map<class_2338, Integer> snoozeUntil = new HashMap<>();
   private final Map<class_2338, Integer> pathFailures = new HashMap<>();
   public static final int LEAF_WATERLOG_MIN_TICKS = 20;
   private final Map<class_2338, Integer> leafSeenTicks = new HashMap<>();
   private int previousSelectedSlot = -1;
   private FinishTask verifyingTask = null;
   private FinishProcess.Aim verifyingAim = null;
   private int verifyingTicks = 0;
   private int verifyingSettledTicks = 0;
   private int completed;
   private int chatted;
   private Consumer<FinishProcess.Result> onFinished;
   private final List<FinishTask> abandoned = new ArrayList<>();

   public FinishProcess(IBaritone iBaritone) {
      this.baritone = iBaritone;
      this.ctx = iBaritone.getPlayerContext();
   }

   public void start(List<FinishTask> list, Consumer<FinishProcess.Result> consumer) {
      this.queue.clear();
      this.queuedTaskPositions.clear();
      this.abandoned.clear();
      this.abandonedTaskPositions.clear();
      this.queue.addAll(list);

      for (FinishTask var4 : list) {
         this.queuedTaskPositions.add(var4.pos());
      }

      this.onFinished = consumer;
      this.attempts = 0;
      this.cooldown = 0;
      this.travelTicks = 0;
      this.calcFailures = 0;
      this.unplaceableTicks = 0;
      this.standUpTicks = 0;
      this.unsettledTicks = 0;
      this.stallTicks = 0;
      this.stallReports = 0;
      this.holdTicks = 0;
      this.dormantUntil = 0;
      this.tickCounter = 0;
      this.snoozeUntil.clear();
      this.pathFailures.clear();
      this.leafSeenTicks.clear();
      this.clearEngagement();
      this.travelTarget = null;
      this.forgetScaffold();
      this.completed = 0;
      this.chatted = 0;
      this.suspended = false;
      this.mode = FinishProcess.Mode.OPPORTUNISTIC;
   }

   public void addTasks(List<FinishTask> list) {
      for (FinishTask var3 : list) {
         if (this.ctx != null && this.ctx.world() != null && var3.satisfied(this.ctx.world())) {
            this.abandoned.remove(var3);
            this.abandonedTaskPositions.remove(var3.pos());
         } else if (!this.queuedTaskPositions.contains(var3.pos()) && !this.abandonedTaskPositions.contains(var3.pos())) {
            this.snoozeUntil.remove(var3.pos());
            this.queue.addLast(var3);
            this.queuedTaskPositions.add(var3.pos());
         }
      }
   }

   public void unSnooze(class_2338 arg) {
      this.snoozeUntil.remove(arg);
   }

   public void markLeafSeen(class_2338 arg) {
      this.leafSeenTicks.putIfAbsent(arg, this.tickCounter);
   }

   public boolean isLeafMatured(class_2338 arg) {
      if (this.ctx != null && this.ctx.world() != null) {
         class_2680 var2 = this.ctx.world().method_8320(arg);
         if (!(var2.method_26204() instanceof class_2397)) {
            this.leafSeenTicks.remove(arg);
            return false;
         } else {
            Integer var3 = this.leafSeenTicks.get(arg);
            if (var3 == null) {
               this.leafSeenTicks.put(arg, this.tickCounter);
               return false;
            } else {
               return this.tickCounter - var3 >= 20;
            }
         }
      } else {
         return false;
      }
   }

   public void retryAbandoned() {
      for (FinishTask var2 : this.abandoned) {
         if (!this.queuedTaskPositions.contains(var2.pos())) {
            this.queue.addLast(var2);
            this.queuedTaskPositions.add(var2.pos());
         }
      }

      this.abandoned.clear();
      this.abandonedTaskPositions.clear();
   }

   public void retrySpecificTasks(List<FinishTask> list) {
      for (FinishTask var3 : list) {
         if (this.ctx != null && this.ctx.world() != null && var3.satisfied(this.ctx.world())) {
            this.abandoned.remove(var3);
            this.abandonedTaskPositions.remove(var3.pos());
         } else {
            this.abandoned.remove(var3);
            this.abandonedTaskPositions.remove(var3.pos());
            this.snoozeUntil.remove(var3.pos());
            if (!this.queuedTaskPositions.contains(var3.pos())) {
               this.queue.addLast(var3);
               this.queuedTaskPositions.add(var3.pos());
            }
         }
      }
   }

   public void beginSweep() {
      this.ceiling = Integer.MAX_VALUE;
      if (this.queue.isEmpty()) {
         this.mode = FinishProcess.Mode.OFF;
         this.report(null);
      } else {
         this.resetForPass();
         this.mode = FinishProcess.Mode.SWEEP;
      }
   }

   public boolean beginLayerSweep(int i) {
      this.ceiling = i;
      if (!this.queue.isEmpty()) {
         this.resetForPass();
         this.mode = FinishProcess.Mode.LAYER;
      }

      return this.hasDoableWorkAtOrBelow(i);
   }

   private void resetForPass() {
      this.unplaceableTicks = 0;
      this.travelTicks = 0;
      this.calcFailures = 0;
      this.layerIdleTicks = 0;
      this.stallTicks = 0;
      this.stallReports = 0;
      this.snoozeUntil.clear();
      this.pathFailures.clear();
      this.clearEngagement();
      this.verifyingTask = null;
      this.verifyingAim = null;
      this.verifyingTicks = 0;
      this.verifyingSettledTicks = 0;
      this.travelTarget = null;
      this.forgetScaffold();

      try {
         BaritoneAPI.getSettings().allowPlace.value = false;
         BaritoneAPI.getSettings().allowPlaceInFluidsSource.value = false;
         BaritoneAPI.getSettings().allowPlaceInFluidsFlow.value = false;
         BaritoneAPI.getSettings().blockPlacementPenalty.value = 35.0;
      } catch (Throwable var2) {
      }
   }

   public void raiseCeiling(int i) {
      this.ceiling = i;
   }

   public void resumeOpportunistic(int i) {
      this.ceiling = i;
      this.mode = FinishProcess.Mode.OPPORTUNISTIC;
      this.suspended = false;
      this.snoozeUntil.clear();
      this.clearEngagement();
      this.travelTarget = null;
      this.forgetScaffold();
      this.releaseClick();
      this.unplaceableTicks = 0;
      this.travelTicks = 0;
      this.layerIdleTicks = 0;
      this.holdTicks = 0;
      this.dormantUntil = 0;
      this.stallTicks = 0;
      this.stallReports = 0;

      try {
         BaritoneAPI.getSettings().allowPlace.value = true;
         BaritoneAPI.getSettings().allowPlaceInFluidsSource.value = false;
         BaritoneAPI.getSettings().allowPlaceInFluidsFlow.value = false;
         BaritoneAPI.getSettings().blockPlacementPenalty.value = 35.0;
      } catch (Throwable var3) {
      }
   }

   public boolean hasTask(FinishTask.Type type, class_2338 arg) {
      return this.queuedTaskPositions.contains(arg) || this.abandonedTaskPositions.contains(arg);
   }

   public void standDown() {
      this.mode = FinishProcess.Mode.OFF;
      this.snoozeUntil.clear();
      this.leafSeenTicks.clear();
      this.clearEngagement();
      this.travelTarget = null;
      this.forgetScaffold();
      this.releaseClick();
      this.unplaceableTicks = 0;
      this.travelTicks = 0;
      this.layerIdleTicks = 0;
      this.holdTicks = 0;
      this.dormantUntil = 0;
      this.stallTicks = 0;
      this.stallReports = 0;
   }

   public boolean hasWorkAtOrBelow(int i) {
      for (FinishTask var3 : this.queue) {
         if (var3.pos().method_10264() <= i && !var3.satisfied(this.ctx.world())) {
            return true;
         }
      }

      return false;
   }

   public boolean hasDoableWorkAtOrBelow(int i) {
      if (this.ctx != null && this.ctx.world() != null) {
         for (FinishTask var3 : this.queue) {
            if (var3.pos().method_10264() <= i && !var3.satisfied(this.ctx.world()) && var3.ready(this.ctx.world())) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public boolean needsFluidItem(class_1792 arg, int i) {
      if (this.ctx != null && this.ctx.world() != null) {
         for (FinishTask var4 : this.queue) {
            if (var4.pos().method_10264() <= i && !var4.satisfied(this.ctx.world()) && var4.ready(this.ctx.world()) && var4.requiredItem() == arg) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public int highestQueuedY() {
      int var1 = Integer.MIN_VALUE;

      for (FinishTask var3 : this.queue) {
         var1 = Math.max(var1, var3.pos().method_10264());
      }

      return var1 == Integer.MIN_VALUE ? Integer.MAX_VALUE : var1;
   }

   public FinishProcess.Mode mode() {
      return this.mode;
   }

   public int remaining() {
      return this.queue.size();
   }

   public int completed() {
      return this.completed;
   }

   private boolean walking() {
      return this.mode == FinishProcess.Mode.SWEEP || this.mode == FinishProcess.Mode.LAYER;
   }

   public int layerIdleTicks() {
      return this.layerIdleTicks;
   }

   public boolean isActive() {
      return this.mode == FinishProcess.Mode.OPPORTUNISTIC
         ? !this.queue.isEmpty() || this.scaffoldPos != null
         : this.mode != FinishProcess.Mode.OFF && !this.suspended && (!this.queue.isEmpty() || this.scaffoldPos != null);
   }

   public boolean isTemporary() {
      return true;
   }

   public double priority() {
      return 5.0;
   }

   public String displayName0() {
      FinishTask var1 = this.queue.peek();
      return var1 == null ? "Finishing farm" : "Finishing farm (" + this.queue.size() + " left, " + var1 + ")";
   }

   public void onLostControl() {
      this.releaseClick();
      if (this.mode != FinishProcess.Mode.OPPORTUNISTIC) {
         this.suspended = true;
      } else {
         this.clearEngagement();
         this.verifyingTask = null;
         this.verifyingAim = null;
         this.verifyingTicks = 0;
         this.verifyingSettledTicks = 0;
      }
   }

   public boolean isEngaged() {
      return this.engaged != null || this.verifyingTask != null;
   }

   public boolean isVerifying() {
      return this.verifyingTask != null;
   }

   public boolean idleWithWork() {
      return this.suspended && !this.queue.isEmpty() && this.onFinished != null;
   }

   public void rearm() {
      this.suspended = false;
   }

   public void abort(String string) {
      if (this.onFinished != null) {
         this.mode = FinishProcess.Mode.OFF;

         for (FinishTask var3 : this.queue) {
            this.abandonedTaskPositions.add(var3.pos());
         }

         this.abandoned.addAll(this.queue);
         this.queue.clear();
         this.queuedTaskPositions.clear();
         this.report(string);
      }
   }

   public PathingCommand onTick(boolean bl, boolean bl2) {
      class_310 var3 = class_310.method_1551();
      if (var3 == null || var3.field_1755 == null && !RestockController.getInstance().isBusy() && !BucketDisposal.getInstance().isBusy()) {
         if (this.mode == FinishProcess.Mode.OPPORTUNISTIC
            && this.baritone != null
            && this.baritone.getBuilderProcess().isActive()
            && !this.baritone.getBuilderProcess().isPaused()
            && this.baritone.getInputOverrideHandler().isInputForcedDown(Input.CLICK_RIGHT)) {
            this.releaseClick();
            return this.defer();
         }

         if (this.mode == FinishProcess.Mode.OPPORTUNISTIC && this.tickCounter < this.dormantUntil) {
            this.tickCounter++;
            this.dropSatisfied();
            this.releaseClick();
            return this.defer();
         }

         PathingCommand var4 = this.tick(bl, bl2);
         if (this.mode != FinishProcess.Mode.OPPORTUNISTIC) {
            return var4;
         }

         if (var4 == null || var4.commandType == PathingCommandType.DEFER) {
            this.holdTicks = 0;
            return var4;
         }

         if (++this.holdTicks <= 200) {
            return var4;
         }

         this.holdTicks = 0;
         this.dormantUntil = this.tickCounter + 300;
         this.giveUpOnEngaged("it was holding the build up");
         AutoBuildFarm.chat("\u2026 standing down for 15s \u2014 the fluid pass was holding the builder still. The sweep will retry these.");
         return this.defer();
      } else {
         this.releaseClick();
         return this.defer();
      }
   }

   private PathingCommand tick(boolean bl, boolean bl2) {
      this.tickCounter++;
      if (this.cooldown > 0) {
         this.cooldown--;
      }

      if (AutoEatController.getInstance().isEating()) {
         this.releaseClick();
         return this.mode == FinishProcess.Mode.OPPORTUNISTIC ? this.defer() : this.standStill();
      }

      if (this.verifyingTask != null) {
         this.releaseClick();
         class_310 var22 = class_310.method_1551();
         if (this.verifyingAim != null) {
            this.baritone.getLookBehavior().updateTarget(this.verifyingAim.rotation(), true);
            this.ctx.player().method_36456(this.verifyingAim.rotation().getYaw());
            this.ctx.player().method_36457(this.verifyingAim.rotation().getPitch());
         }

         if (this.ctx != null && this.ctx.world() != null && this.verifyingTask.satisfied(this.ctx.world())) {
            if (++this.verifyingSettledTicks >= 4) {
               DebugLog.detail("Placement confirmed in world for " + this.verifyingTask);
               this.consecutiveFluidRollbacks = 0;
               this.dropSatisfied();
               this.verifyingTask = null;
               this.verifyingAim = null;
               this.verifyingTicks = 0;
               this.verifyingSettledTicks = 0;
               this.clearEngagement();
               this.cooldown = 4;
               return this.mode == FinishProcess.Mode.OPPORTUNISTIC ? this.defer() : this.standStill();
            } else {
               return this.standStill();
            }
         } else if (++this.verifyingTicks > 30) {
            DebugLog.detail("Placement confirmation TIMED OUT for " + this.verifyingTask);
            FinishTask var23 = this.verifyingTask;
            this.verifyingTask = null;
            this.verifyingAim = null;
            this.verifyingTicks = 0;
            this.verifyingSettledTicks = 0;
            this.consecutiveFluidRollbacks++;
            AutoBuildFarm.chat(
               "\u00a7e[C\u1ea3nh b\u00e1o] Kh\u00f4ng \u0111\u1eb7t \u0111\u01b0\u1ee3c n\u01b0\u1edbc/lava t\u1ea1i "
                  + var23.pos().method_10263()
                  + ","
                  + var23.pos().method_10264()
                  + ","
                  + var23.pos().method_10260()
                  + " (l\u1ea7n "
                  + this.consecutiveFluidRollbacks
                  + "/5)!"
            );
            if (this.consecutiveFluidRollbacks >= 5) {
               this.consecutiveFluidRollbacks = 0;
               AutoBuildFarm.chat(
                  "\u00a7cKh\u00f4ng \u0111\u1eb7t \u0111\u01b0\u1ee3c n\u01b0\u1edbc/lava sau 5 l\u1ea7n (b\u1ecb m\u00e1y ch\u1ee7 t\u1eeb ch\u1ed1i) -> K\u00edch ho\u1ea1t Auto Rejoin\u2026"
               );
               AutoRejoinHandler.getInstance().trigger("Kh\u00f4ng \u0111\u1eb7t \u0111\u01b0\u1ee3c n\u01b0\u1edbc/lava sau 5 l\u1ea7n");
            }

            this.snoozeUntil.put(var23.pos(), this.tickCounter + 25);
            this.clearEngagement();
            return this.mode == FinishProcess.Mode.OPPORTUNISTIC ? this.defer() : this.standStill();
         } else {
            return this.standStill();
         }
      } else {
         this.dropSatisfied();
         if (!this.recentFluidPlacements.isEmpty() && this.ctx != null && this.ctx.world() != null) {
            long var3 = System.currentTimeMillis();
            Iterator var5 = this.recentFluidPlacements.entrySet().iterator();

            while (var5.hasNext()) {
               Entry var6 = (Entry)var5.next();
               long var7 = var3 - (Long)var6.getValue();
               if (var7 > 8000L) {
                  var5.remove();
                  this.recentFluidTasks.remove(var6.getKey());
               } else {
                  FinishTask var9 = this.recentFluidTasks.get(var6.getKey());
                  if (var9 != null && !var9.satisfied(this.ctx.world())) {
                     var5.remove();
                     this.recentFluidTasks.remove(var6.getKey());
                     this.consecutiveFluidRollbacks++;
                     AutoBuildFarm.chat(
                        "\u00a7e[C\u1ea3nh b\u00e1o] N\u01b0\u1edbc/Lava t\u1ea1i "
                           + ((class_2338)var6.getKey()).method_10263()
                           + ","
                           + ((class_2338)var6.getKey()).method_10264()
                           + ","
                           + ((class_2338)var6.getKey()).method_10260()
                           + " b\u1ecb bi\u1ebfn m\u1ea5t ("
                           + this.consecutiveFluidRollbacks
                           + "/5)!"
                     );
                     if (this.consecutiveFluidRollbacks >= 5) {
                        this.consecutiveFluidRollbacks = 0;
                        AutoBuildFarm.chat(
                           "\u00a7cKh\u00f4ng \u0111\u1eb7t \u0111\u01b0\u1ee3c n\u01b0\u1edbc/lava sau 5 l\u1ea7n (b\u1ecb m\u00e1y ch\u1ee7 ho\u00e0n t\u00e1c) -> K\u00edch ho\u1ea1t Auto Rejoin\u2026"
                        );
                        AutoRejoinHandler.getInstance().trigger("Kh\u00f4ng \u0111\u1eb7t \u0111\u01b0\u1ee3c n\u01b0\u1edbc/lava sau 5 l\u1ea7n");
                     }
                  }
               }
            }
         }

         if (++this.stallTicks % 200 == 0 && this.stallReports < 12 && (this.mode != FinishProcess.Mode.OPPORTUNISTIC || this.engaged != null)) {
            this.stallReports++;
            this.diagnose(bl2);
         }

         if (this.scaffoldPos != null && (this.scaffoldFor == null || !this.queue.contains(this.scaffoldFor))) {
            PathingCommand var20 = this.removeScaffold();
            if (var20 != null) {
               return var20;
            }
         }

         if (this.queue.isEmpty()) {
            this.releaseClick();
            if (this.mode == FinishProcess.Mode.SWEEP) {
               this.mode = FinishProcess.Mode.OFF;
               this.report(null);
            }

            return null;
         } else {
            FinishProcess.Aim var21 = this.engagedAim();
            if (var21 == null) {
               this.releaseClick();
               return this.mode == FinishProcess.Mode.OPPORTUNISTIC ? this.defer() : this.travel(bl);
            }

            this.travelTicks = 0;
            this.calcFailures = 0;
            this.unplaceableTicks = 0;
            if (!this.standUp()) {
               this.releaseClick();
               return this.standStill();
            }

            if (!this.settled(bl2)) {
               this.releaseClick();
               return this.mode == FinishProcess.Mode.OPPORTUNISTIC ? this.defer() : this.standStill();
            }

            if (!this.equipFor(var21)) {
               this.releaseClick();
               if (this.mode == FinishProcess.Mode.OPPORTUNISTIC) {
                  this.giveUpOnEngaged("bucket is not on the hotbar", 1200);
                  return this.defer();
               } else {
                  return this.standStill();
               }
            } else {
               this.baritone.getLookBehavior().updateTarget(var21.rotation(), true);
               this.ctx.player().method_36456(var21.rotation().getYaw());
               this.ctx.player().method_36457(var21.rotation().getPitch());
               class_310 var4 = class_310.method_1551();
               int var24 = var21.task().isFluid() ? 3 : 0;
               class_243 var25 = this.ctx.player().method_18798();
               double var26 = var25.field_1352 * var25.field_1352 + var25.field_1350 * var25.field_1350;
               boolean var27 = !var21.task().isFluid() || var26 < 0.01;
               if (this.cooldown <= 0 && this.onTarget(var21) && this.engagedTicks >= var24 && var27) {
                  if (var4 != null && var4.field_1761 != null && var4.field_1724 != null && var4.field_1687 != null) {
                     class_1792 var10 = var21.task().requiredItem();
                     if (var10 != null
                        && !var4.field_1724.method_6047().method_31574(var10)
                        && (!this.equipFor(var21) || !var4.field_1724.method_6047().method_31574(var10))) {
                        this.releaseClick();
                        this.giveUpOnEngaged("not holding required item: " + var10.method_63680().getString());
                        return this.mode == FinishProcess.Mode.OPPORTUNISTIC ? this.defer() : this.standStill();
                     }

                     if (!var21.task().ready(var4.field_1687)) {
                        this.releaseClick();
                        this.giveUpOnEngaged("host block vanished between picking and clicking");
                        return this.mode == FinishProcess.Mode.OPPORTUNISTIC ? this.defer() : this.standStill();
                     }

                     if (var21.task().type() == FinishTask.Type.WATERLOG && !this.isLeafMatured(var21.task().pos())) {
                        this.releaseClick();
                        this.giveUpOnEngaged("leaf confirmation delay not elapsed yet");
                        return this.mode == FinishProcess.Mode.OPPORTUNISTIC ? this.defer() : this.standStill();
                     }

                     class_239 var11 = this.ctx.objectMouseOver();
                     class_3965 var12 = null;
                     if (!(
                        var11 instanceof class_3965 var13
                           && var11.method_17783() == class_240.field_1332
                           && var13.method_17777().equals(var21.hit())
                           && (var21.side() == null || var13.method_17780() == var21.side())
                     )) {
                        class_239 var14 = RayTraceUtils.rayTraceTowards(var4.field_1724, this.ctx.playerRotations(), REACH, false);
                        if (var14 instanceof class_3965 var15
                           && var14.method_17783() == class_240.field_1332
                           && var15.method_17777().equals(var21.hit())
                           && (var21.side() == null || var15.method_17780() == var21.side())) {
                           var12 = var15;
                        }
                     } else {
                        var12 = var13;
                     }

                     if (var12 != null) {
                        if (var21.task().type() == FinishTask.Type.WATERLOG) {
                           class_2680 var28 = var4.field_1687.method_8320(var12.method_17777());
                           if (!(var28.method_26204() instanceof class_2397) && var28.method_26204() != var21.task().desired().method_26204()) {
                              this.releaseClick();
                              this.giveUpOnEngaged("crosshair hit non-leaf block during waterlog interaction");
                              return this.mode == FinishProcess.Mode.OPPORTUNISTIC ? this.defer() : this.standStill();
                           }

                           if (var28.method_28498(class_2741.field_12508) && (Boolean)var28.method_11654(class_2741.field_12508)) {
                              this.releaseClick();
                              this.verifyingTask = var21.task();
                              this.verifyingSettledTicks = 4;
                              return this.standStill();
                           }
                        } else if (var21.task().isFluid()) {
                           class_2680 var29 = var4.field_1687.method_8320(var21.task().pos());
                           if (!var29.method_26215() && !var29.method_45474() && !var29.method_26227().method_15769() && var29.method_26227().method_15771()) {
                              this.releaseClick();
                              this.verifyingTask = var21.task();
                              this.verifyingSettledTicks = 4;
                              return this.standStill();
                           }
                        }

                        class_1269 var30 = var4.field_1761.method_2896(var4.field_1724, class_1268.field_5808, var12);
                        if (!var30.method_23665() && var21.task().isFluid()) {
                           class_239 var31 = RayTraceUtils.rayTraceTowards(var4.field_1724, this.ctx.playerRotations(), REACH, false);
                           if (var31 instanceof class_3965 var32 && var31.method_17783() == class_240.field_1332) {
                              boolean var16 = false;
                              if (var21.task().type() == FinishTask.Type.WATERLOG) {
                                 class_2680 var34 = var4.field_1687.method_8320(var21.task().pos());
                                 boolean var35 = var34.method_28498(class_2741.field_12508) && !(Boolean)var34.method_11654(class_2741.field_12508);
                                 var16 = var32.method_17777().equals(var21.task().pos()) && var35;
                              } else {
                                 boolean var17 = var32.method_17777().equals(var21.hit()) && (var21.side() == null || var32.method_17780() == var21.side());
                                 class_2680 var18 = var4.field_1687.method_8320(var21.task().pos());
                                 boolean var19 = var18.method_26215()
                                    || var18.method_45474()
                                    || !var18.method_26227().method_15769() && !var18.method_26227().method_15771();
                                 var16 = var17 && var19;
                              }

                              if (var16) {
                                 var30 = var4.field_1761.method_2919(var4.field_1724, class_1268.field_5808);
                              } else {
                                 DebugLog.detail("Suppressed unsafe interactItem for " + var21.task() + " (not safe or crosshair drifted off target)");
                              }
                           } else {
                              DebugLog.detail("Suppressed unsafe interactItem for " + var21.task() + " (crosshair not on block)");
                           }
                        }

                        if (var30.method_23665()) {
                           var4.field_1724.method_6104(class_1268.field_5808);
                           this.stallTicks = 0;
                           if (var21.task().isFluid()) {
                              this.cooldown = Math.max(14, (Integer)BaritoneAPI.getSettings().rightClickSpeed.value + 6);
                              this.verifyingTask = var21.task();
                              this.verifyingAim = var21;
                              this.verifyingTicks = 0;
                              this.verifyingSettledTicks = 0;
                              this.releaseClick();
                              return this.standStill();
                           }

                           this.cooldown = (Integer)BaritoneAPI.getSettings().rightClickSpeed.value + 2;
                        }

                        if (++this.attempts > 24) {
                           this.abandon(var21.task(), "it kept refusing the interaction");
                        }

                        if (this.mode == FinishProcess.Mode.OPPORTUNISTIC && !var21.task().isFluid()) {
                           this.snoozeUntil.put(var21.task().pos(), this.tickCounter + 15);
                           this.clearEngagement();
                           this.releaseClick();
                           return this.defer();
                        }
                     }
                  }

                  this.releaseClick();
               } else {
                  this.releaseClick();
               }

               if (this.mode == FinishProcess.Mode.OPPORTUNISTIC && this.engaged != null && this.engagedTicks > 8) {
                  this.giveUpOnEngaged("could not line up click mid-build", 30);
                  return this.defer();
               } else {
                  return this.standStill();
               }
            }
         }
      }
   }

   private PathingCommand defer() {
      return new PathingCommand(null, PathingCommandType.DEFER);
   }

   private PathingCommand standStill() {
      return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
   }

   private FinishProcess.Aim engagedAim() {
      if (this.engaged != null) {
         if (this.queue.contains(this.engaged) && (this.engaged.type() != FinishTask.Type.WATERLOG || this.isLeafMatured(this.engaged.pos()))) {
            FinishProcess.Aim var2 = this.aimFor(this.engaged);
            if (var2 != null) {
               if (++this.engagedTicks <= this.engageLimit()) {
                  return var2;
               }

               this.giveUpOnEngaged("could not line up a click on it");
               return null;
            }

            this.dropped = this.engaged;
            if (this.mode != FinishProcess.Mode.OPPORTUNISTIC && this.mode != FinishProcess.Mode.LAYER) {
               this.clearEngagement();
            } else {
               this.giveUpOnEngaged("lost reach mid-build", 40);
            }

            return null;
         }

         this.clearEngagement();
      }

      FinishProcess.Aim var1 = this.findInReach();
      if (var1 != null) {
         this.engaged = var1.task();
         this.engagedTicks = 0;
         if (this.engaged.equals(this.dropped)) {
            if (++this.reEngageRuns == 1) {
               DebugLog.detail("re-engage " + this.engaged + " after losing reach \u2014 will report the total");
            }
         } else {
            this.reportReEngageRun();
            DebugLog.detail("engage " + this.engaged + " (" + this.queue.size() + " queued)");
         }

         this.dropped = null;
      }

      return var1;
   }

   private void reportReEngageRun() {
      if (this.reEngageRuns > 1) {
         DebugLog.detail("lost reach on the same task " + this.reEngageRuns + "x in a row before moving on");
      }

      this.reEngageRuns = 0;
   }

   private int engageLimit() {
      return this.mode == FinishProcess.Mode.OPPORTUNISTIC ? 60 : 200;
   }

   private void giveUpOnEngaged(String string) {
      this.giveUpOnEngaged(string, 40);
   }

   private void giveUpOnEngaged(String string, int i) {
      FinishTask var3 = this.engaged;
      int var4 = this.engagedTicks;
      this.clearEngagement();
      this.releaseClick();
      if (var3 != null) {
         if (this.scaffoldPos != null
            && var3.equals(this.scaffoldFor)
            && this.ctx != null
            && this.ctx.world() != null
            && this.ctx.world().method_8320(this.scaffoldPos).method_26215()) {
            this.forgetScaffold();
         }

         DebugLog.detail("give up on " + var3 + " after " + var4 + "t: " + string);
         if (this.mode == FinishProcess.Mode.SWEEP) {
            this.abandon(var3, string);
         } else {
            this.snoozeUntil.put(var3.pos(), this.tickCounter + i);
            this.queue.remove(var3);
            this.queue.addLast(var3);
         }
      }
   }

   private void clearEngagement() {
      if (this.mode == FinishProcess.Mode.OPPORTUNISTIC && this.previousSelectedSlot >= 0) {
         class_310 var1 = class_310.method_1551();
         if (var1 != null && var1.field_1724 != null) {
            class_1799 var2 = var1.field_1724.method_31548().method_5438(this.previousSelectedSlot);
            if (!var2.method_31574(class_1802.field_8535) && !var2.method_31574(class_1802.field_8554) && !var2.method_31574(class_1802.field_8187)) {
               InventoryHelper.selectHotbarSlot(var1, this.previousSelectedSlot);
            } else {
               int var3 = InventoryHelper.findSafeHotbarSlot(var1.field_1724);
               if (var3 >= 0) {
                  InventoryHelper.selectHotbarSlot(var1, var3);
               }
            }
         }

         this.previousSelectedSlot = -1;
      }

      this.engaged = null;
      this.engagedTicks = 0;
      this.attempts = 0;
      this.standUpTicks = 0;
      this.calcFailures = 0;
   }

   private PathingCommand travel(boolean bl) {
      if (this.travelTarget != null && (!this.queue.contains(this.travelTarget) || !this.travelable(this.travelTarget))) {
         this.travelTarget = null;
      }

      if (this.travelTarget == null) {
         this.travelTarget = this.nearestTravelable();
         if (this.travelTarget == null && !this.queue.isEmpty()) {
            this.snoozeUntil.clear();
            this.travelTarget = this.nearestTravelable();
         }

         this.travelTicks = 0;
         this.calcFailures = 0;
      }

      FinishTask var2 = this.travelTarget;
      if (var2 != null) {
         this.unplaceableTicks = 0;
         this.layerIdleTicks = 0;
         if (bl) {
            this.calcFailures++;
         }

         int var9 = Math.max(200, (int)(Math.sqrt(var2.pos().method_10262(this.ctx.playerFeet())) * 25.0));
         if (++this.travelTicks > var9 || this.calcFailures > 40) {
            int var11 = this.pathFailures.getOrDefault(var2.pos(), 0) + 1;
            this.pathFailures.put(var2.pos(), var11);
            if (var11 >= 3) {
               DebugLog.detail(
                  "Abandoning "
                     + var2
                     + " after "
                     + var11
                     + " failed pathing attempts (travelTicks="
                     + this.travelTicks
                     + ", calcFailures="
                     + this.calcFailures
                     + ")"
               );
               this.abandon(var2, "could not get to it" + (this.mode == FinishProcess.Mode.LAYER ? " on layer Y=" + this.ceiling : ""));
            } else {
               DebugLog.detail(
                  "Snoozing " + var2 + " (attempt " + var11 + "/3) for 160 ticks due to pathing difficulty (calcFailures=" + this.calcFailures + ")"
               );
               this.snoozeUntil.put(var2.pos(), this.tickCounter + 160);
               this.travelTarget = null;
               this.travelTicks = 0;
               this.calcFailures = 0;
            }

            return this.standStill();
         } else {
            if (this.occupies(var2.pos())) {
               return new PathingCommand(new GoalRunAway(4.0, new class_2338[]{var2.pos()}), PathingCommandType.SET_GOAL_AND_PATH);
            }

            if (var2.type() == FinishTask.Type.LAVA_SOURCE && !this.isPlayerSafeFromLava(var2)) {
               return new PathingCommand(new GoalRunAway(2.0, new class_2338[]{var2.pos()}), PathingCommandType.SET_GOAL_AND_PATH);
            }

            if (this.scaffoldPos != null && this.ctx.playerFeet().method_10074().equals(this.scaffoldPos)) {
               return new PathingCommand(new GoalRunAway(2.0, new class_2338[]{this.scaffoldPos}), PathingCommandType.SET_GOAL_AND_PATH);
            }

            if (this.ctx.playerFeet().method_10264() < var2.pos().method_10264()) {
               try {
                  BaritoneAPI.getSettings().allowPlace.value = true;
                  BaritoneAPI.getSettings().allowPlaceInFluidsSource.value = false;
                  BaritoneAPI.getSettings().allowPlaceInFluidsFlow.value = false;
                  BaritoneAPI.getSettings().blockPlacementPenalty.value = 1.0;
               } catch (Throwable var8) {
               }
            } else {
               try {
                  BaritoneAPI.getSettings().allowPlace.value = false;
                  BaritoneAPI.getSettings().allowPlaceInFluidsSource.value = false;
                  BaritoneAPI.getSettings().allowPlaceInFluidsFlow.value = false;
                  BaritoneAPI.getSettings().blockPlacementPenalty.value = 35.0;
               } catch (Throwable var7) {
               }
            }

            int var10 = var2.pos().method_10264();
            int var12 = var2.pos().method_10264() + 2;
            if (isFluidSource(var2)) {
               Goal var6;
               if (this.calcFailures > 10) {
                  var6 = new FinishProcess.GoalLayerNear(var2.pos(), 2, var10, var12);
               } else {
                  var6 = this.fluidStandGoal(var2);
               }

               return new PathingCommand(var6, PathingCommandType.SET_GOAL_AND_PATH);
            } else {
               return new PathingCommand(new FinishProcess.GoalLayerNear(var2.pos(), 3, var10, var12), PathingCommandType.SET_GOAL_AND_PATH);
            }
         }
      } else if (this.mode == FinishProcess.Mode.LAYER) {
         if (this.hasDoableWorkAtOrBelow(this.ceiling) && ++this.layerIdleTicks <= 400) {
            return this.standStill();
         }

         this.mode = FinishProcess.Mode.OFF;
         return null;
      } else {
         if (++this.unplaceableTicks <= 200) {
            return this.standStill();
         }

         FinishTask var3 = this.queue.peek();
         this.mode = FinishProcess.Mode.OFF;

         for (FinishTask var5 : this.queue) {
            this.abandonedTaskPositions.add(var5.pos());
         }

         this.abandoned.addAll(this.queue);
         this.queue.clear();
         this.queuedTaskPositions.clear();
         this.report(
            "nothing left is placeable \u2014 the structure is probably incomplete"
               + (
                  var3 == null
                     ? ""
                     : " (e.g. " + var3 + " is still waiting on" + (var3.ready(this.ctx.world()) ? " a block to pour against" : " its own block") + ")"
               )
         );
         return null;
      }
   }

   private Goal fluidStandGoal(FinishTask finishTask) {
      class_2338 var2 = finishTask.pos();
      ArrayList var3 = new ArrayList();
      int var4 = this.ctx.playerFeet().method_10264();

      for (int var5 = -2; var5 <= 2; var5++) {
         for (int var6 = -2; var6 <= 2; var6++) {
            if ((var5 != 0 || var6 != 0) && Math.abs(var5) + Math.abs(var6) <= 3) {
               for (int var7 = 0; var7 <= 1; var7++) {
                  class_2338 var8 = var2.method_10069(var5, var7, var6);
                  if (Math.abs(var8.method_10264() - var4) <= 1) {
                     class_2338 var9 = var8.method_10074();
                     if (this.scaffoldPos == null || !var9.equals(this.scaffoldPos)) {
                        class_2680 var10 = this.ctx.world().method_8320(var9);
                        class_2680 var11 = this.ctx.world().method_8320(var8);
                        class_2680 var12 = this.ctx.world().method_8320(var8.method_10084());
                        if (!var10.method_26215()
                           && !var10.method_45474()
                           && var10.method_26227().method_15769()
                           && (var11.method_26215() || var11.method_45474())
                           && var11.method_26227().method_15769()
                           && (var12.method_26215() || var12.method_45474())
                           && (finishTask.type() != FinishTask.Type.LAVA_SOURCE || this.isPlayerSafeFromLavaAt(class_243.method_24955(var8), finishTask))) {
                           class_243 var13 = new class_243(var8.method_10263() + 0.5, var8.method_10264() + 1.62, var8.method_10260() + 0.5);
                           if (this.pourAimFrom(finishTask, var13) != null) {
                              var3.add(var8);
                           }
                        }
                     }
                  }
               }
            }
         }
      }

      if (!var3.isEmpty()) {
         class_2338 var14 = (class_2338)var3.get(0);
         double var15 = var14.method_10262(this.ctx.playerFeet());

         for (int var16 = 1; var16 < var3.size(); var16++) {
            class_2338 var17 = (class_2338)var3.get(var16);
            double var18 = var17.method_10262(this.ctx.playerFeet());
            if (var18 < var15) {
               var14 = var17;
               var15 = var18;
            }
         }

         return new GoalBlock(var14);
      } else {
         return new FinishProcess.GoalLayerNear(var2, 2, var2.method_10264(), var2.method_10264() + 2);
      }
   }

   private boolean travelable(FinishTask finishTask) {
      if (finishTask.pos().method_10264() > this.ceiling) {
         return false;
      }

      if (!finishTask.ready(this.ctx.world())) {
         return false;
      }

      if (isFluidSource(finishTask)) {
         return this.hasSupport(finishTask) || this.canScaffold(finishTask);
      }

      if (finishTask.type() != FinishTask.Type.WATERLOG) {
         return true;
      }

      class_2680 var2 = this.ctx.world().method_8320(finishTask.pos());
      return var2.method_26204() == finishTask.desired().method_26204()
         || var2.method_26204() instanceof class_2397 && finishTask.desired().method_26204() instanceof class_2397;
   }

   private boolean canScaffold(FinishTask finishTask) {
      if (this.scaffoldItem() == null) {
         return false;
      }

      if (this.scaffoldPos != null && !finishTask.equals(this.scaffoldFor)) {
         return false;
      }

      class_2350[] var2 = finishTask.type() == FinishTask.Type.WATERLOG ? SCAFFOLD_ORDER_WATERLOG : SCAFFOLD_ORDER_FLUID;

      for (class_2350 var6 : var2) {
         class_2338 var7 = finishTask.pos().method_10093(var6);
         if (this.scaffoldable(var7)) {
            for (class_2350 var11 : class_2350.values()) {
               class_2338 var12 = var7.method_10093(var11);
               if (!var12.equals(finishTask.pos()) && this.placeableAgainst(var12)) {
                  return true;
               }
            }
         }
      }

      return false;
   }

   private FinishTask nearestTravelable() {
      BetterBlockPos var1 = this.ctx.playerFeet();
      FinishTask var2 = null;
      double var3 = Double.MAX_VALUE;

      for (FinishTask var6 : this.queue) {
         if (this.travelable(var6)) {
            Integer var7 = this.snoozeUntil.get(var6.pos());
            if (var7 == null || this.tickCounter >= var7) {
               double var8 = var6.pos().method_10262(var1);
               if (var8 < var3) {
                  var3 = var8;
                  var2 = var6;
               }
            }
         }
      }

      return var2;
   }

   private FinishProcess.Aim findInReach() {
      class_243 var1 = this.ctx.player().method_33571();
      double var2 = (REACH + 1.0) * (REACH + 1.0);
      int var4 = 0;
      this.skips = new int[SKIP_REASONS.length];

      for (FinishTask var6 : this.queue) {
         if (var6.pos().method_10264() > this.ceiling) {
            this.skips[6]++;
         } else if (var1.method_1025(class_243.method_24953(var6.pos())) > var2) {
            this.skips[0]++;
         } else {
            Integer var7 = this.snoozeUntil.get(var6.pos());
            if (var7 != null && this.tickCounter < var7) {
               this.skips[1]++;
            } else {
               if (this.mode == FinishProcess.Mode.OPPORTUNISTIC) {
                  if (this.cooldown > 0) {
                     return null;
                  }

                  if (var6.requiredItem() != null && !InventoryHelper.canEquipOpportunistic(this.ctx.player(), var6.requiredItem())) {
                     this.skips[1]++;
                     continue;
                  }
               }

               if (this.mode == FinishProcess.Mode.OPPORTUNISTIC && var6.type() == FinishTask.Type.LAVA_SOURCE && !this.lavaSafe(var6)) {
                  this.skips[2]++;
               } else if (LavaSeal.needsSealCheck(this.mode, var6) && !this.sealed(var6)) {
                  this.skips[3]++;
               } else if (var6.type() == FinishTask.Type.LAVA_SOURCE && !this.isPlayerSafeFromLava(var6)) {
                  this.skips[2]++;
               } else if (!var6.ready(this.ctx.world())) {
                  this.skips[4]++;
               } else if (var6.type() == FinishTask.Type.WATERLOG && !this.isLeafMatured(var6.pos())) {
                  this.skips[1]++;
               } else {
                  FinishProcess.Aim var8 = this.aimFor(var6);
                  if (var8 != null) {
                     return var8;
                  }

                  this.skips[5]++;
                  if (++var4 >= 6) {
                     return null;
                  }
               }
            }
         }
      }

      return null;
   }

   private String skipTally() {
      if (this.skips == null) {
         return "";
      }

      StringBuilder var1 = new StringBuilder();

      for (int var2 = 0; var2 < this.skips.length; var2++) {
         if (this.skips[var2] > 0) {
            var1.append(var1.isEmpty() ? " skipped: " : ", ").append(this.skips[var2]).append(' ').append(SKIP_REASONS[var2]);
         }
      }

      return var1.toString();
   }

   private boolean sealed(FinishTask finishTask) {
      if (finishTask.type() != FinishTask.Type.WATER_SOURCE && finishTask.type() != FinishTask.Type.LAVA_SOURCE) {
         return true;
      }

      for (class_2350 var5 : class_2350.values()) {
         if (var5 != class_2350.field_11036) {
            if (var5 == class_2350.field_11033) {
               class_2338 var6 = finishTask.pos().method_10074();
               class_2680 var7 = this.ctx.world().method_8320(var6);
               if (var7.method_26227().method_15769() && !var7.method_26234(this.ctx.world(), var6)) {
                  if (this.mode == FinishProcess.Mode.OPPORTUNISTIC) {
                     return false;
                  }

                  class_2338 var8 = var6;
                  boolean var9 = false;

                  label77:
                  while (var8.method_10264() > this.ctx.world().method_31607()) {
                     class_2680 var10 = this.ctx.world().method_8320(var8);
                     if (var10.method_26234(this.ctx.world(), var8) || !var10.method_26227().method_15769()) {
                        var9 = true;
                        break;
                     }

                     boolean var11 = true;

                     for (class_2350 var15 : class_2350.values()) {
                        if (var15.method_10166().method_10179()) {
                           class_2338 var16 = var8.method_10093(var15);
                           class_2680 var17 = this.ctx.world().method_8320(var16);
                           if (!var17.method_26234(this.ctx.world(), var16)) {
                              var11 = false;
                              if (!var11) {
                                 return false;
                              }

                              var8 = var8.method_10074();
                              continue label77;
                           }
                        }
                     }
                     break;
                  }

                  if (!var9) {
                     return false;
                  }
               }
            } else {
               class_2338 var18 = finishTask.pos().method_10093(var5);
               class_2680 var19 = this.ctx.world().method_8320(var18);
               if (var19.method_26227().method_15769()) {
                  if (var19.method_26215() || var19.method_45474()) {
                     return false;
                  }

                  if (!var19.method_26234(this.ctx.world(), var18)) {
                     return false;
                  }
               }
            }
         }
      }

      return true;
   }

   private boolean lavaSafe(FinishTask finishTask) {
      class_2338 var2 = finishTask.pos();

      for (int var3 = -1; var3 <= 1; var3++) {
         for (int var4 = -1; var4 <= 1; var4++) {
            for (int var5 = -1; var5 <= 2; var5++) {
               class_2338 var6 = var2.method_10069(var3, var5, var4);
               class_2680 var7 = this.ctx.world().method_8320(var6);
               if (var7.method_26227().method_15769() && var7.method_50011()) {
                  return false;
               }
            }
         }
      }

      return this.isPlayerSafeFromLava(finishTask);
   }

   private boolean isPlayerSafeFromLava(FinishTask finishTask) {
      class_2338 var2 = finishTask.pos();
      BetterBlockPos var3 = this.ctx.playerFeet();
      if (var2.equals(var3) || var2.equals(var3.method_10084()) || var2.equals(var3.method_10074())) {
         return false;
      } else {
         return this.ctx.player() != null
            ? this.isPlayerSafeFromLavaAt(
               new class_243(this.ctx.player().method_23317(), this.ctx.player().method_23318(), this.ctx.player().method_23321()), finishTask
            )
            : true;
      }
   }

   private boolean isPlayerSafeFromLavaAt(class_243 arg, FinishTask finishTask) {
      class_2338 var3 = finishTask.pos();
      double var4 = arg.field_1352;
      double var6 = arg.field_1351;
      double var8 = arg.field_1350;
      return !(var4 > var3.method_10263() - 0.35)
         || !(var4 < var3.method_10263() + 1.35)
         || !(var8 > var3.method_10260() - 0.35)
         || !(var8 < var3.method_10260() + 1.35)
         || !(var6 > var3.method_10264() - 1.85)
         || !(var6 < var3.method_10264() + 1.0);
   }

   private FinishProcess.Aim aimFor(FinishTask finishTask) {
      if (finishTask.type() == FinishTask.Type.WATERLOG) {
         class_2680 var2 = this.ctx.world().method_8320(finishTask.pos());
         if (var2.method_26204() != finishTask.desired().method_26204()
            && (!(var2.method_26204() instanceof class_2397) || !(finishTask.desired().method_26204() instanceof class_2397))) {
            return null;
         }

         if (var2.method_28498(class_2741.field_12508) && (Boolean)var2.method_11654(class_2741.field_12508)) {
            return null;
         }

         if (!this.isLeafMatured(finishTask.pos())) {
            return null;
         }
      }

      FinishProcess.Aim var3 = this.pourAim(finishTask);
      return var3 != null ? var3 : this.scaffoldAim(finishTask);
   }

   private static List<class_243> facePoints(class_2338 arg, class_2350 arg2) {
      ArrayList var2 = new ArrayList();
      class_243 var3 = class_243.method_24953(arg).method_1031(arg2.method_10148() * 0.48, arg2.method_10164() * 0.48, arg2.method_10165() * 0.48);
      var2.add(var3);
      if (arg2.method_10166().method_10179()) {
         class_2350 var4 = arg2.method_10170();
         double[] var5 = new double[]{-0.18, 0.18};
         double[] var6 = new double[]{0.18, -0.18};

         for (double var10 : var6) {
            for (double var15 : var5) {
               var2.add(var3.method_1031(var4.method_10148() * var15, var10, var4.method_10165() * var15));
            }
         }
      } else {
         double[] var17 = new double[]{-0.18, 0.18};
         double[] var18 = new double[]{-0.18, 0.18};

         for (double var22 : var18) {
            for (double var25 : var17) {
               var2.add(var3.method_1031(var25, 0.0, var22));
            }
         }
      }

      return var2;
   }

   private FinishProcess.Aim waterlogAim(FinishTask finishTask) {
      class_2338 var2 = finishTask.pos();
      class_243 var3 = this.ctx.player().method_33571();
      class_2350[] var4 = new class_2350[]{
         class_2350.field_11036, class_2350.field_11043, class_2350.field_11035, class_2350.field_11039, class_2350.field_11034, class_2350.field_11033
      };

      for (class_2350 var8 : var4) {
         class_2338 var9 = var2.method_10093(var8);
         class_2680 var10 = this.ctx.world().method_8320(var9);
         if (!var10.method_26234(this.ctx.world(), var9)) {
            for (class_243 var12 : facePoints(var2, var8)) {
               if (!(var3.method_1025(var12) > REACH * REACH)) {
                  class_3959 var13 = new class_3959(var3, var12, class_3960.field_17559, class_242.field_1348, this.ctx.player());
                  class_3965 var14 = this.ctx.world().method_17742(var13);
                  if (var14 != null && var14.method_17783() == class_240.field_1332 && var14.method_17777().equals(var2) && var14.method_17780() == var8) {
                     Rotation var15 = RotationUtils.calcRotationFromVec3d(var3, var14.method_17784(), this.ctx.playerRotations());
                     return new FinishProcess.Aim(finishTask, var15, var2, var8, FinishProcess.Kind.USE);
                  }
               }
            }
         }
      }

      Optional var16 = RotationUtils.reachable(this.ctx, var2, REACH, false);
      if (var16.isPresent()) {
         Rotation var17 = (Rotation)var16.get();
         class_239 var18 = RayTraceUtils.rayTraceTowards(this.ctx.player(), var17, REACH, false);
         if (var18 instanceof class_3965 var19 && var18.method_17783() == class_240.field_1332 && var19.method_17777().equals(var2)) {
            return new FinishProcess.Aim(finishTask, var17, var2, var19.method_17780(), FinishProcess.Kind.USE);
         }
      }

      return null;
   }

   private FinishProcess.Aim pourAim(FinishTask finishTask) {
      return this.occupies(finishTask.pos()) ? null : this.pourAimFrom(finishTask, this.ctx.player().method_33571());
   }

   private FinishProcess.Aim pourAimFrom(FinishTask finishTask, class_243 arg) {
      class_2338 var3 = finishTask.pos();
      if (finishTask.type() == FinishTask.Type.WATERLOG) {
         return this.waterlogAim(finishTask);
      }

      if (!isFluidSource(finishTask)) {
         return RotationUtils.reachable(this.ctx, var3, REACH, false)
            .map(rotation -> new FinishProcess.Aim(finishTask, rotation, var3, null, FinishProcess.Kind.USE))
            .orElse(null);
      }

      boolean var4 = finishTask.type() == FinishTask.Type.WATER_SOURCE;

      for (class_2350 var8 : SUPPORT_ORDER) {
         class_2338 var9 = var3.method_10093(var8);
         class_2350 var10 = var8.method_10153();
         if (canPourAgainst(this.ctx.world(), var9, var4)) {
            for (class_243 var12 : facePoints(var9, var10)) {
               if (!(arg.method_1025(var12) > REACH * REACH)) {
                  class_3959 var13 = new class_3959(arg, var12, class_3960.field_17559, class_242.field_1348, this.ctx.player());
                  class_3965 var14 = this.ctx.world().method_17742(var13);
                  if (var14 != null && var14.method_17783() == class_240.field_1332 && var14.method_17777().equals(var9) && var14.method_17780() == var10) {
                     Rotation var15 = RotationUtils.calcRotationFromVec3d(arg, var14.method_17784(), this.ctx.playerRotations());
                     return new FinishProcess.Aim(finishTask, var15, var9, var10, FinishProcess.Kind.USE);
                  }
               }
            }
         }
      }

      return null;
   }

   private FinishProcess.Aim scaffoldAim(FinishTask finishTask) {
      if (this.walking() && this.scaffoldItem() != null) {
         if (this.scaffoldPos != null) {
            if (!this.ctx.world().method_8320(this.scaffoldPos).method_26215()) {
               return null;
            } else {
               return finishTask.equals(this.scaffoldFor) ? this.placeAim(finishTask, this.scaffoldPos, FinishProcess.Kind.SCAFFOLD) : null;
            }
         } else {
            class_2350[] var2 = finishTask.type() == FinishTask.Type.WATERLOG ? SCAFFOLD_ORDER_WATERLOG : SCAFFOLD_ORDER_FLUID;

            for (class_2350 var6 : var2) {
               class_2338 var7 = finishTask.pos().method_10093(var6);
               if (this.scaffoldable(var7)) {
                  FinishProcess.Aim var8 = this.placeAim(finishTask, var7, FinishProcess.Kind.SCAFFOLD);
                  if (var8 != null) {
                     this.scaffoldPos = var7;
                     this.scaffoldFor = finishTask;
                     this.scaffoldBreakTicks = 0;
                     return var8;
                  }
               }
            }

            return null;
         }
      } else {
         return null;
      }
   }

   private boolean scaffoldable(class_2338 arg) {
      if (this.ctx.world().method_8320(arg).method_26215() && !this.occupies(arg)) {
         if (!arg.equals(this.ctx.playerFeet()) && !arg.equals(this.ctx.playerFeet().method_10074())) {
            for (FinishTask var3 : this.queue) {
               if (var3.pos().equals(arg)) {
                  return false;
               }
            }

            return true;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private FinishProcess.Aim placeAim(FinishTask finishTask, class_2338 arg, FinishProcess.Kind kind) {
      if (this.occupies(arg)) {
         return null;
      }

      class_243 var4 = this.ctx.player().method_33571();

      for (class_2350 var8 : class_2350.values()) {
         class_2338 var9 = arg.method_10093(var8);
         if (!var9.equals(finishTask.pos()) && this.placeableAgainst(var9)) {
            class_2350 var10 = var8.method_10153();

            for (class_243 var12 : facePoints(var9, var10)) {
               if (!(var4.method_1025(var12) > REACH * REACH)) {
                  class_3959 var13 = new class_3959(var4, var12, class_3960.field_17559, class_242.field_1348, this.ctx.player());
                  class_3965 var14 = this.ctx.world().method_17742(var13);
                  if (var14 != null && var14.method_17783() == class_240.field_1332 && var14.method_17777().equals(var9) && var14.method_17780() == var10) {
                     Rotation var15 = RotationUtils.calcRotationFromVec3d(var4, var14.method_17784(), this.ctx.playerRotations());
                     return new FinishProcess.Aim(finishTask, var15, var9, var10, kind);
                  }
               }
            }
         }
      }

      return null;
   }

   private boolean placeableAgainst(class_2338 arg) {
      class_2680 var2 = this.ctx.world().method_8320(arg);
      if (!var2.method_26215() && !var2.method_45474() && var2.method_26227().method_15769()) {
         if (!var2.method_26234(this.ctx.world(), arg) && !(var2.method_26204() instanceof class_2397)) {
            return false;
         }

         class_2248 var3 = var2.method_26204();
         return !(var3 instanceof class_2237) && !(var3 instanceof class_2428) && !(var3 instanceof class_2304);
      } else {
         return false;
      }
   }

   private class_1792 scaffoldItem() {
      class_746 var1 = this.ctx.player();
      if (var1 == null) {
         return null;
      }

      for (class_1792 var5 : SCAFFOLD_ITEMS) {
         if (InventoryHelper.count(var1, var5) > 0) {
            return var5;
         }
      }

      return null;
   }

   private PathingCommand removeScaffold() {
      class_2338 var1 = this.scaffoldPos;
      if (this.ctx.world().method_8320(var1).method_26215()) {
         this.forgetScaffold();
         return null;
      }

      if (++this.scaffoldBreakTicks > 200) {
         AutoBuildFarm.chat(
            "\u26a0 Left a temporary block at "
               + var1.method_10263()
               + ", "
               + var1.method_10264()
               + ", "
               + var1.method_10260()
               + " \u2014 could not break it back out."
         );
         this.forgetScaffold();
         return null;
      }

      this.releaseClick();
      if (!this.standUp()) {
         return this.standStill();
      }

      if (this.ctx.playerFeet().method_10074().equals(var1)) {
         return new PathingCommand(new GoalRunAway(2.0, new class_2338[]{var1}), PathingCommandType.SET_GOAL_AND_PATH);
      }

      Optional var2 = RotationUtils.reachable(this.ctx, var1, REACH, false);
      if (var2.isEmpty()) {
         return new PathingCommand(new GoalNear(var1, 2), PathingCommandType.SET_GOAL_AND_PATH);
      }

      InventoryHelper.holdBestTool(class_310.method_1551(), this.ctx.world().method_8320(var1));
      this.baritone.getLookBehavior().updateTarget((Rotation)var2.get(), true);
      class_239 var3 = this.ctx.objectMouseOver();
      if (var3 instanceof class_3965 var4 && var3.method_17783() == class_240.field_1332 && var4.method_17777().equals(var1)) {
         this.baritone.getInputOverrideHandler().setInputForceState(Input.CLICK_LEFT, true);
         this.breakHeld = true;
         this.stallTicks = 0;
      }

      return this.standStill();
   }

   private void forgetScaffold() {
      this.releaseClick();
      this.scaffoldPos = null;
      this.scaffoldFor = null;
      this.scaffoldBreakTicks = 0;
   }

   private boolean hasSupport(FinishTask finishTask) {
      boolean var2 = finishTask.type() == FinishTask.Type.WATER_SOURCE;

      for (class_2350 var6 : SUPPORT_ORDER) {
         if (canPourAgainst(this.ctx.world(), finishTask.pos().method_10093(var6), var2)) {
            return true;
         }
      }

      return false;
   }

   private static boolean canPourAgainst(class_1922 arg, class_2338 arg2, boolean bl) {
      class_2680 var3 = arg.method_8320(arg2);
      if (!var3.method_26215() && !var3.method_45474() && var3.method_26227().method_15769()) {
         class_2248 var4 = var3.method_26204();
         return !(var4 instanceof class_2237)
               && !(var4 instanceof class_2304)
               && !(var4 instanceof class_2533)
               && !(var4 instanceof class_2323)
               && !(var4 instanceof class_2349)
               && !(var4 instanceof class_2269)
               && !(var4 instanceof class_2401)
               && !(var4 instanceof class_2428)
            ? !bl || !var3.method_28498(class_2741.field_12508) || (Boolean)var3.method_11654(class_2741.field_12508)
            : false;
      } else {
         return false;
      }
   }

   private boolean occupies(class_2338 arg) {
      BetterBlockPos var2 = this.ctx.playerFeet();
      return var2.equals(arg) || var2.method_10084().equals(arg);
   }

   private boolean onTarget(FinishProcess.Aim aim) {
      class_239 var2 = this.ctx.objectMouseOver();
      if (!(
         var2 instanceof class_3965 var3
            && var2.method_17783() == class_240.field_1332
            && var3.method_17777().equals(aim.hit())
            && (aim.side() == null || var3.method_17780() == aim.side())
      )) {
         Rotation var11 = this.ctx.playerRotations();
         class_239 var4 = RayTraceUtils.rayTraceTowards(this.ctx.player(), var11, REACH, false);
         if (!(
            var4 instanceof class_3965 var5
               && var4.method_17783() == class_240.field_1332
               && var5.method_17777().equals(aim.hit())
               && (aim.side() == null || var5.method_17780() == aim.side())
         )) {
            if (!aim.task().isFluid()) {
               double var12 = Math.abs(class_3532.method_15393(var11.getYaw() - aim.rotation().getYaw()));
               double var7 = Math.abs(var11.getPitch() - aim.rotation().getPitch());
               if (var12 < 2.0 && var7 < 2.0) {
                  class_239 var9 = RayTraceUtils.rayTraceTowards(this.ctx.player(), aim.rotation(), REACH, false);
                  if (var9 instanceof class_3965 var10
                     && var9.method_17783() == class_240.field_1332
                     && var10.method_17777().equals(aim.hit())
                     && (aim.side() == null || var10.method_17780() == aim.side())) {
                     return true;
                  }
               }
            }

            return false;
         } else {
            return true;
         }
      } else {
         return true;
      }
   }

   private static boolean isFluidSource(FinishTask finishTask) {
      return finishTask.type() == FinishTask.Type.WATER_SOURCE || finishTask.type() == FinishTask.Type.LAVA_SOURCE;
   }

   private boolean standUp() {
      boolean var1 = this.baritone.getInputOverrideHandler().isInputForcedDown(Input.SNEAK)
         || this.ctx.player().method_5715()
         || this.ctx.player().method_18276();
      if (!var1) {
         this.standUpTicks = 0;
         return true;
      } else {
         this.baritone.getInputOverrideHandler().setInputForceState(Input.SNEAK, false);
         return ++this.standUpTicks > 20;
      }
   }

   public void diagnoseNow() {
      if (this.mode != FinishProcess.Mode.OFF && this.ctx.player() != null) {
         this.diagnose(this.baritone.getPathingBehavior().getCurrent() == null);
      }
   }

   private void diagnose(boolean bl) {
      FinishTask var2 = this.engaged != null ? this.engaged : (this.travelTarget != null ? this.travelTarget : this.queue.peek());
      StringBuilder var3 = new StringBuilder("\u2026 stuck: ");
      var3.append(this.mode).append(", ").append(this.queue.size()).append(" left");
      if (this.mode == FinishProcess.Mode.OPPORTUNISTIC) {
         var3.append(this.tickCounter < this.dormantUntil ? ", stood down " + (this.dormantUntil - this.tickCounter) + "t" : ", held " + this.holdTicks + "t");
      }

      if (var2 != null) {
         class_2338 var4 = var2.pos();
         var3.append(", on ")
            .append(var2)
            .append(" @ ")
            .append(var4.method_10263())
            .append(',')
            .append(var4.method_10264())
            .append(',')
            .append(var4.method_10260())
            .append(" (")
            .append(Math.round(Math.sqrt(var4.method_10262(this.ctx.playerFeet()))))
            .append("m)");
         if (!var2.ready(this.ctx.world())) {
            var3.append(" [its own block is missing]");
         } else if (isFluidSource(var2) && !this.hasSupport(var2)) {
            var3.append(this.canScaffold(var2) ? " [needs a ledge]" : " [nothing to pour against]");
         } else if (this.pourAim(var2) == null) {
            var3.append(" [cannot see it from here]");
         }
      }

      if (this.engaged != null) {
         var3.append(", engaged ").append(this.engagedTicks).append('t');
      }

      if (this.scaffoldPos != null) {
         var3.append(", ledge @ ")
            .append(this.scaffoldPos.method_10263())
            .append(',')
            .append(this.scaffoldPos.method_10264())
            .append(',')
            .append(this.scaffoldPos.method_10260());
      } else if (this.scaffoldItem() == null) {
         var3.append(", no filler block on me");
      }

      if (!bl) {
         var3.append(", mid-movement");
      }

      if (!this.ctx.player().method_24828()) {
         var3.append(this.ctx.player().method_5799() ? ", floating" : ", airborne");
      }

      AutoBuildFarm.chat(var3.toString());
      DebugLog.detail("queue" + this.skipTally() + this.describeQueueHead());
   }

   private String describeQueueHead() {
      StringBuilder var1 = new StringBuilder();
      int var2 = 0;

      for (FinishTask var4 : this.queue) {
         if (var2++ >= 3) {
            break;
         }

         var1.append(" | ")
            .append(var4)
            .append(var4.ready(this.ctx.world()) ? " ready" : " host block missing")
            .append(this.sealed(var4) ? "" : " unsealed")
            .append(var4.type() == FinishTask.Type.LAVA_SOURCE && !this.lavaSafe(var4) ? " burn-risk" : "")
            .append(' ')
            .append(Math.round(Math.sqrt(var4.pos().method_10262(this.ctx.playerFeet()))))
            .append('m');
      }

      return var1.toString();
   }

   private boolean settled(boolean bl) {
      if (!bl) {
         this.unsettledTicks = 0;
         return false;
      } else {
         boolean var2 = this.ctx.player().method_24828() || this.ctx.player().method_5799() || this.ctx.player().method_5771();
         if (var2) {
            this.unsettledTicks = 0;
            return true;
         } else {
            return ++this.unsettledTicks > 40;
         }
      }
   }

   private void releaseClick() {
      if (this.clickHeld) {
         this.baritone.getInputOverrideHandler().setInputForceState(Input.CLICK_RIGHT, false);
         this.clickHeld = false;
      }

      if (this.breakHeld) {
         this.baritone.getInputOverrideHandler().setInputForceState(Input.CLICK_LEFT, false);
         this.breakHeld = false;
      }
   }

   private void dropSatisfied() {
      Iterator var1 = this.queue.iterator();

      while (var1.hasNext()) {
         FinishTask var2 = (FinishTask)var1.next();
         if (var2.satisfied(this.ctx.world())) {
            var1.remove();
            this.queuedTaskPositions.remove(var2.pos());
            if (var2.isFluid()) {
               this.recentFluidPlacements.put(var2.pos(), System.currentTimeMillis());
               this.recentFluidTasks.put(var2.pos(), var2);
               this.consecutiveFluidRollbacks = 0;
            }

            this.completed++;
            this.stallTicks = 0;
            this.stallReports = 0;
            this.travelTicks = 0;
            this.unplaceableTicks = 0;
            this.snoozeUntil.remove(var2.pos());
            this.leafSeenTicks.remove(var2.pos());
            if (var2.equals(this.engaged)) {
               this.clearEngagement();
               this.releaseClick();
            }

            this.attempts = 0;
            if (this.chatted < 24) {
               this.chatted++;
               AutoBuildFarm.chat("\u2714 " + var2 + " (" + this.queue.size() + " left)" + (this.chatted == 24 ? " \u2014 going quiet from here" : ""));
            }
         }
      }
   }

   private boolean equipFor(FinishProcess.Aim aim) {
      if (aim.kind() != FinishProcess.Kind.SCAFFOLD) {
         FinishTask var8 = aim.task();
         class_1792 var3 = var8.requiredItem();
         if (var3 == null) {
            return true;
         }

         class_310 var4 = class_310.method_1551();
         if (this.mode == FinishProcess.Mode.OPPORTUNISTIC && this.previousSelectedSlot < 0 && var4 != null && var4.field_1724 != null) {
            this.previousSelectedSlot = var4.field_1724.method_31548().method_67532();
         }

         if (InventoryHelper.holdItem(var4, var3, this.walking())) {
            return true;
         }

         if (this.mode == FinishProcess.Mode.OPPORTUNISTIC) {
            return false;
         }

         if (this.mode == FinishProcess.Mode.LAYER) {
            this.snoozeUntil.put(var8.pos(), this.tickCounter + 100);
            if (++this.stallReports % 10 == 1) {
               AutoBuildFarm.chat("Need " + var3.method_63680().getString() + " to finish layer! Please restock.");
            }

            return false;
         } else {
            int var5 = 0;
            Iterator var6 = this.queue.iterator();

            while (var6.hasNext()) {
               FinishTask var7 = (FinishTask)var6.next();
               if (var7.requiredItem() == var3) {
                  var6.remove();
                  this.queuedTaskPositions.remove(var7.pos());
                  this.abandoned.add(var7);
                  this.abandonedTaskPositions.add(var7.pos());
                  var5++;
               }
            }

            AutoBuildFarm.chat("Out of " + var3.method_63680().getString() + " \u2014 skipping " + var5 + " position(s). Refill and run /buildfarm resume.");
            this.attempts = 0;
            this.travelTicks = 0;
            this.calcFailures = 0;
            this.travelTarget = null;
            return false;
         }
      } else {
         class_1792 var2 = this.scaffoldItem();
         return var2 != null && InventoryHelper.holdItem(class_310.method_1551(), var2, true);
      }
   }

   private void abandon(FinishTask finishTask, String string) {
      if (finishTask.equals(this.engaged)) {
         this.clearEngagement();
      }

      this.snoozeUntil.remove(finishTask.pos());
      this.leafSeenTicks.remove(finishTask.pos());
      this.pathFailures.remove(finishTask.pos());
      AutoBuildFarm.LOG.warn("Skipping {}: {}", finishTask, string);
      DebugLog.detail("Skipping " + finishTask + " \u2014 " + string + ".");
      this.queue.remove(finishTask);
      this.queuedTaskPositions.remove(finishTask.pos());
      this.abandoned.add(finishTask);
      this.abandonedTaskPositions.add(finishTask.pos());
      this.attempts = 0;
      this.travelTicks = 0;
      this.calcFailures = 0;
      this.travelTarget = null;
   }

   private void report(String string) {
      this.releaseClick();
      if (this.scaffoldPos != null && !this.ctx.world().method_8320(this.scaffoldPos).method_26215()) {
         AutoBuildFarm.chat(
            "\u26a0 A temporary block is still at "
               + this.scaffoldPos.method_10263()
               + ", "
               + this.scaffoldPos.method_10264()
               + ", "
               + this.scaffoldPos.method_10260()
               + "."
         );
      }

      this.forgetScaffold();
      Consumer var2 = this.onFinished;
      this.onFinished = null;
      if (var2 != null) {
         var2.accept(new FinishProcess.Result(this.completed, List.copyOf(this.abandoned), string));
      }
   }

   private record Aim(FinishTask task, Rotation rotation, class_2338 hit, class_2350 side, FinishProcess.Kind kind) {
   }

   public static class GoalLayerNear implements Goal {
      private final int x;
      private final int y;
      private final int z;
      private final int rangeSq;
      private final int minY;
      private final int maxY;

      public GoalLayerNear(class_2338 arg, int i, int j, int k) {
         this.x = arg.method_10263();
         this.y = arg.method_10264();
         this.z = arg.method_10260();
         this.rangeSq = i * i;
         this.minY = j;
         this.maxY = k;
      }

      public boolean isInGoal(int i, int j, int k) {
         if (j >= this.minY && j <= this.maxY) {
            int var4 = i - this.x;
            int var5 = j - this.y;
            int var6 = k - this.z;
            return var4 * var4 + var5 * var5 + var6 * var6 <= this.rangeSq;
         } else {
            return false;
         }
      }

      public double heuristic(int i, int j, int k) {
         int var4 = i - this.x;
         int var5 = j - this.y;
         int var6 = k - this.z;
         double var7 = Math.sqrt(var4 * var4 + var5 * var5 + var6 * var6);
         if (j < this.minY) {
            var7 += (this.minY - j) * 100.0;
         } else if (j > this.maxY) {
            var7 += (j - this.maxY) * 100.0;
         }

         return var7;
      }
   }

   private enum Kind {
      USE,
      SCAFFOLD;
   }

   public enum Mode {
      OFF,
      OPPORTUNISTIC,
      LAYER,
      SWEEP;
   }

   public record Result(int completed, List<FinishTask> abandoned, String message) {
      public boolean clean() {
         return this.abandoned.isEmpty() && this.message == null;
      }
   }
}
