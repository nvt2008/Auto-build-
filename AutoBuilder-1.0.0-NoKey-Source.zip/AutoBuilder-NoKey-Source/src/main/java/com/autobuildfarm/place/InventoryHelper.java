package com.autobuildfarm.place;

import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2680;
import net.minecraft.class_2868;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_746;
import net.minecraft.class_7923;

public final class InventoryHelper {
   private InventoryHelper() {
   }

   public static boolean isMatchingItem(class_1799 arg, class_1792 arg2) {
      if (arg == null || arg.method_7960() || arg2 == null) {
         return false;
      }

      if (arg.method_31574(arg2)) {
         return true;
      }

      if (arg2 == class_1802.field_8410) {
         class_2960 var2 = class_7923.field_41178.method_10221(arg.method_7909());
         if (var2 != null && var2.method_12832().contains("stained_glass")) {
            return true;
         }
      }

      return false;
   }

   public static int count(class_746 arg, class_1792 arg2) {
      int var2 = 0;
      class_1661 var3 = arg.method_31548();

      for (int var4 = 0; var4 < var3.method_5439(); var4++) {
         if (isMatchingItem(var3.method_5438(var4), arg2)) {
            var2 += var3.method_5438(var4).method_7947();
         }
      }

      return var2;
   }

   public static boolean canEquipOpportunistic(class_746 arg, class_1792 arg2) {
      if (arg != null && arg2 != null) {
         class_1661 var2 = arg.method_31548();

         for (int var3 = 0; var3 < class_1661.method_7368(); var3++) {
            if (isMatchingItem(var2.method_5438(var3), arg2)) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public static boolean holdItem(class_310 arg, class_1792 arg2) {
      return holdItem(arg, arg2, true);
   }

   public static boolean holdItem(class_310 arg, class_1792 arg2, boolean bl) {
      class_746 var3 = arg.field_1724;
      if (var3 != null && arg.field_1761 != null && arg.method_1562() != null) {
         if (arg.field_1755 != null) {
            return false;
         }

         class_1661 var4 = var3.method_31548();
         if (isMatchingItem(var4.method_5438(var4.method_67532()), arg2)) {
            return true;
         }

         for (int var5 = 0; var5 < class_1661.method_7368(); var5++) {
            if (isMatchingItem(var4.method_5438(var5), arg2)) {
               selectHotbarSlot(arg, var5);
               return true;
            }
         }

         if (!bl) {
            return false;
         }

         for (int var8 = class_1661.method_7368(); var8 < 36; var8++) {
            if (isMatchingItem(var4.method_5438(var8), arg2)) {
               int var6 = -1;
               if (arg2 == class_1802.field_8705 || arg2 == class_1802.field_8187) {
                  for (int var7 = 0; var7 < class_1661.method_7368(); var7++) {
                     if (var4.method_5438(var7).method_31574(class_1802.field_8550)) {
                        var6 = var7;
                        break;
                     }
                  }
               }

               if (var6 < 0) {
                  var6 = spareHotbarSlot(var4);
               }

               if (var6 < 0) {
                  var6 = findEvictableHotbarSlot(var4);
               }

               if (var6 < 0) {
                  return false;
               }

               if (var3.field_7512 != null && var3.field_7512 != var3.field_7498) {
                  var3.method_7346();
               }

               arg.field_1761.method_2906(0, var8, var6, class_1713.field_7791, var3);
               selectHotbarSlot(arg, var6);
               return isMatchingItem(var4.method_5438(var6), arg2);
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public static boolean ensureHotbarSupplied(class_310 arg, class_1792 arg2) {
      class_746 var2 = arg.field_1724;
      if (var2 != null && arg.field_1761 != null) {
         if (arg.field_1755 != null) {
            return false;
         }

         class_1661 var3 = var2.method_31548();

         for (int var4 = 0; var4 < class_1661.method_7368(); var4++) {
            if (isMatchingItem(var3.method_5438(var4), arg2) && !var3.method_5438(var4).method_7960()) {
               return true;
            }
         }

         int var6 = -1;
         if (arg2 == class_1802.field_8705 || arg2 == class_1802.field_8187) {
            for (int var5 = 0; var5 < class_1661.method_7368(); var5++) {
               if (var5 != var3.method_67532() && var3.method_5438(var5).method_31574(class_1802.field_8550)) {
                  var6 = var5;
                  break;
               }
            }
         }

         if (var6 < 0) {
            var6 = spareHotbarSlot(var3);
         }

         if (var6 < 0) {
            return false;
         }

         for (int var7 = class_1661.method_7368(); var7 < 36; var7++) {
            if (isMatchingItem(var3.method_5438(var7), arg2) && !var3.method_5438(var7).method_7960()) {
               if (var2.field_7512 != null && var2.field_7512 != var2.field_7498) {
                  var2.method_7346();
               }

               arg.field_1761.method_2906(0, var7, var6, class_1713.field_7791, var2);
               return isMatchingItem(var3.method_5438(var6), arg2);
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public static void holdBestTool(class_310 arg, class_2680 arg2) {
      class_746 var2 = arg.field_1724;
      if (var2 != null) {
         class_1661 var3 = var2.method_31548();
         int var4 = -1;
         float var5 = 1.0F;

         for (int var6 = 0; var6 < class_1661.method_7368(); var6++) {
            float var7 = var3.method_5438(var6).method_7924(arg2);
            if (var7 > var5) {
               var5 = var7;
               var4 = var6;
            }
         }

         if (var4 >= 0) {
            selectHotbarSlot(arg, var4);
         }
      }
   }

   public static void selectHotbarSlot(class_310 arg, int i) {
      class_746 var2 = arg.field_1724;
      if (var2 != null) {
         if (var2.method_31548().method_67532() != i) {
            var2.method_31548().method_61496(i);
         }

         if (arg.method_1562() != null) {
            arg.method_1562().method_52787(new class_2868(i));
         }
      }
   }

   public static int spareHotbarSlot(class_1661 arg) {
      int var1 = arg.method_67532();

      for (int var2 = 0; var2 < class_1661.method_7368(); var2++) {
         if (var2 != var1) {
            class_1799 var3 = arg.method_5438(var2);
            if (var3.method_7960()) {
               return var2;
            }
         }
      }

      return -1;
   }

   public static int findInHotbar(class_746 arg, class_1792 arg2) {
      if (arg != null && arg2 != null) {
         class_1661 var2 = arg.method_31548();

         for (int var3 = 0; var3 < class_1661.method_7368(); var3++) {
            if (isMatchingItem(var2.method_5438(var3), arg2) && !var2.method_5438(var3).method_7960()) {
               return var3;
            }
         }

         return -1;
      } else {
         return -1;
      }
   }

   private static int findEvictableHotbarSlot(class_1661 arg) {
      int var1 = arg.method_67532();

      for (int var2 = 0; var2 < class_1661.method_7368(); var2++) {
         if (var2 != var1 && !arg.method_5438(var2).method_7963()) {
            return var2;
         }
      }

      return -1;
   }

   public static int findSafeHotbarSlot(class_746 arg) {
      if (arg == null) {
         return -1;
      }

      class_1661 var1 = arg.method_31548();

      for (int var2 = 0; var2 < class_1661.method_7368(); var2++) {
         class_1799 var3 = var1.method_5438(var2);
         if (var3.method_7960()) {
            return var2;
         }

         class_1792 var4 = var3.method_7909();
         if (var4 != class_1802.field_8535
            && var4 != class_1802.field_8554
            && var4 != class_1802.field_8187
            && (var4 == class_1802.field_20412 || var4 == class_1802.field_8281 || var4 instanceof class_1747)) {
            return var2;
         }
      }

      for (int var5 = 0; var5 < class_1661.method_7368(); var5++) {
         class_1799 var6 = var1.method_5438(var5);
         class_1792 var7 = var6.method_7909();
         if (var7 != class_1802.field_8535 && var7 != class_1802.field_8554 && var7 != class_1802.field_8187) {
            return var5;
         }
      }

      return var1.method_67532();
   }
}
