package com.autobuildfarm.eat;

import baritone.api.BaritoneAPI;
import baritone.api.IBaritone;
import baritone.api.process.IBuilderProcess;
import com.autobuildfarm.AutoBuildFarm;
import com.autobuildfarm.FarmConfig;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_4174;
import net.minecraft.class_9334;

public final class AutoEatController {
   private static final AutoEatController INSTANCE = new AutoEatController();
   private boolean enabled = true;
   private int hungerThreshold = 16;
   private boolean isEating = false;
   private boolean wasBuilderRunning = false;
   private int eatingTicks = 0;
   private int noFoodWarnCooldown = 0;
   private int startAttemptTicks = 0;

   public static AutoEatController getInstance() {
      return INSTANCE;
   }

   private AutoEatController() {
   }

   public boolean isEating() {
      return this.isEating;
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public void setEnabled(boolean bl) {
      this.enabled = bl;
      FarmConfig.autoEatEnabled = bl;
      FarmConfig.save();
      if (!bl && this.isEating) {
         this.stopEating(class_310.method_1551(), "T\u1eaft Auto Eat");
      }
   }

   public int getHungerThreshold() {
      return this.hungerThreshold;
   }

   public void setHungerThreshold(int i) {
      this.hungerThreshold = Math.max(1, Math.min(19, i));
      FarmConfig.autoEatThreshold = this.hungerThreshold;
      FarmConfig.save();
   }

   public boolean tick(class_310 arg) {
      if (this.enabled && arg != null && arg.field_1724 != null && arg.field_1687 != null) {
         if (this.noFoodWarnCooldown > 0) {
            this.noFoodWarnCooldown--;
         }

         if (arg.field_1755 != null) {
            if (this.isEating) {
               if (arg.field_1690 != null && arg.field_1690.field_1904 != null) {
                  arg.field_1690.field_1904.method_23481(false);
               }

               if (arg.field_1761 != null && arg.field_1724.method_6115()) {
                  arg.field_1761.method_2897(arg.field_1724);
               }
            }

            return false;
         } else if (!arg.field_1724.method_5805()) {
            if (this.isEating) {
               this.stopEating(arg, "Ng\u01b0\u1eddi ch\u01a1i \u0111\u00e3 ch\u1ebft");
            }

            return false;
         } else {
            int var2 = arg.field_1724.method_7344().method_7586();
            class_1799 var3 = arg.field_1724.method_6079();
            class_4174 var4 = var3.method_7960() ? null : (class_4174)var3.method_58694(class_9334.field_50075);
            if (this.isEating) {
               this.eatingTicks++;
               boolean var5 = var2 >= 20;
               boolean var6 = arg.field_1724.method_7332(var4 != null && var4.comp_2493());
               boolean var7 = var4 != null && !var3.method_7960();
               if (!var5 && var6 && var7 && this.eatingTicks <= 300) {
                  IBaritone var10 = BaritoneAPI.getProvider().getPrimaryBaritone();
                  if (var10 != null) {
                     var10.getInputOverrideHandler().clearAllKeys();
                  }

                  if (!arg.field_1724.method_6115()) {
                     this.startAttemptTicks++;
                     arg.field_1690.field_1904.method_23481(false);
                     class_1269 var9 = arg.field_1761.method_2919(arg.field_1724, class_1268.field_5810);
                     if (!var9.method_23665() && !arg.field_1724.method_6115()) {
                        if (this.startAttemptTicks > 40) {
                           this.stopEating(arg, "Kh\u00f4ng th\u1ec3 t\u01b0\u01a1ng t\u00e1c d\u00f9ng th\u1ee9c \u0103n (th\u1eed l\u1ea1i sau)");
                           return false;
                        }
                     } else {
                        arg.field_1690.field_1904.method_23481(true);
                        this.startAttemptTicks = 0;
                     }
                  } else {
                     arg.field_1690.field_1904.method_23481(true);
                  }

                  return true;
               } else {
                  String var8;
                  if (var5) {
                     var8 = "\u2714 \u0110\u00e3 \u0103n no ("
                        + var2
                        + "/20 thanh \u0111\u00f3i) \u2014 ti\u1ebfp t\u1ee5c qu\u00e1 tr\u00ecnh x\u00e2y d\u1ef1ng!";
                  } else if (!var7) {
                     var8 = "\u26a0 \u0110\u00e3 h\u1ebft th\u1ee9c \u0103n \u1edf tay ph\u1ee5 \u2014 ti\u1ebfp t\u1ee5c l\u00e0m vi\u1ec7c.";
                  } else if (this.eatingTicks > 300) {
                     var8 = "H\u1ebft th\u1eddi gian ch\u1edd \u0103n (15s timeout) \u2014 ti\u1ebfp t\u1ee5c l\u00e0m vi\u1ec7c.";
                  } else {
                     var8 = "Kh\u00f4ng th\u1ec3 \u0103n th\u00eam \u2014 ti\u1ebfp t\u1ee5c l\u00e0m vi\u1ec7c.";
                  }

                  this.stopEating(arg, var8);
                  return false;
               }
            } else {
               if (var2 > this.hungerThreshold) {
                  return false;
               }

               if (var4 == null) {
                  if (this.noFoodWarnCooldown <= 0) {
                     this.noFoodWarnCooldown = 200;
                     AutoBuildFarm.chat(
                        "\u26a0 Thanh \u0111\u00f3i xu\u1ed1ng c\u00f2n "
                           + var2
                           + "/20 ("
                           + var2 / 2
                           + " c\u1ee5c) nh\u01b0ng tay ph\u1ee5 (off-hand) kh\u00f4ng c\u1ea7m th\u1ee9c \u0103n! H\u00e3y c\u1ea7m th\u1ee9c \u0103n v\u00e0o tay ph\u1ee5."
                     );
                  }

                  return false;
               } else {
                  this.startEating(arg, var3, var2);
                  return true;
               }
            }
         }
      } else {
         if (this.isEating) {
            this.stopEating(arg, "M\u1ea5t k\u1ebft n\u1ed1i ho\u1eb7c player kh\u00f4ng h\u1ee3p l\u1ec7");
         }

         return false;
      }
   }

   private void startEating(class_310 arg, class_1799 arg2, int i) {
      this.isEating = true;
      this.eatingTicks = 0;
      this.startAttemptTicks = 0;
      AutoBuildFarm.chat(
         "Thanh \u0111\u00f3i xu\u1ed1ng c\u00f2n "
            + i
            + "/20 ("
            + i / 2
            + " c\u1ee5c) -> T\u1ea1m d\u1eebng Baritone \u0111\u1ec3 \u0103n "
            + arg2.method_7964().getString()
            + " (tay ph\u1ee5)\u2026"
      );
      IBaritone var4 = BaritoneAPI.getProvider().getPrimaryBaritone();
      if (var4 != null) {
         IBuilderProcess var5 = var4.getBuilderProcess();
         this.wasBuilderRunning = var5 != null && var5.isActive() && !var5.isPaused();
         if (this.wasBuilderRunning) {
            var5.pause();
         }

         var4.getInputOverrideHandler().clearAllKeys();
      }

      if (arg.field_1724.method_6115() && arg.field_1724.method_6058() != class_1268.field_5810) {
         arg.field_1761.method_2897(arg.field_1724);
      }

      arg.field_1690.field_1904.method_23481(false);
      class_1269 var6 = arg.field_1761.method_2919(arg.field_1724, class_1268.field_5810);
      if (var6.method_23665() || arg.field_1724.method_6115()) {
         arg.field_1690.field_1904.method_23481(true);
      }
   }

   private void stopEating(class_310 arg, String string) {
      this.isEating = false;
      this.eatingTicks = 0;
      this.startAttemptTicks = 0;
      if (arg != null && arg.field_1690 != null && arg.field_1690.field_1904 != null) {
         arg.field_1690.field_1904.method_23481(false);
      }

      if (arg != null && arg.field_1761 != null && arg.field_1724 != null && arg.field_1724.method_6115()) {
         arg.field_1761.method_2897(arg.field_1724);
      }

      IBaritone var3 = BaritoneAPI.getProvider().getPrimaryBaritone();
      if (var3 != null && this.wasBuilderRunning) {
         IBuilderProcess var4 = var3.getBuilderProcess();
         if (var4 != null && var4.isActive() && var4.isPaused()) {
            var4.resume();
         }
      }

      this.wasBuilderRunning = false;
      if (string != null && !string.isEmpty()) {
         AutoBuildFarm.chat(string);
      }
   }

   public void abort() {
      if (this.isEating) {
         this.stopEating(class_310.method_1551(), "H\u1ee7y \u0103n do d\u1eebng t\u00e1c v\u1ee5");
      }
   }
}
