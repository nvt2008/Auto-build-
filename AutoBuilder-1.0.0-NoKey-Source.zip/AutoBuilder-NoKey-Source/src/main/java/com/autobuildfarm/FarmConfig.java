package com.autobuildfarm;

import baritone.api.BaritoneAPI;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import net.fabricmc.loader.api.FabricLoader;

public final class FarmConfig {
   private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
   private static final Path CONFIG_PATH = FabricLoader.getInstance().getConfigDir().resolve("autobuildfarm.json");
   public static int placeSpeed = 5;
   public static int leafPlaceSpeed = 8;
   public static float placeReach = 3.8F;
   public static boolean autoEatEnabled = true;
   public static int autoEatThreshold = 16;

   private FarmConfig() {
   }

   public static synchronized void load() {
      try {
         if (!Files.exists(CONFIG_PATH)) {
            save();
            return;
         }

         try (BufferedReader var0 = Files.newBufferedReader(CONFIG_PATH, StandardCharsets.UTF_8)) {
            JsonObject var1 = JsonParser.parseReader(var0).getAsJsonObject();
            if (var1.has("placeSpeed")) {
               placeSpeed = Math.max(0, var1.get("placeSpeed").getAsInt());
            }

            if (var1.has("leafPlaceSpeed")) {
               leafPlaceSpeed = Math.max(1, var1.get("leafPlaceSpeed").getAsInt());
            }

            if (var1.has("placeReach")) {
               placeReach = Math.max(1.5F, Math.min(5.0F, var1.get("placeReach").getAsFloat()));
            }

            if (var1.has("autoEatEnabled")) {
               autoEatEnabled = var1.get("autoEatEnabled").getAsBoolean();
            }

            if (var1.has("autoEatThreshold")) {
               autoEatThreshold = Math.max(1, Math.min(19, var1.get("autoEatThreshold").getAsInt()));
            }
         }
      } catch (Throwable var5) {
         AutoBuildFarm.LOG.warn("Could not load autobuildfarm.json", var5);
      }

      applyToBaritone();
   }

   public static synchronized void save() {
      try {
         Path var0 = CONFIG_PATH.getParent();
         if (var0 != null && !Files.exists(var0)) {
            Files.createDirectories(var0);
         }

         JsonObject var1 = new JsonObject();
         var1.addProperty("placeSpeed", placeSpeed);
         var1.addProperty("leafPlaceSpeed", leafPlaceSpeed);
         var1.addProperty("placeReach", placeReach);
         var1.addProperty("autoEatEnabled", autoEatEnabled);
         var1.addProperty("autoEatThreshold", autoEatThreshold);

         try (BufferedWriter var2 = Files.newBufferedWriter(CONFIG_PATH, StandardCharsets.UTF_8)) {
            GSON.toJson(var1, var2);
         }
      } catch (Throwable var7) {
         AutoBuildFarm.LOG.warn("Could not save autobuildfarm.json", var7);
      }

      syncToBaritoneSettingsFile();
   }

   public static void applyToBaritone() {
      try {
         if (BaritoneAPI.getSettings() != null) {
            if (BaritoneAPI.getSettings().rightClickSpeed != null) {
               BaritoneAPI.getSettings().rightClickSpeed.value = placeSpeed;
            }

            if (BaritoneAPI.getSettings().blockReachDistance != null) {
               BaritoneAPI.getSettings().blockReachDistance.value = placeReach;
            }
         }
      } catch (Throwable var1) {
      }
   }

   public static synchronized void syncToBaritoneSettingsFile() {
      try {
         Path var0 = FabricLoader.getInstance().getGameDir();
         Path var1 = var0.resolve("baritone").resolve("settings.txt");
         if (var1.getParent() != null && !Files.exists(var1.getParent())) {
            Files.createDirectories(var1.getParent());
         }

         ArrayList var2 = Files.exists(var1) ? new ArrayList<>(Files.readAllLines(var1, StandardCharsets.UTF_8)) : new ArrayList();
         boolean var3 = false;

         for (int var4 = 0; var4 < var2.size(); var4++) {
            String var5 = ((String)var2.get(var4)).trim();
            if (var5.startsWith("rightClickSpeed ")) {
               var2.set(var4, "rightClickSpeed " + placeSpeed);
               var3 = true;
               break;
            }
         }

         if (!var3) {
            var2.add("rightClickSpeed " + placeSpeed);
         }

         Files.write(var1, var2, StandardCharsets.UTF_8);
      } catch (Throwable var6) {
      }
   }
}
