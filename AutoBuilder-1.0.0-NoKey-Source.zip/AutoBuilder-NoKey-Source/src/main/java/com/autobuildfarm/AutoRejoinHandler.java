package com.autobuildfarm;

import com.autobuildfarm.litematica.LitematicaBridge;
import com.autobuildfarm.order.BucketDisposal;
import com.autobuildfarm.order.GuiAutomator;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_412;
import net.minecraft.class_419;
import net.minecraft.class_442;
import net.minecraft.class_639;
import net.minecraft.class_642;

public final class AutoRejoinHandler {
   private static final AutoRejoinHandler INSTANCE = new AutoRejoinHandler();
   private AutoRejoinHandler.RejoinState state = AutoRejoinHandler.RejoinState.IDLE;
   private class_642 savedServerInfo;
   private String savedReason;
   private boolean wasBuilding;
   private int savedPlacementIndex = -1;
   private int savedLayerIndex = -1;
   private int ticksInState = 0;
   private long lastTriggerTime = 0L;
   private int connectionRetries = 0;

   public static AutoRejoinHandler getInstance() {
      return INSTANCE;
   }

   private AutoRejoinHandler() {
   }

   public boolean isRejoining() {
      return this.state != AutoRejoinHandler.RejoinState.IDLE;
   }

   public synchronized void trigger(String string) {
      long var2 = System.currentTimeMillis();
      if (this.state == AutoRejoinHandler.RejoinState.IDLE && var2 - this.lastTriggerTime >= 10000L) {
         class_310 var4 = class_310.method_1551();
         if (var4 != null) {
            if (var4.method_1542()) {
               AutoBuildFarm.chat("\u00a7c[AutoRejoin] Ch\u01a1i \u0111\u01a1n (Singleplayer), kh\u00f4ng th\u1ec3 th\u1ef1c hi\u1ec7n rejoin: " + string);
            } else {
               class_642 var5 = var4.method_1558();
               if (var5 == null) {
                  AutoBuildFarm.chat("\u00a7c[AutoRejoin] Kh\u00f4ng t\u00ecm th\u1ea5y th\u00f4ng tin m\u00e1y ch\u1ee7 \u0111\u1ec3 rejoin: " + string);
               } else {
                  this.savedServerInfo = var5;
                  this.savedReason = string;
                  this.lastTriggerTime = var2;
                  this.connectionRetries = 0;
                  this.wasBuilding = FarmBuildController.INSTANCE.getState() != FarmBuildController.State.IDLE;
                  this.savedPlacementIndex = FarmBuildController.INSTANCE.getPlacementIndex();
                  this.savedLayerIndex = FarmBuildController.INSTANCE.getCurrentLayerIndex();
                  AutoBuildFarm.chat("\u00a7c[AutoRejoin] " + string + "!");
                  AutoBuildFarm.chat(
                     "\u00a7e[AutoRejoin] \u0110ang ng\u1eaft k\u1ebft n\u1ed1i v\u00e0 t\u1ef1 \u0111\u1ed9ng k\u1ebft n\u1ed1i l\u1ea1i sau 3 gi\u00e2y\u2026"
                  );
                  DebugLog.line("AUTO_REJOIN triggered: " + string);

                  try {
                     FarmBuildController.INSTANCE.cancel();
                  } catch (Throwable var7) {
                  }

                  GuiAutomator.getInstance().clearQueue();
                  BucketDisposal.getInstance().reset();
                  this.state = AutoRejoinHandler.RejoinState.DISCONNECTING;
                  this.ticksInState = 0;
               }
            }
         }
      }
   }

   public void tick(class_310 arg) {
      if (this.state != AutoRejoinHandler.RejoinState.IDLE && arg != null) {
         this.ticksInState++;
         switch (this.state) {
            case DISCONNECTING:
               if (this.ticksInState >= 2) {
                  try {
                     arg.method_73360(class_2561.method_43470("AutoBuildFarm: Rejoining in 3s... (" + this.savedReason + ")"));
                  } catch (Throwable var7) {
                     DebugLog.line("Disconnect error: " + var7);
                  }

                  this.state = AutoRejoinHandler.RejoinState.WAITING_TO_CONNECT;
                  this.ticksInState = 0;
               }
               break;
            case WAITING_TO_CONNECT:
               if (this.ticksInState >= 60) {
                  if (this.savedServerInfo == null) {
                     this.state = AutoRejoinHandler.RejoinState.IDLE;
                     this.ticksInState = 0;
                     return;
                  }

                  DebugLog.line("Reconnecting to " + this.savedServerInfo.field_3761 + "...");

                  try {
                     class_412.method_36877(new class_442(), arg, class_639.method_2950(this.savedServerInfo.field_3761), this.savedServerInfo, false, null);
                  } catch (Throwable var6) {
                     DebugLog.line("ConnectScreen error: " + var6);
                  }

                  this.state = AutoRejoinHandler.RejoinState.WAITING_WORLD_LOAD;
                  this.ticksInState = 0;
               }
               break;
            case WAITING_WORLD_LOAD:
               if (arg.field_1755 instanceof class_419) {
                  if (this.ticksInState >= 100) {
                     this.connectionRetries++;
                     if (this.connectionRetries <= 3 && this.savedServerInfo != null) {
                        DebugLog.line("Retry reconnecting attempt " + this.connectionRetries + "/3...");

                        try {
                           class_412.method_36877(
                              new class_442(), arg, class_639.method_2950(this.savedServerInfo.field_3761), this.savedServerInfo, false, null
                           );
                        } catch (Throwable var4) {
                           DebugLog.line("Retry connect error: " + var4);
                        }

                        this.ticksInState = 0;
                     } else {
                        AutoBuildFarm.chat(
                           "\u00a7c[AutoRejoin] Kh\u00f4ng th\u1ec3 k\u1ebft n\u1ed1i l\u1ea1i m\u00e1y ch\u1ee7 sau nhi\u1ec1u l\u1ea7n th\u1eed."
                        );
                        this.state = AutoRejoinHandler.RejoinState.IDLE;
                        this.ticksInState = 0;
                     }
                  }

                  return;
               }

               if (arg.field_1687 != null && arg.field_1724 != null && arg.field_1755 == null) {
                  this.state = AutoRejoinHandler.RejoinState.WAITING_STABILIZE;
                  this.ticksInState = 0;
                  FarmConfig.applyToBaritone();
                  AutoBuildFarm.chat(
                     "\u00a7a[AutoRejoin] \u0110\u00e3 k\u1ebft n\u1ed1i l\u1ea1i th\u00e0nh c\u00f4ng! \u0110ang ch\u1edd \u1ed5n \u0111\u1ecbnh (3.5s)\u2026"
                  );
                  return;
               }

               if (this.ticksInState > 600) {
                  AutoBuildFarm.chat("\u00a7c[AutoRejoin] H\u1ebft th\u1eddi gian ch\u1edd t\u1ea3i th\u1ebf gi\u1edbi sau khi k\u1ebft n\u1ed1i.");
                  this.state = AutoRejoinHandler.RejoinState.IDLE;
                  this.ticksInState = 0;
               }
               break;
            case WAITING_STABILIZE:
               if (this.ticksInState >= 70) {
                  this.state = AutoRejoinHandler.RejoinState.IDLE;
                  this.ticksInState = 0;
                  FarmConfig.applyToBaritone();
                  if (this.wasBuilding && arg.field_1724 != null) {
                     AutoBuildFarm.chat(
                        "\u00a7a[AutoRejoin] T\u1ef1 \u0111\u1ed9ng ti\u1ebfp t\u1ee5c ti\u1ebfn tr\u00ecnh x\u00e2y d\u1ef1ng farm"
                           + (this.savedLayerIndex >= 0 ? " t\u1eeb layer " + (this.savedLayerIndex + 1) : "")
                           + "!"
                     );
                     int var2 = this.savedPlacementIndex >= 0 ? this.savedPlacementIndex : LitematicaBridge.getClosestPlacementIndex();

                     try {
                        FarmBuildController.INSTANCE.cancel();
                     } catch (Throwable var5) {
                     }

                     FarmBuildController.INSTANCE.start(var2, this.savedLayerIndex);
                  }
               }
         }
      }
   }

   public enum RejoinState {
      IDLE,
      DISCONNECTING,
      WAITING_TO_CONNECT,
      WAITING_WORLD_LOAD,
      WAITING_STABILIZE;
   }
}
