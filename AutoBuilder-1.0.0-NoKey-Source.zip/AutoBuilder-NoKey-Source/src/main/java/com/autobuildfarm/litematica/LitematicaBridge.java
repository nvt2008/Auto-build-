package com.autobuildfarm.litematica;

import baritone.api.schematic.IStaticSchematic;
import baritone.utils.schematic.litematica.LitematicaHelper;
import com.autobuildfarm.AutoBuildFarm;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_310;
import net.minecraft.class_3545;

public final class LitematicaBridge {
   private LitematicaBridge() {
   }

   public static boolean isLitematicaPresent() {
      try {
         if (FabricLoader.getInstance().isModLoaded("litematica")) {
            return true;
         }
      } catch (Throwable var3) {
      }

      try {
         Class.forName("fi.dy.masa.litematica.data.DataManager");
         return true;
      } catch (Throwable var2) {
         try {
            return LitematicaHelper.isLitematicaPresent();
         } catch (Throwable var1) {
            return false;
         }
      }
   }

   public static boolean hasPlacement(int i) {
      try {
         return LitematicaHelper.hasLoadedSchematic(i);
      } catch (Throwable var2) {
         return false;
      }
   }

   public static int getClosestPlacementIndex() {
      try {
         if (!isLitematicaPresent()) {
            return 0;
         }

         class_310 var0 = class_310.method_1551();
         if (var0 != null && var0.field_1724 != null) {
            class_2338 var1 = var0.field_1724.method_24515();
            Class var2 = Class.forName("fi.dy.masa.litematica.data.DataManager");
            Object var3 = var2.getMethod("getSchematicPlacementManager").invoke(null);
            List var4 = (List)var3.getClass().getMethod("getAllSchematicsPlacements").invoke(var3);
            if (var4 != null && !var4.isEmpty()) {
               int var5 = 0;
               double var6 = Double.MAX_VALUE;

               for (int var8 = 0; var8 < var4.size(); var8++) {
                  Object var9 = var4.get(var8);
                  boolean var10 = true;

                  try {
                     var10 = (Boolean)var9.getClass().getMethod("isEnabled").invoke(var9);
                  } catch (Throwable var15) {
                  }

                  if ((var10 || var4.size() <= 1) && var9.getClass().getMethod("getOrigin").invoke(var9) instanceof class_2338 var12) {
                     double var13 = var12.method_10262(var1);
                     if (var13 < var6) {
                        var6 = var13;
                        var5 = var8;
                     }
                  }
               }

               return var5;
            } else {
               return 0;
            }
         } else {
            return 0;
         }
      } catch (Throwable var16) {
         return 0;
      }
   }

   public static Object getPlacementObject(int i) {
      try {
         Class var1 = Class.forName("fi.dy.masa.litematica.data.DataManager");
         Object var2 = var1.getMethod("getSchematicPlacementManager").invoke(null);
         List var3 = (List)var2.getClass().getMethod("getAllSchematicsPlacements").invoke(var2);
         if (var3 != null && i >= 0 && i < var3.size()) {
            return var3.get(i);
         }
      } catch (Throwable var4) {
      }

      return null;
   }

   public static List<String> getPlacementSummaries() {
      ArrayList var0 = new ArrayList();

      try {
         if (!isLitematicaPresent()) {
            return var0;
         }

         class_310 var1 = class_310.method_1551();
         class_2338 var2 = var1 != null && var1.field_1724 != null ? var1.field_1724.method_24515() : null;
         Class var3 = Class.forName("fi.dy.masa.litematica.data.DataManager");
         Object var4 = var3.getMethod("getSchematicPlacementManager").invoke(null);
         List var5 = (List)var4.getClass().getMethod("getAllSchematicsPlacements").invoke(var4);
         if (var5 != null) {
            for (int var6 = 0; var6 < var5.size(); var6++) {
               Object var7 = var5.get(var6);
               String var8 = (String)var7.getClass().getMethod("getName").invoke(var7);
               boolean var9 = true;
               boolean var10 = true;

               try {
                  var9 = (Boolean)var7.getClass().getMethod("isEnabled").invoke(var7);
               } catch (Throwable var18) {
               }

               try {
                  var10 = (Boolean)var7.getClass().getMethod("isRenderingEnabled").invoke(var7);
               } catch (Throwable var17) {
               }

               Object var11 = null;

               try {
                  var11 = var7.getClass().getMethod("getSchematic").invoke(var7);
               } catch (Throwable var16) {
               }

               Object var12 = var7.getClass().getMethod("getOrigin").invoke(var7);
               String var13 = "";
               if (var2 != null && var12 instanceof class_2338 var14) {
                  int var15 = (int)Math.sqrt(var14.method_10262(var2));
                  if (var15 <= 32) {
                     var13 = " \u2014 c\u00e1ch " + var15 + "m [\u1ede \u0110\u00c2Y]";
                  } else {
                     var13 = " \u2014 c\u00e1ch " + var15 + "m";
                  }
               }

               String var20 = var11 == null ? " \u26a0\ufe0f[TR\u1ed0NG - CH\u01afA N\u1ea0P FILE SCHEMATIC]" : "";
               String var21 = var10 ? "" : ", render=T\u1eaeT";
               var0.add("#" + var6 + ": \"" + var8 + "\" (b\u1eadt=" + (var9 ? "C\u00f3" : "KH\u00d4NG") + var21 + ", origin=" + var12 + var13 + ")" + var20);
            }
         }
      } catch (Throwable var19) {
      }

      return var0;
   }

   public static void printPlacementList() {
      List var0 = getPlacementSummaries();
      if (var0.isEmpty()) {
         AutoBuildFarm.chat("\u2139 Kh\u00f4ng t\u00ecm th\u1ea5y placement n\u00e0o \u0111ang \u0111\u01b0\u1ee3c n\u1ea1p trong Litematica.");
         AutoBuildFarm.chat("\ud83d\udca1 H\u00e3y m\u1edf menu Litematica (ph\u00edm M -> Load Schematics) \u0111\u1ec3 t\u1ea3i file schematic.");
      } else {
         AutoBuildFarm.chat("Danh s\u00e1ch placements trong Litematica (" + var0.size() + "):");

         for (String var2 : var0) {
            AutoBuildFarm.chat("  \u2022 " + var2);
         }
      }
   }

   public static void prepareAndPopulate(Object object, int i) {
      if (object != null) {
         try {
            try {
               Class var2 = Class.forName("fi.dy.masa.litematica.config.Configs$Visuals");
               Object var3 = var2.getField("ENABLE_RENDERING").get(null);
               boolean var4 = (Boolean)var3.getClass().getMethod("getBooleanValue").invoke(var3);
               if (!var4) {
                  var3.getClass().getMethod("setBooleanValue", boolean.class).invoke(var3, true);
                  AutoBuildFarm.chat(
                     "\u2139 \u0110\u00e3 t\u1ef1 \u0111\u1ed9ng B\u1eacT hi\u1ec3n th\u1ecb Litematica (Rendering: ON do ph\u00edm M+R \u0111ang t\u1eaft)."
                  );
               }

               Object var5 = var2.getField("ENABLE_SCHEMATIC_RENDERING").get(null);
               boolean var6 = (Boolean)var5.getClass().getMethod("getBooleanValue").invoke(var5);
               if (!var6) {
                  var5.getClass().getMethod("setBooleanValue", boolean.class).invoke(var5, true);
               }

               Object var7 = var2.getField("ENABLE_SCHEMATIC_BLOCKS").get(null);
               boolean var8 = (Boolean)var7.getClass().getMethod("getBooleanValue").invoke(var7);
               if (!var8) {
                  var7.getClass().getMethod("setBooleanValue", boolean.class).invoke(var7, true);
               }
            } catch (Throwable var25) {
            }

            try {
               boolean var28 = (Boolean)object.getClass().getMethod("isEnabled").invoke(object);
               if (!var28) {
                  object.getClass().getMethod("setEnabled", boolean.class).invoke(object, true);
                  AutoBuildFarm.chat("\u2139 \u0110\u00e3 t\u1ef1 \u0111\u1ed9ng B\u1eacT (Enable) placement #" + i + ".");
               }

               boolean var30 = (Boolean)object.getClass().getMethod("isRenderingEnabled").invoke(object);
               if (!var30) {
                  object.getClass().getMethod("setRenderSchematic", boolean.class).invoke(object, true);
                  AutoBuildFarm.chat("\u2139 \u0110\u00e3 t\u1ef1 \u0111\u1ed9ng B\u1eacT render cho placement #" + i + ".");
               }
            } catch (Throwable var24) {
            }

            try {
               Class var29 = Class.forName("fi.dy.masa.litematica.data.DataManager");
               Object var31 = var29.getMethod("getSchematicPlacementManager").invoke(null);
               if (var31 != null) {
                  for (Method var38 : var31.getClass().getDeclaredMethods()) {
                     if (var38.getName().equals("addTouchedChunksFor") && var38.getParameterCount() == 1) {
                        var38.setAccessible(true);
                        var38.invoke(var31, object);
                        break;
                     }
                  }
               }

               Class var33 = Class.forName("fi.dy.masa.litematica.schematic.placement.SubRegionPlacement$RequiredEnabled");
               Object var35 = var33.getField("PLACEMENT_ENABLED").get(null);
               Set var37 = (Set)object.getClass().getMethod("getTouchedChunks", var33).invoke(object, var35);
               if (var37 != null && !var37.isEmpty()) {
                  Class var39 = Class.forName("fi.dy.masa.litematica.world.SchematicWorldHandler");
                  Object var40 = var39.getMethod("getSchematicWorld").invoke(null);
                  if (var40 != null) {
                     Object var9 = var40.getClass().getMethod("getChunkSource").invoke(var40);
                     Class var10 = Class.forName("fi.dy.masa.litematica.world.ChunkSchematic");
                     Class var11 = Class.forName("fi.dy.masa.litematica.world.ProtoChunkSchematic");
                     Class var12 = Class.forName("fi.dy.masa.litematica.world.ChunkSchematicState");
                     Object var13 = var12.getField("PROTO").get(null);
                     Class var14 = Class.forName("fi.dy.masa.litematica.util.WorldPlacingUtils");
                     Method var15 = null;

                     for (Method var19 : var14.getMethods()) {
                        if (var19.getName().equals("placeToProtoChunk") && var19.getParameterCount() == 3) {
                           var15 = var19;
                           break;
                        }
                     }

                     Constructor var41 = var10.getConstructors()[0];
                     Constructor var42 = var11.getConstructors()[0];

                     for (Object var44 : var37) {
                        Object var20 = var41.newInstance(var40, var44);
                        Object var21 = var42.newInstance(var20);
                        var11.getMethod("setState", var12).invoke(var21, var13);
                        if (var15 != null) {
                           var15.invoke(null, var21, var44, object);
                        }

                        Object var22 = var11.getMethod("getWrapped").invoke(var21);
                        class_1923 var23 = (class_1923)var44;
                        var9.getClass().getMethod("replaceChunk", int.class, int.class, var10).invoke(var9, var23.field_9181, var23.field_9180, var22);
                     }
                  }
               }
            } catch (Throwable var26) {
               AutoBuildFarm.LOG.warn("Could not force-populate Litematica chunks", var26);
            }
         } catch (Throwable var27) {
         }
      }
   }

   public static Optional<LitematicaBridge.Placement> load(int i) {
      if (!isLitematicaPresent()) {
         AutoBuildFarm.chat("\u274c Litematica ch\u01b0a \u0111\u01b0\u1ee3c c\u00e0i \u0111\u1eb7t ho\u1eb7c ch\u01b0a kh\u1edfi t\u1ea1o.");
         return Optional.empty();
      }

      if (!hasPlacement(i)) {
         AutoBuildFarm.chat("\u274c Kh\u00f4ng t\u00ecm th\u1ea5y Litematica placement t\u1ea1i index #" + i + ".");
         printPlacementList();
         return Optional.empty();
      }

      Object var1 = getPlacementObject(i);
      if (var1 != null) {
         Object var2 = null;

         try {
            var2 = var1.getClass().getMethod("getSchematic").invoke(var1);
         } catch (Throwable var7) {
         }

         if (var2 == null) {
            String var9 = "Placement";

            try {
               var9 = (String)var1.getClass().getMethod("getName").invoke(var1);
            } catch (Throwable var5) {
            }

            AutoBuildFarm.chat(
               "\u274c Placement #"
                  + i
                  + " (\""
                  + var9
                  + "\") l\u00e0 v\u00f9ng ch\u1ecdn tr\u1ed1ng (ch\u01b0a c\u00f3 file schematic n\u00e0o \u0111\u01b0\u1ee3c g\u00e1n)!"
            );
            AutoBuildFarm.chat("\ud83d\udca1 H\u01b0\u1edbng d\u1eabn s\u1eeda:");
            AutoBuildFarm.chat("  1. B\u1ea5m ph\u00edm M -> ch\u1ecdn 'Load Schematics'.");
            AutoBuildFarm.chat("  2. Ch\u1ecdn file schematic c\u1ee7a farm (.litematic) r\u1ed3i b\u1ea5m n\u00fat 'Load Schematic'.");
            AutoBuildFarm.chat("  3. Sau \u0111\u00f3 g\u00f5 l\u1ea1i: /buildfarm start " + i);
            printPlacementList();
            return Optional.empty();
         }

         prepareAndPopulate(var1, i);
      }

      try {
         class_3545 var8 = LitematicaHelper.getSchematic(i);
         if (var8 != null && var8.method_15442() != null && var8.method_15441() != null) {
            IStaticSchematic var3 = (IStaticSchematic)var8.method_15442();
            if (var3.widthX() > 0 && var3.heightY() > 0 && var3.lengthZ() > 0) {
               return Optional.of(new LitematicaBridge.Placement(i, var3, (class_2382)var8.method_15441()));
            }

            AutoBuildFarm.chat(
               "\u274c Placement #" + i + " c\u00f3 k\u00edch th\u01b0\u1edbc r\u1ed7ng (" + var3.widthX() + "x" + var3.heightY() + "x" + var3.lengthZ() + ")!"
            );
            AutoBuildFarm.chat(
               "\ud83d\udca1 G\u1ee3i \u00fd: H\u00e3y m\u1edf menu Litematica (ph\u00edm M -> Schematic Placements) v\u00e0 ki\u1ec3m tra placement v\u00e0 c\u00e1c subregion \u0111\u00e3 \u0111\u01b0\u1ee3c B\u1eacT (Enabled: ON) ch\u01b0a."
            );
            printPlacementList();
            return Optional.empty();
         } else {
            AutoBuildFarm.chat("\u274c LitematicaHelper kh\u00f4ng th\u1ec3 \u0111\u1ecdc placement #" + i + ".");
            printPlacementList();
            return Optional.empty();
         }
      } catch (Throwable var6) {
         AutoBuildFarm.LOG.warn("Could not read Litematica placement #" + i, var6);
         AutoBuildFarm.chat("\u274c L\u1ed7i khi \u0111\u1ecdc placement #" + i + ": " + var6.getMessage());
         printPlacementList();
         return Optional.empty();
      }
   }

   public record Placement(int index, IStaticSchematic schematic, class_2382 origin) {
   }
}
