package com.autobuildfarm;

import com.autobuildfarm.command.BuildFarmCommand;
import com.autobuildfarm.eat.AutoEatController;
import com.autobuildfarm.order.RestockController;
import com.autobuildfarm.security.SecurityGuard;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.EndTick;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.AfterInit;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class AutoBuildFarm implements ClientModInitializer {
   public static final String MOD_ID = "autobuildfarm";
   public static final Logger LOG = LoggerFactory.getLogger("AutoBuildFarm");
   private static boolean wasInWorld = false;

   public void onInitializeClient() {
      FarmConfig.load();
      AutoEatController.getInstance().setEnabled(FarmConfig.autoEatEnabled);
      AutoEatController.getInstance().setHungerThreshold(FarmConfig.autoEatThreshold);
      SecurityGuard.verify();
      ClientTickEvents.END_CLIENT_TICK.register((EndTick)arg -> {
         boolean var1 = arg.field_1687 != null && arg.field_1724 != null;
         if (var1 && !wasInWorld) {
            FarmConfig.applyToBaritone();
         }

         wasInWorld = var1;
         SecurityGuard.warnIfNotLicensed();
         AutoRejoinHandler.getInstance().tick(arg);
         FarmBuildController.INSTANCE.onClientTick();
      });
      ClientCommandRegistrationCallback.EVENT
         .register((ClientCommandRegistrationCallback)(commandDispatcher, arg) -> BuildFarmCommand.register(commandDispatcher));
      ScreenEvents.AFTER_INIT.register((AfterInit)(arg, arg2, i, j) -> RestockController.getInstance().onScreenOpen(arg2.method_25440().getString(), arg2));
      LOG.info("Auto Build Farm ready \u2014 /buildfarm");
   }

   public static void chat(String string) {
      DebugLog.line(string);
      class_310 var1 = class_310.method_1551();
      if (var1.field_1724 == null) {
         LOG.info(string);
      } else {
         var1.field_1724
            .method_7353(
               class_2561.method_43470("[AutoBuildFarm] ")
                  .method_27692(class_124.field_1075)
                  .method_10852(class_2561.method_43470(string).method_27692(class_124.field_1068)),
               false
            );
      }
   }
}
