package com.autobuildfarm;

import baritone.api.BaritoneAPI;
import baritone.api.IBaritone;
import baritone.api.Settings;
import baritone.api.behavior.IPathingBehavior;
import baritone.api.pathing.goals.Goal;
import baritone.api.pathing.goals.GoalComposite;
import baritone.api.process.IBaritoneProcess;
import baritone.api.process.IBuilderProcess;
import baritone.api.schematic.IStaticSchematic;
import baritone.api.utils.IInputOverrideHandler;
import baritone.api.utils.input.Input;
import baritone.api.utils.interfaces.IGoalRenderPos;
import com.autobuildfarm.eat.AutoEatController;
import com.autobuildfarm.litematica.LitematicaBridge;
import com.autobuildfarm.order.BucketDisposal;
import com.autobuildfarm.order.GuiAutomator;
import com.autobuildfarm.order.RestockController;
import com.autobuildfarm.place.InventoryHelper;
import com.autobuildfarm.plan.FinishTask;
import com.autobuildfarm.plan.PlanScanner;
import com.autobuildfarm.plan.SkipSchematic;
import com.autobuildfarm.process.FinishProcess;
import com.autobuildfarm.security.SecurityGuard;
import java.lang.reflect.Field;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_239;
import net.minecraft.class_2397;
import net.minecraft.class_2415;
import net.minecraft.class_243;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2769;
import net.minecraft.class_310;
import net.minecraft.class_3486;
import net.minecraft.class_3612;
import net.minecraft.class_3965;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_7923;
import net.minecraft.class_2338.class_2339;
import net.minecraft.class_2350.class_2353;
import net.minecraft.class_239.class_240;

public final class FarmBuildController {
   public static final FarmBuildController INSTANCE = new FarmBuildController();
   private static final int STALL_LIMIT = 1200;
   private static final int BUILD_STALL_REPORT = 60;
   private static final int TRACE_INTERVAL = 20;
   private static final int MAX_RETRY_ROUNDS = 2;
   private static final int MAX_REBUILD_ROUNDS = 6;
   private static final int MAX_FRUITLESS_ROUNDS = 2;
   private static final int FLOAT_CHECK_INTERVAL = 20;
   private static final int FLOAT_CONFIRM_CHECKS = 6;
   private static final int FLOAT_CONFIRM_CHECKS_LOADED = 2;
   private static final int PAUSED_LIMIT = 300;
   private static final int BUILDER_IDLE_CONFIRM = 30;
   private FarmBuildController.State state = FarmBuildController.State.IDLE;
   private FinishProcess finishProcess;
   private IBaritone boundTo;
   private List<FinishTask> plan = List.of();
   private int placementIndex;
   private FarmBuildController.BuildSettingsOverride override;
   private boolean warnedPaused;
   private int pausedTicks;
   private int lastRemaining = -1;
   private int stallTicks;
   private class_2338 lastFeet;
   private int buildStallTicks;
   private int buildStallReports;
   private int traceTicks;
   private int materialCheckTicks;
   private class_2338 lastStationaryPos;
   private int lastPlacedCount;
   private int fastBuildingTicks;
   private final Deque<class_2338> recentBuildPositions = new ArrayDeque<>();
   private int positionSampleTimer;
   private int lastCompletedTasks;
   private int elevatorTicks;
   private class_2338 elevatorTargetPos;
   private final Set<class_2338> skipped = new LinkedHashSet<>();
   private final Set<class_2338> everCorrect = new LinkedHashSet<>();
   private final Map<class_2338, Long> correctSince = new LinkedHashMap<>();
   private Set<class_2338> lastMissingSet = Set.of();
   private int fruitlessRounds;
   private int rollbacksLogged;
   private int rollbacksSeen;
   private static final int ROLLBACK_LOG_LIMIT = 12;
   private static final long SERVER_REJECT_MS = 400L;
   private static final int DIAGNOSE_SAMPLE = 6;
   private static final long DIAGNOSE_INTERVAL_MS = 2000L;
   private long lastDiagnoseMs = 0L;
   private final Set<class_2338> floatSkipped = new LinkedHashSet<>();
   private final Set<class_2338> stuckSkipped = new LinkedHashSet<>();
   private IStaticSchematic schematic;
   private class_2382 origin;
   private int retryRounds;
   private int builderIdleTicks;
   private int floatTicks;
   private class_2338 floatingGoal;
   private int floatingChecks;
   private List<Integer> layerYLevels = List.of();
   private int currentLayerIndex = 0;
   private int currentCeilingY = Integer.MAX_VALUE;
   private int disposalCooldown = 0;
   private int layerFluidsStallTicks = 0;
   private int lastRemainingFluids = -1;
   private int layerFluidsRetryRounds = 0;
   private int consecutiveBlockRollbacks = 0;
   private long lastBlockRollbackTime = 0L;
   private class_2338 lastPlayerStationaryFeet = null;
   private int stationaryTicks = 0;
   private Map<class_1792, Integer> schematicTotalCounts = null;
   private Map<Integer, Integer> structuralBlocksPerLayer = null;
   private final Map<class_1792, Integer> cachedRemainingCounts = new HashMap<>();
   private long lastRemainingScanTime = 0L;
   private Set<class_1792> cachedRequiredItems = null;
   private static final double SCAFFOLD_PENALTY = 35.0;

   public FarmBuildController.State getState() {
      return this.state;
   }

   public int getPlacementIndex() {
      return this.placementIndex;
   }

   public int getCurrentCeilingY() {
      return this.currentCeilingY;
   }

   public int getCurrentLayerIndex() {
      return this.currentLayerIndex;
   }

   public int findFirstIncompleteLayerIndex() {
      if (this.schematic != null && this.origin != null && this.layerYLevels != null && !this.layerYLevels.isEmpty()) {
         for (int var1 = 0; var1 < this.layerYLevels.size(); var1++) {
            int var2 = this.layerYLevels.get(var1);
            List var3 = this.missingPositionsOnLayer(var2);
            if (!var3.isEmpty()) {
               return var1;
            }

            if (this.finishProcess != null && this.finishProcess.hasWorkAtOrBelow(var2)) {
               return var1;
            }
         }

         return 0;
      } else {
         return 0;
      }
   }

   private FarmBuildController() {
   }

   public void start(int i) {
      this.start(i, -1);
   }

   public void start(int i, int j) {
      if (!SecurityGuard.isLicensed()) {
         AutoBuildFarm.chat("\u00a7c" + SecurityGuard.getLicenseStatusMessage());
      } else {
         IBaritone var3 = baritone();
         if (this.state != FarmBuildController.State.IDLE) {
            if (j < 0) {
               AutoBuildFarm.chat("Already running (" + this.state + "). Use /buildfarm cancel first.");
               return;
            }

            this.cancel();
         }

         if (var3 == null) {
            AutoBuildFarm.chat("Baritone is not available.");
         } else {
            try {
               if (!LitematicaBridge.isLitematicaPresent()) {
                  AutoBuildFarm.chat("Litematica is not installed \u2014 nothing to read a placement from.");
                  return;
               }

               Optional var4 = LitematicaBridge.load(i);
               if (var4.isEmpty()) {
                  return;
               }

               this.placementIndex = i;
               DebugLog.begin("/buildfarm start " + i);
               this.schematic = ((LitematicaBridge.Placement)var4.get()).schematic();
               this.invalidateCaches();
               this.origin = ((LitematicaBridge.Placement)var4.get()).origin();
               this.plan = PlanScanner.scan(this.schematic, this.origin);
               this.layerYLevels = collectLayers(this.schematic, this.origin, this.plan);
               int var5 = this.countTotalBlocks();
               AutoBuildFarm.chat(
                  "N\u1ea1p placement #"
                     + i
                     + ": "
                     + this.schematic.widthX()
                     + "x"
                     + this.schematic.heightY()
                     + "x"
                     + this.schematic.lengthZ()
                     + " ("
                     + var5
                     + " kh\u1ed1i khung, "
                     + this.plan.size()
                     + " fluid/redstone, "
                     + this.layerYLevels.size()
                     + " layers)"
               );
               if (var5 == 0 && this.plan.isEmpty()) {
                  AutoBuildFarm.chat("\u274c Placement #" + i + " kh\u00f4ng c\u00f3 b\u1ea5t k\u1ef3 kh\u1ed1i n\u00e0o c\u1ea7n x\u00e2y d\u1ef1ng!");
                  class_310 var15 = class_310.method_1551();
                  if (var15 != null && var15.field_1724 != null && this.origin != null) {
                     double var16 = Math.sqrt(var15.field_1724.method_5649(this.origin.method_10263(), this.origin.method_10264(), this.origin.method_10260()));
                     if (var16 > 128.0) {
                        int var21 = LitematicaBridge.getClosestPlacementIndex();
                        AutoBuildFarm.chat("\u26a0\ufe0f B\u1ea1n \u0111ang c\u00e1ch v\u1ecb tr\u00ed placement #" + i + " t\u1edbi " + (int)var16 + "m!");
                        AutoBuildFarm.chat(
                           "\u2139 Litematica ch\u1ec9 t\u1ea3i kh\u1ed1i trong t\u1ea7m nh\u00ecn ng\u01b0\u1eddi ch\u01a1i (render distance) n\u00ean schematic \u1edf xa b\u1ecb r\u1ed7ng."
                        );
                        if (var21 != i) {
                           AutoBuildFarm.chat(
                              "\ud83d\udc49 Placement g\u1ea7n b\u1ea1n nh\u1ea5t l\u00e0 #" + var21 + ". D\u00f9ng l\u1ec7nh: /buildfarm start " + var21
                           );
                        }
                     }
                  }

                  AutoBuildFarm.chat("\ud83d\udca1 H\u01b0\u1edbng d\u1eabn ki\u1ec3m tra l\u1ea1i Litematica:");
                  AutoBuildFarm.chat("  \u2022 B\u1ea5m ph\u00edm M+R \u0111\u1ec3 ch\u1eafc ch\u1eafn \u0111\u00e3 B\u1eacT hi\u1ec3n th\u1ecb schematic.");
                  AutoBuildFarm.chat(
                     "  \u2022 B\u1ea5m ph\u00edm M -> 'Schematic Placements': Ki\u1ec3m tra placement #"
                        + i
                        + " \u0111\u00e3 b\u1eadt Enabled v\u00e0 Render ch\u01b0a."
                  );
                  AutoBuildFarm.chat(
                     "  \u2022 N\u1ebfu placement l\u00e0 'Unnamed' ho\u1eb7c r\u1ed7ng: H\u00e3y v\u00e0o 'Load Schematics' \u0111\u1ec3 t\u1ea3i \u0111\u00fang file .litematic c\u1ee7a farm."
                  );
                  LitematicaBridge.printPlacementList();
                  this.state = FarmBuildController.State.IDLE;
                  return;
               }

               if (this.layerYLevels.isEmpty()) {
                  AutoBuildFarm.chat("\u274c Kh\u00f4ng t\u00ecm th\u1ea5y layer n\u00e0o ch\u1ee9a block c\u1ea7n \u0111\u1eb7t trong placement #" + i + "!");
                  LitematicaBridge.printPlacementList();
                  this.state = FarmBuildController.State.IDLE;
                  return;
               }

               AutoBuildFarm.chat("Plan: " + PlanScanner.describe(this.plan));
               this.reportBucketBudget();
               this.override = FarmBuildController.BuildSettingsOverride.apply(this.plan);
               this.warnedPaused = false;
               this.pausedTicks = 0;
               this.lastRemaining = -1;
               this.stallTicks = 0;
               this.lastFeet = null;
               this.buildStallTicks = 0;
               this.buildStallReports = 0;
               this.traceTicks = 0;
               this.materialCheckTicks = 0;
               this.lastStationaryPos = null;
               this.lastPlacedCount = 0;
               this.lastCompletedTasks = 0;
               this.elevatorTicks = 0;
               this.elevatorTargetPos = null;
               RestockController.getInstance().clearFailureCooldowns();
               this.skipped.clear();
               this.lastMissingSet = Set.of();
               this.fruitlessRounds = 0;
               this.everCorrect.clear();
               this.correctSince.clear();
               this.rollbacksSeen = 0;
               this.rollbacksLogged = 0;
               this.floatSkipped.clear();
               this.stuckSkipped.clear();
               this.floatTicks = 0;
               this.floatingGoal = null;
               this.floatingChecks = 0;
               this.retryRounds = 0;
               this.builderIdleTicks = 0;
               if (j >= 0 && j < this.layerYLevels.size()) {
                  this.currentLayerIndex = j;
                  AutoBuildFarm.chat(
                     "Ti\u1ebfp t\u1ee5c t\u1eeb layer "
                        + (this.currentLayerIndex + 1)
                        + "/"
                        + this.layerYLevels.size()
                        + " (Y="
                        + this.layerYLevels.get(this.currentLayerIndex)
                        + ")\u2026"
                  );
               } else {
                  this.currentLayerIndex = this.findFirstIncompleteLayerIndex();
                  if (this.currentLayerIndex > 0) {
                     AutoBuildFarm.chat(
                        "\u2714 Ph\u00e1t hi\u1ec7n c\u00e1c t\u1ea7ng 1 \u2192 "
                           + this.currentLayerIndex
                           + " \u0111\u00e3 xong! T\u1ef1 \u0111\u1ed9ng b\u1ecf qua v\u00e0 b\u1eaft \u0111\u1ea7u t\u1eeb layer "
                           + (this.currentLayerIndex + 1)
                           + "/"
                           + this.layerYLevels.size()
                           + " (Y="
                           + this.layerYLevels.get(this.currentLayerIndex)
                           + ")\u2026"
                     );
                  }
               }

               this.currentCeilingY = this.layerYLevels.get(this.currentLayerIndex);
               ArrayList var6 = new ArrayList();
               class_746 var7 = class_310.method_1551().field_1724;
               if (var7 != null) {
                  LinkedHashSet var8 = new LinkedHashSet();

                  for (RestockController.QuotaEntry var10 : RestockController.TARGET_ITEMS) {
                     var8.add(var10.item());
                     if (var10.item() != class_1802.field_8187) {
                        if (var10.item() == class_1802.field_20412) {
                           int var11 = InventoryHelper.count(var7, var10.item());
                           if (!RestockController.isQuotaSatisfied(var10.item(), var11)) {
                              var6.add(var10.item());
                           }
                        } else {
                           int var24 = this.countTotalNeeded(var10.item());
                           if (var24 != 0) {
                              int var12 = this.countRemainingNeeded(var10.item());
                              if (var12 != 0) {
                                 int var13 = InventoryHelper.count(var7, var10.item());
                                 if (!RestockController.isQuotaSatisfied(var10.item(), var13)) {
                                    var6.add(var10.item());
                                 }
                              }
                           }
                        }
                     }
                  }

                  for (class_1792 var22 : this.getRequiredItemsInSchematic()) {
                     if (!var8.contains(var22)) {
                        int var25 = this.countRemainingNeeded(var22);
                        if (var25 != 0) {
                           int var27 = InventoryHelper.count(var7, var22);
                           if (!RestockController.isQuotaSatisfied(var22, var27)) {
                              var6.add(var22);
                           }
                        }
                     }
                  }
               }

               class_310 var17 = class_310.method_1551();
               if (var17 != null && var17.method_1542()) {
                  AutoBuildFarm.chat(
                     "Ch\u1ebf \u0111\u1ed9 Singleplayer: B\u1ecf qua ki\u1ec3m tra /order, b\u1eaft \u0111\u1ea7u x\u00e2y d\u1ef1ng ngay\u2026"
                  );
                  this.state = FarmBuildController.State.BUILDING;
                  FinishProcess var20 = this.ensureProcess(var3);
                  var20.start(new ArrayList<>(this.plan), this::onFinishingDone);
                  var20.resumeOpportunistic(this.currentCeilingY);
                  this.issueBuild(var3);
                  AutoBuildFarm.chat(
                     "Building placement #"
                        + i
                        + " \u2014 layer "
                        + (this.currentLayerIndex + 1)
                        + "/"
                        + this.layerYLevels.size()
                        + " (Y="
                        + this.currentCeilingY
                        + ")"
                        + this.layerSummary(this.currentCeilingY)
                        + " v\u1edbi Baritone\u2026"
                  );
                  AutoBuildFarm.chat("Debug log: " + DebugLog.location());
                  return;
               }

               if (!var6.isEmpty()) {
                  this.state = FarmBuildController.State.INITIAL_RESTOCK;
                  AutoBuildFarm.chat(
                     "Ki\u1ec3m tra nguy\u00ean li\u1ec7u: B\u1eaft \u0111\u1ea7u m\u1edf /order \u0111\u1ec3 l\u1ea5y \u0111\u1ee7 tr\u01b0\u1edbc khi x\u00e2y d\u1ef1ng ("
                        + var6.size()
                        + " lo\u1ea1i c\u1ea7n b\u1ed5 sung)\u2026"
                  );
                  DebugLog.detail("c\u1ea7n b\u1ed5 sung: " + var6);
                  RestockController.getInstance()
                     .startRestockSequence(
                        var6,
                        () -> {
                           ArrayList var4x = new ArrayList();
                           class_310 var5x = class_310.method_1551();
                           if (var5x != null && var5x.field_1724 != null) {
                              for (class_1792 var7x : var6) {
                                 if (InventoryHelper.count(var5x.field_1724, var7x) == 0) {
                                    var4x.add(var7x);
                                 }
                              }
                           }

                           if (var4x.isEmpty()) {
                              AutoBuildFarm.chat(
                                 "\u2714 \u0110\u00e3 chu\u1ea9n b\u1ecb xong to\u00e0n b\u1ed9 nguy\u00ean li\u1ec7u t\u1eeb /order! B\u1eaft \u0111\u1ea7u x\u00e2y d\u1ef1ng placement #"
                                    + i
                                    + "\u2026"
                              );
                           } else {
                              AutoBuildFarm.chat(
                                 "\u00a7eV\u1eabn thi\u1ebfu h\u1eb3n "
                                    + var4x.size()
                                    + " lo\u1ea1i sau khi ch\u1ea1y /order \u2014 x\u00e2y d\u1ef1ng s\u1ebd b\u1ecf qua c\u00e1c kh\u1ed1i \u0111\u00f3."
                              );
                              DebugLog.detail("v\u1eabn thi\u1ebfu h\u1eb3n sau /order: " + var4x);
                           }

                           this.state = FarmBuildController.State.BUILDING;
                           FinishProcess var9 = this.ensureProcess(var3);
                           var9.start(new ArrayList<>(this.plan), this::onFinishingDone);
                           var9.resumeOpportunistic(this.currentCeilingY);
                           if (var5x != null && var5x.field_1724 != null) {
                              for (class_1792 var8x : this.getRequiredItemsInSchematic()) {
                                 InventoryHelper.ensureHotbarSupplied(var5x, var8x);
                              }

                              InventoryHelper.ensureHotbarSupplied(var5x, class_1802.field_20412);
                              InventoryHelper.ensureHotbarSupplied(var5x, class_1802.field_8705);
                           }

                           this.issueBuild(var3);
                           AutoBuildFarm.chat(
                              "Building placement #"
                                 + i
                                 + " \u2014 layer "
                                 + (this.currentLayerIndex + 1)
                                 + "/"
                                 + this.layerYLevels.size()
                                 + " (Y="
                                 + this.currentCeilingY
                                 + ")"
                                 + this.layerSummary(this.currentCeilingY)
                                 + " v\u1edbi Baritone\u2026"
                           );
                        }
                     );
               } else {
                  this.state = FarmBuildController.State.BUILDING;
                  FinishProcess var19 = this.ensureProcess(var3);
                  var19.start(new ArrayList<>(this.plan), this::onFinishingDone);
                  var19.resumeOpportunistic(this.currentCeilingY);

                  for (class_1792 var26 : this.getRequiredItemsInSchematic()) {
                     InventoryHelper.ensureHotbarSupplied(var17, var26);
                  }

                  InventoryHelper.ensureHotbarSupplied(var17, class_1802.field_20412);
                  InventoryHelper.ensureHotbarSupplied(var17, class_1802.field_8705);
                  this.issueBuild(var3);
                  AutoBuildFarm.chat(
                     "\u0110\u00e3 c\u00f3 \u0111\u1ee7 nguy\u00ean li\u1ec7u theo \u0111\u1ecbnh m\u1ee9c! B\u1eaft \u0111\u1ea7u x\u00e2y d\u1ef1ng placement #"
                        + i
                        + " \u2014 layer "
                        + (this.currentLayerIndex + 1)
                        + "/"
                        + this.layerYLevels.size()
                        + " (Y="
                        + this.currentCeilingY
                        + ")"
                        + this.layerSummary(this.currentCeilingY)
                        + " v\u1edbi Baritone\u2026"
                  );
               }

               AutoBuildFarm.chat("Debug log: " + DebugLog.location());
            } catch (Throwable var14) {
               AutoBuildFarm.chat("\u00a7cL\u1ed7i /buildfarm start: " + var14);
               DebugLog.line("CRASH in start(): " + var14);
               var14.printStackTrace();
            }
         }
      }
   }

   public void resumeFinish() {
      if (!SecurityGuard.isLicensed()) {
         AutoBuildFarm.chat("\u00a7c" + SecurityGuard.getLicenseStatusMessage());
      } else {
         IBaritone var1 = baritone();
         if (var1 != null && var1.getBuilderProcess().isActive() && var1.getBuilderProcess().isPaused()) {
            AutoBuildFarm.chat("Ti\u1ebfp t\u1ee5c ti\u1ebfn tr\u00ecnh x\u00e2y d\u1ef1ng c\u1ee7a Baritone (#resume)\u2026");
            var1.getBuilderProcess().resume();
         } else if (this.state == FarmBuildController.State.BUILDING) {
            if (var1 != null) {
               this.issueBuild(var1);
            }
         } else if (this.state != FarmBuildController.State.IDLE) {
            AutoBuildFarm.chat("Already running (" + this.state + ").");
         } else {
            if (this.schematic == null || this.origin == null) {
               Optional var2 = LitematicaBridge.load(this.placementIndex);
               if (!var2.isPresent()) {
                  AutoBuildFarm.chat("No active farm build to resume. Use /buildfarm start <index>.");
                  return;
               }

               this.schematic = ((LitematicaBridge.Placement)var2.get()).schematic();
               this.invalidateCaches();
               this.origin = ((LitematicaBridge.Placement)var2.get()).origin();
            }

            DebugLog.begin("/buildfarm resume");
            this.beginFinishing();
         }
      }
   }

   public void cancel() {
      IBaritone var1 = baritone();
      if (var1 != null) {
         var1.getBuilderProcess().onLostControl();
      }

      if (this.finishProcess != null) {
         this.finishProcess.abort("cancelled");
      }

      BucketDisposal.getInstance().reset();
      AutoEatController.getInstance().abort();
      this.disposalCooldown = 0;
      this.elevatorTicks = 0;
      this.elevatorTargetPos = null;
      this.lastCompletedTasks = 0;
      GuiAutomator.getInstance().clearQueue();
      this.restoreSettings();
      this.skipped.clear();
      this.floatSkipped.clear();
      this.stuckSkipped.clear();
      this.state = FarmBuildController.State.IDLE;
      this.layerYLevels = List.of();
      this.currentLayerIndex = 0;
      this.currentCeilingY = Integer.MAX_VALUE;
      this.invalidateCaches();
      AutoBuildFarm.chat("Cancelled.");
   }

   public synchronized void invalidateCaches() {
      this.schematicTotalCounts = null;
      this.structuralBlocksPerLayer = null;
      this.cachedRequiredItems = null;
      this.cachedRemainingCounts.clear();
      this.lastRemainingScanTime = 0L;
   }

   private synchronized void computeSchematicTotals() {
      if (this.schematic == null) {
         this.schematicTotalCounts = Collections.emptyMap();
         this.structuralBlocksPerLayer = Collections.emptyMap();
         this.cachedRequiredItems = Collections.emptySet();
      } else {
         HashMap var1 = new HashMap();
         HashMap var2 = new HashMap();
         LinkedHashSet var3 = new LinkedHashSet();

         for (int var4 = 0; var4 < this.schematic.heightY(); var4++) {
            int var5 = 0;

            for (int var6 = 0; var6 < this.schematic.widthX(); var6++) {
               for (int var7 = 0; var7 < this.schematic.lengthZ(); var7++) {
                  class_2680 var8 = this.schematic.getDirect(var6, var4, var7);
                  if (var8 != null && !var8.method_26215()) {
                     class_2248 var9 = var8.method_26204();
                     if (var9 != class_2246.field_10382
                        && var9 != class_2246.field_10164
                        && var9 != class_2246.field_10243
                        && var9 != class_2246.field_10543
                        && var9 != class_2246.field_10369) {
                        var5++;
                        class_1792 var10;
                        if (SkipSchematic.isIce(var9)) {
                           var10 = class_1802.field_8410;
                        } else {
                           var10 = var9.method_8389();
                        }

                        if (var10 != class_1802.field_8162) {
                           var1.merge(var10, 1, Integer::sum);
                           var3.add(var10);
                        }
                     }
                  }
               }
            }

            if (var5 > 0 && this.origin != null) {
               var2.put(this.origin.method_10264() + var4, var5);
            }
         }

         this.schematicTotalCounts = Collections.unmodifiableMap(var1);
         this.structuralBlocksPerLayer = Collections.unmodifiableMap(var2);
         this.cachedRequiredItems = Collections.unmodifiableSet(var3);
      }
   }

   public synchronized Map<class_1792, Integer> computeRemainingCounts(boolean bl) {
      long var2 = System.currentTimeMillis();
      if (!bl && var2 - this.lastRemainingScanTime < 2000L && !this.cachedRemainingCounts.isEmpty()) {
         return this.cachedRemainingCounts;
      }

      if (this.schematic != null && this.origin != null) {
         class_310 var4 = class_310.method_1551();
         if (var4 != null && var4.field_1687 != null) {
            class_638 var5 = var4.field_1687;
            HashMap var6 = new HashMap();
            class_2339 var7 = new class_2339();

            for (int var8 = 0; var8 < this.schematic.heightY(); var8++) {
               for (int var9 = 0; var9 < this.schematic.widthX(); var9++) {
                  for (int var10 = 0; var10 < this.schematic.lengthZ(); var10++) {
                     class_2680 var11 = this.schematic.getDirect(var9, var8, var10);
                     if (var11 != null && !var11.method_26215()) {
                        class_2248 var12 = var11.method_26204();
                        if (var12 != class_2246.field_10382
                           && var12 != class_2246.field_10164
                           && var12 != class_2246.field_10243
                           && var12 != class_2246.field_10543
                           && var12 != class_2246.field_10369) {
                           var7.method_10103(this.origin.method_10263() + var9, this.origin.method_10264() + var8, this.origin.method_10260() + var10);
                           class_2680 var13 = var5.method_8320(var7);
                           boolean var14 = SkipSchematic.isIce(var12) || SkipSchematic.isGlass(var12);
                           if (var14) {
                              if (!SkipSchematic.isGlass(var13.method_26204())) {
                                 var6.merge(class_1802.field_8410, 1, Integer::sum);
                              }
                           } else {
                              class_1792 var15 = var12.method_8389();
                              if (var15 != class_1802.field_8162 && var13.method_26204().method_8389() != var15) {
                                 var6.merge(var15, 1, Integer::sum);
                              }
                           }
                        }
                     }
                  }
               }
            }

            this.cachedRemainingCounts.clear();
            this.cachedRemainingCounts.putAll(var6);
            this.lastRemainingScanTime = var2;
            return this.cachedRemainingCounts;
         } else {
            return Collections.emptyMap();
         }
      } else {
         return Collections.emptyMap();
      }
   }

   public int countTotalBlocks() {
      if (this.schematic == null) {
         return 0;
      }

      if (this.schematicTotalCounts == null) {
         this.computeSchematicTotals();
      }

      int var1 = 0;

      for (int var3 : this.schematicTotalCounts.values()) {
         var1 += var3;
      }

      return var1;
   }

   public Set<class_1792> getRequiredItemsInSchematic() {
      if (this.cachedRequiredItems != null) {
         return this.cachedRequiredItems;
      }

      if (this.schematic == null) {
         return Collections.emptySet();
      }

      if (this.schematicTotalCounts == null) {
         this.computeSchematicTotals();
      }

      return this.cachedRequiredItems;
   }

   private List<class_2338> missingPositionsOnLayer(int i) {
      if (this.schematic != null && this.origin != null) {
         class_310 var2 = class_310.method_1551();
         if (var2 != null && var2.field_1687 != null) {
            class_638 var3 = var2.field_1687;
            int var4 = i - this.origin.method_10264();
            if (var4 >= 0 && var4 < this.schematic.heightY()) {
               ArrayList var5 = new ArrayList();

               for (int var6 = 0; var6 < this.schematic.widthX(); var6++) {
                  for (int var7 = 0; var7 < this.schematic.lengthZ(); var7++) {
                     class_2680 var8 = this.schematic.getDirect(var6, var4, var7);
                     if (var8 != null && !var8.method_26215()) {
                        class_2248 var9 = var8.method_26204();
                        if (var9 != class_2246.field_10382
                           && var9 != class_2246.field_10164
                           && var9 != class_2246.field_10243
                           && var9 != class_2246.field_10543
                           && var9 != class_2246.field_10369) {
                           class_2338 var10 = new class_2338(this.origin.method_10263() + var6, i, this.origin.method_10260() + var7);
                           class_2680 var11 = var3.method_8320(var10);
                           boolean var12 = SkipSchematic.isIce(var9) ? SkipSchematic.isGlass(var11.method_26204()) : var11.method_26204() == var9;
                           if (var12) {
                              this.everCorrect.add(var10.method_10062());
                           } else {
                              var5.add(var10);
                           }
                        }
                     }
                  }
               }

               return var5;
            } else {
               return List.of();
            }
         } else {
            return List.of();
         }
      } else {
         return List.of();
      }
   }

   private void watchPlacements() {
      if (this.schematic != null && this.origin != null) {
         class_310 var1 = class_310.method_1551();
         if (var1 != null && var1.field_1687 != null) {
            int var2 = this.currentCeilingY - this.origin.method_10264();
            if (var2 >= 0 && var2 < this.schematic.heightY()) {
               long var3 = System.currentTimeMillis();
               class_2339 var5 = new class_2339();

               for (int var6 = 0; var6 < this.schematic.widthX(); var6++) {
                  for (int var7 = 0; var7 < this.schematic.lengthZ(); var7++) {
                     class_2680 var8 = this.schematic.getDirect(var6, var2, var7);
                     if (var8 != null && !var8.method_26215()) {
                        class_2248 var9 = var8.method_26204();
                        if (var9 != class_2246.field_10382
                           && var9 != class_2246.field_10164
                           && var9 != class_2246.field_10243
                           && var9 != class_2246.field_10543
                           && var9 != class_2246.field_10369) {
                           var5.method_10103(this.origin.method_10263() + var6, this.currentCeilingY, this.origin.method_10260() + var7);
                           class_2680 var10 = var1.field_1687.method_8320(var5);
                           boolean var11 = SkipSchematic.isIce(var9) ? SkipSchematic.isGlass(var10.method_26204()) : var10.method_26204() == var9;
                           if (var11) {
                              this.correctSince.putIfAbsent(var5.method_10062(), var3);
                           } else {
                              Long var12 = this.correctSince.remove(var5);
                              if (var12 != null) {
                                 long var13 = var3 - var12;
                                 this.rollbacksSeen++;
                                 if (this.rollbacksLogged++ < 12) {
                                    DebugLog.detail(
                                       (var13 < 400L ? "SERVER REJECTED " : "removed ")
                                          + var9.method_8389()
                                          + " @"
                                          + var5.method_10263()
                                          + ","
                                          + var5.method_10264()
                                          + ","
                                          + var5.method_10260()
                                          + " after "
                                          + var13
                                          + "ms \u2014 now "
                                          + var10.method_26204().method_8389()
                                    );
                                 }

                                 if (var13 < 5000L) {
                                    if (var3 - this.lastBlockRollbackTime < 10000L) {
                                       this.consecutiveBlockRollbacks++;
                                    } else {
                                       this.consecutiveBlockRollbacks = 1;
                                    }

                                    this.lastBlockRollbackTime = var3;
                                    AutoBuildFarm.chat(
                                       "\u00a7e[C\u1ea3nh b\u00e1o] Kh\u00f4ng \u0111\u1eb7t \u0111\u01b0\u1ee3c block @"
                                          + var5.method_10263()
                                          + ","
                                          + var5.method_10264()
                                          + ","
                                          + var5.method_10260()
                                          + " (b\u1ecb bi\u1ebfn m\u1ea5t/ho\u00e0n t\u00e1c "
                                          + this.consecutiveBlockRollbacks
                                          + "/5)!"
                                    );
                                    if (this.consecutiveBlockRollbacks >= 5) {
                                       this.consecutiveBlockRollbacks = 0;
                                       AutoBuildFarm.chat(
                                          "\u00a7cKh\u00f4ng \u0111\u1eb7t \u0111\u01b0\u1ee3c block sau 5 l\u1ea7n -> K\u00edch ho\u1ea1t Auto Rejoin\u2026"
                                       );
                                       AutoRejoinHandler.getInstance().trigger("Kh\u00f4ng \u0111\u1eb7t \u0111\u01b0\u1ee3c block sau 5 l\u1ea7n");
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private void diagnoseMissing(int i, List<class_2338> list) {
      long var3 = System.currentTimeMillis();
      if (var3 - this.lastDiagnoseMs >= 2000L) {
         this.lastDiagnoseMs = var3;
         class_310 var5 = class_310.method_1551();
         if (var5 != null && var5.field_1687 != null && var5.field_1724 != null) {
            class_243 var6 = var5.field_1724.method_33571();
            DebugLog.detail("why Y=" + i + " is incomplete (" + list.size() + " block(s)):");
            int var7 = 0;

            for (class_2338 var9 : list) {
               if (var7++ >= 6) {
                  DebugLog.detail("    \u2026 and " + (list.size() - 6) + " more");
                  break;
               }

               class_2680 var10 = this.desiredStateAt(var9);
               class_2248 var11 = var10 == null ? null : var10.method_26204();
               class_1792 var12 = var11 == null ? null : (SkipSchematic.isIce(var11) ? class_1802.field_8410 : var11.method_8389());
               int var13 = var12 != null && var12 != class_1802.field_8162 ? InventoryHelper.count(var5.field_1724, var12) : -1;
               double var14 = var6.method_1022(class_243.method_24953(var9));
               StringBuilder var16 = new StringBuilder("    ");
               var16.append(var9.method_10263())
                  .append(',')
                  .append(var9.method_10264())
                  .append(',')
                  .append(var9.method_10260())
                  .append(" want=")
                  .append(var11 == null ? "?" : var11.method_8389())
                  .append(" now=")
                  .append(var5.field_1687.method_8320(var9).method_26204().method_8389())
                  .append(" have=")
                  .append(var13)
                  .append(" dist=")
                  .append(String.format("%.2f", var14))
                  .append(" face=")
                  .append(hasFaceToPlaceAgainst(var9) ? "yes" : "no");
               if (this.skipped.contains(var9)) {
                  var16.append(" hidden");
               }

               if (this.everCorrect.contains(var9)) {
                  var16.append(" ROLLBACK(was placed, gone again)");
               }

               DebugLog.detail(var16.toString());
            }
         }
      }
   }

   private boolean layerHasStructuralBlocks(int i) {
      if (this.structuralBlocksPerLayer == null) {
         this.computeSchematicTotals();
      }

      return this.structuralBlocksPerLayer.getOrDefault(i, 0) > 0;
   }

   private class_2680 desiredStateAt(class_2338 arg) {
      if (this.schematic != null && this.origin != null) {
         int var2 = arg.method_10263() - this.origin.method_10263();
         int var3 = arg.method_10264() - this.origin.method_10264();
         int var4 = arg.method_10260() - this.origin.method_10260();
         return var2 >= 0 && var3 >= 0 && var4 >= 0 && var2 < this.schematic.widthX() && var3 < this.schematic.heightY() && var4 < this.schematic.lengthZ()
            ? this.schematic.getDirect(var2, var3, var4)
            : null;
      } else {
         return null;
      }
   }

   public boolean isWaterlogDesired(class_2338 arg) {
      class_2680 var2 = this.desiredStateAt(arg);
      return var2 != null && var2.method_28498(class_2741.field_12508) && (Boolean)var2.method_11654(class_2741.field_12508);
   }

   public boolean isLayerStructureComplete(int i) {
      return this.missingPositionsOnLayer(i).isEmpty();
   }

   public class_1792 findFirstMissingBlockOnLayer(int i) {
      return this.findFirstMissingBlockOnLayer(this.missingPositionsOnLayer(i));
   }

   public class_1792 findFirstMissingBlockOnLayer(List<class_2338> list) {
      for (class_2338 var3 : list) {
         class_2680 var4 = this.desiredStateAt(var3);
         if (var4 != null) {
            class_2248 var5 = var4.method_26204();
            class_1792 var6 = SkipSchematic.isIce(var5) ? class_1802.field_8410 : var5.method_8389();
            if (var6 != class_1802.field_8162) {
               return var6;
            }
         }
      }

      return null;
   }

   private boolean worthRetrying(class_2338 arg) {
      return !this.floatSkipped.contains(arg) || hasFaceToPlaceAgainst(arg);
   }

   private boolean onlyOrphansMissing(List<class_2338> list) {
      if (list.isEmpty()) {
         return false;
      }

      for (class_2338 var3 : list) {
         if (hasFaceToPlaceAgainst(var3)) {
            return false;
         }
      }

      return true;
   }

   public int countTotalNeeded(class_1792 arg) {
      if (this.schematic == null || this.origin == null || arg == null) {
         return -1;
      }

      if (arg == class_1802.field_8705) {
         int var7 = 0;
         if (this.plan != null) {
            for (FinishTask var11 : this.plan) {
               if (var11.type() == FinishTask.Type.WATERLOG || var11.type() == FinishTask.Type.WATER_SOURCE) {
                  var7++;
               }
            }
         }

         return var7;
      } else if (arg == class_1802.field_8187) {
         int var6 = 0;
         if (this.plan != null) {
            for (FinishTask var10 : this.plan) {
               if (var10.type() == FinishTask.Type.LAVA_SOURCE) {
                  var6++;
               }
            }
         }

         return var6;
      } else {
         if (this.schematicTotalCounts == null) {
            this.computeSchematicTotals();
         }

         boolean var2 = arg == class_1802.field_8410 || arg == class_1802.field_8483 || RestockController.isStainedGlassItem(arg);
         if (var2) {
            int var3 = 0;

            for (Entry var5 : this.schematicTotalCounts.entrySet()) {
               if (RestockController.isStainedGlassItem((class_1792)var5.getKey())) {
                  var3 += var5.getValue();
               }
            }

            return var3;
         } else {
            return this.schematicTotalCounts.getOrDefault(arg, 0);
         }
      }
   }

   public int countRemainingNeeded(class_1792 arg) {
      if (this.schematic != null && this.origin != null && arg != null) {
         class_310 var2 = class_310.method_1551();
         if (var2 != null && var2.field_1687 != null) {
            class_638 var3 = var2.field_1687;
            if (arg == class_1802.field_8705) {
               int var10 = 0;
               if (this.plan != null) {
                  for (FinishTask var13 : this.plan) {
                     if (var13.type() == FinishTask.Type.WATERLOG || var13.type() == FinishTask.Type.WATER_SOURCE) {
                        class_2338 var14 = var13.pos();
                        class_2680 var15 = var3.method_8320(var14);
                        if (var13.type() == FinishTask.Type.WATERLOG
                           ? !var15.method_28498(class_2741.field_12508) || !(Boolean)var15.method_11654(class_2741.field_12508)
                           : !var15.method_26227().method_15771() || !var15.method_26227().method_33659(class_3612.field_15910)) {
                           var10++;
                        }
                     }
                  }
               }

               return var10;
            } else if (arg == class_1802.field_8187) {
               int var9 = 0;
               if (this.plan != null) {
                  for (FinishTask var6 : this.plan) {
                     if (var6.type() == FinishTask.Type.LAVA_SOURCE) {
                        class_2338 var7 = var6.pos();
                        class_2680 var8 = var3.method_8320(var7);
                        if (!var8.method_26227().method_15771() || !var8.method_26227().method_33659(class_3612.field_15908)) {
                           var9++;
                        }
                     }
                  }
               }

               return var9;
            } else {
               boolean var4 = arg == class_1802.field_8410 || arg == class_1802.field_8483 || RestockController.isStainedGlassItem(arg);
               Map var5 = this.computeRemainingCounts(false);
               return var4 ? var5.getOrDefault(class_1802.field_8410, 0) : var5.getOrDefault(arg, 0);
            }
         } else {
            return -1;
         }
      } else {
         return -1;
      }
   }

   public void printStatus() {
      AutoBuildFarm.chat(
         "State: "
            + this.state
            + (
               !this.layerYLevels.isEmpty() && this.currentLayerIndex < this.layerYLevels.size()
                  ? " | layer: " + (this.currentLayerIndex + 1) + "/" + this.layerYLevels.size() + " (Y=" + this.currentCeilingY + ")"
                  : ""
            )
            + " | planned finishing tasks: "
            + this.plan.size()
            + (
               this.finishProcess != null && this.state != FarmBuildController.State.IDLE
                  ? " | left: " + this.finishProcess.remaining() + " (" + this.finishProcess.mode() + ")"
                  : ""
            )
      );
      this.reportBucketBudget();
   }

   private String layerSummary(int i) {
      int var2 = 0;
      int var3 = 0;
      if (this.plan != null) {
         for (FinishTask var5 : this.plan) {
            if (var5.pos().method_10264() == i) {
               if (var5.type() == FinishTask.Type.LAVA_SOURCE) {
                  var2++;
               } else if (var5.type() == FinishTask.Type.WATER_SOURCE || var5.type() == FinishTask.Type.WATERLOG) {
                  var3++;
               }
            }
         }
      }

      if (var2 == 0 && var3 == 0) {
         return " (0 fluids)";
      }

      StringBuilder var6 = new StringBuilder(" (fluids: ");
      if (var3 > 0) {
         var6.append(var3).append(" water");
      }

      if (var2 > 0) {
         if (var3 > 0) {
            var6.append(", ");
         }

         var6.append(var2).append(" lava");
      }

      var6.append(")");
      return var6.toString();
   }

   public void onClientTick() {
      class_310 var1 = class_310.method_1551();
      if (var1 != null && var1.field_1687 != null && var1.field_1724 != null) {
         GuiAutomator.getInstance().tick();
         if (this.disposalCooldown > 0) {
            this.disposalCooldown--;
         }

         if (BucketDisposal.getInstance().isBusy()) {
            BucketDisposal.getInstance().tick(var1);
         } else if (this.state != FarmBuildController.State.IDLE && this.disposalCooldown <= 0 && BucketDisposal.getInstance().needsDisposal(var1.field_1724)) {
            this.disposalCooldown = 600;
            IBaritone var19 = baritone();
            boolean var23 = var19 != null && var19.getBuilderProcess().isActive() && !var19.getBuilderProcess().isPaused();
            if (var23) {
               var19.getBuilderProcess().pause();
            }

            BucketDisposal.getInstance().start(var1, () -> {
               if (var23) {
                  IBaritone var1x = baritone();
                  if (var1x != null && var1x.getBuilderProcess().isActive() && var1x.getBuilderProcess().isPaused()) {
                     var1x.getBuilderProcess().resume();
                  }
               }
            });
         } else if (RestockController.getInstance().isBusy()) {
            RestockController.getInstance().tick(var1);
         } else if (AutoEatController.getInstance().tick(var1)) {
            this.pausedTicks = 0;
            this.builderIdleTicks = 0;
            this.stationaryTicks = 0;
         } else if (this.state == FarmBuildController.State.IDLE) {
            this.stationaryTicks = 0;
            this.lastPlayerStationaryFeet = null;
            this.elevatorTicks = 0;
            this.elevatorTargetPos = null;
         } else if (this.elevatorTicks > 0) {
            this.elevatorTicks++;
            if (var1.field_1724 != null && this.elevatorTargetPos != null) {
               double var18 = var1.field_1724.method_23318() - this.elevatorTargetPos.method_10264();
               if (var18 >= 1.05 || this.elevatorTicks >= 10) {
                  int var28 = InventoryHelper.findInHotbar(var1.field_1724, class_1802.field_20412);
                  if (var28 < 0) {
                     var28 = InventoryHelper.findInHotbar(var1.field_1724, class_1802.field_8831);
                  }

                  if (var28 < 0) {
                     var28 = InventoryHelper.findSafeHotbarSlot(var1.field_1724);
                  }

                  if (var28 >= 0) {
                     InventoryHelper.selectHotbarSlot(var1, var28);
                  }

                  this.placeBlockUnderFeet(var1, this.elevatorTargetPos);
                  this.elevatorTicks = 0;
                  this.elevatorTargetPos = null;
                  IBaritone var32 = baritone();
                  if (var32 != null) {
                     var32.getPathingBehavior().cancelEverything();
                  }

                  return;
               }
            } else {
               this.elevatorTicks = 0;
            }
         } else {
            class_2338 var2 = var1.field_1724.method_24515();
            if (this.lastPlayerStationaryFeet != null && var2.method_19455(this.lastPlayerStationaryFeet) <= 2) {
               this.stationaryTicks++;
               if (this.stationaryTicks >= 600) {
                  this.stationaryTicks = 0;
                  AutoBuildFarm.chat(
                     "\u00a7c\u0110\u1ee9ng y\u00ean qu\u00e1 30s kh\u00f4ng th\u1ec3 ti\u1ebfp t\u1ee5c -> T\u1ef1 \u0111\u1ed9ng k\u1ebft n\u1ed1i l\u1ea1i (Auto Rejoin)\u2026"
                  );
                  AutoRejoinHandler.getInstance().trigger("\u0110\u1ee9ng y\u00ean qu\u00e1 30 gi\u00e2y");
                  return;
               }
            } else {
               this.lastPlayerStationaryFeet = var2;
               this.stationaryTicks = 0;
            }

            if (this.state == FarmBuildController.State.BUILDING) {
               this.fastBuildingTicks++;
               if (this.finishProcess != null) {
                  this.finishProcess.rearm();
               }

               if (this.fastBuildingTicks % 10 == 0 && var1.field_1724 != null) {
                  IBaritone var3 = baritone();
                  boolean var4 = var3 != null && var3.getInputOverrideHandler().isInputForcedDown(Input.CLICK_RIGHT);
                  if (!var4) {
                     boolean var5 = false;
                     int var6 = var1.field_1724.method_31548().method_67532();

                     for (int var7 = 0; var7 < 9; var7++) {
                        if (var7 != var6) {
                           class_1799 var8 = var1.field_1724.method_31548().method_5438(var7);
                           if (var8.method_7960() || var8.method_31574(class_1802.field_8550)) {
                              var5 = true;
                              break;
                           }
                        }
                     }

                     if (var5) {
                        for (RestockController.QuotaEntry var41 : RestockController.TARGET_ITEMS) {
                           if (var41.item() != class_1802.field_8187) {
                              InventoryHelper.ensureHotbarSupplied(var1, var41.item());
                           }
                        }

                        for (class_1792 var42 : this.getRequiredItemsInSchematic()) {
                           InventoryHelper.ensureHotbarSupplied(var1, var42);
                        }
                     }
                  }
               }

               if (var1.field_1724 != null) {
                  class_1799 var20 = var1.field_1724.method_6047();
                  if (var20.method_31574(class_1802.field_8535) || var20.method_31574(class_1802.field_8554)) {
                     int var24 = InventoryHelper.findSafeHotbarSlot(var1.field_1724);
                     if (var24 >= 0) {
                        InventoryHelper.selectHotbarSlot(var1, var24);
                     }
                  }
               }

               if (this.fastBuildingTicks % 10 == 0 && this.finishProcess != null && var1.field_1724 != null && var1.field_1687 != null) {
                  class_2338 var21 = var1.field_1724.method_24515();

                  for (int var25 = -4; var25 <= 4; var25++) {
                     for (int var29 = -3; var29 <= 3; var29++) {
                        for (int var33 = -4; var33 <= 4; var33++) {
                           class_2338 var38 = var21.method_10069(var25, var29, var33);
                           if (var38.method_10264() <= this.currentCeilingY) {
                              class_2680 var43 = var1.field_1687.method_8320(var38);
                              if (var43.method_26204() instanceof class_2397
                                 && this.isWaterlogDesired(var38)
                                 && var43.method_28498(class_2741.field_12508)
                                 && !(Boolean)var43.method_11654(class_2741.field_12508)) {
                                 this.finishProcess.markLeafSeen(var38);
                                 if (!this.finishProcess.hasTask(FinishTask.Type.WATERLOG, var38)) {
                                    class_2680 var9 = this.desiredStateAt(var38);
                                    this.finishProcess.addTasks(List.of(new FinishTask(FinishTask.Type.WATERLOG, var38, var9 != null ? var9 : var43)));
                                 }
                              }
                           }
                        }
                     }
                  }
               }

               if (this.fastBuildingTicks % 10 == 0) {
                  this.watchPlacements();
               }
            } else if (this.state == FarmBuildController.State.LAYER_FLUIDS || this.state == FarmBuildController.State.FINISHING) {
               this.fastBuildingTicks++;
               if (this.fastBuildingTicks % 10 == 0) {
                  InventoryHelper.ensureHotbarSupplied(var1, class_1802.field_8705);
                  InventoryHelper.ensureHotbarSupplied(var1, class_1802.field_8187);
               }
            }

            if (this.state == FarmBuildController.State.FINISHING) {
               this.tickFinishing();
            } else {
               IBaritone var22 = baritone();
               if (var22 != null) {
                  if (this.state == FarmBuildController.State.LAYER_FLUIDS) {
                     this.tickLayerFluids(var22);
                  } else if (this.state == FarmBuildController.State.BUILDING) {
                     if (!RestockController.getInstance().isBusy() && !BucketDisposal.getInstance().isBusy()) {
                        if (this.finishProcess == null || !this.finishProcess.isEngaged() && !this.finishProcess.isVerifying()) {
                           if (++this.materialCheckTicks >= 20) {
                              this.materialCheckTicks = 0;
                              if (this.checkBuildingMaterials(var22)) {
                                 return;
                              }
                           }
                        } else {
                           this.materialCheckTicks = 0;
                        }
                     } else {
                        this.materialCheckTicks = 0;
                     }

                     if (var1.field_1724 != null) {
                        class_1799 var26 = var1.field_1724.method_6047();
                        class_1799 var30 = var1.field_1724.method_6079();
                        boolean var34 = var26.method_7909() instanceof class_1747 var44 && var44.method_7711() instanceof class_2397
                           || var30.method_7909() instanceof class_1747 var39 && var39.method_7711() instanceof class_2397;
                        if (!var34 && !this.isTargetingLeaves(var22)) {
                           BaritoneAPI.getSettings().rightClickSpeed.value = FarmConfig.placeSpeed;
                        } else {
                           BaritoneAPI.getSettings().rightClickSpeed.value = FarmConfig.leafPlaceSpeed;
                        }
                     }

                     IBuilderProcess var27 = var22.getBuilderProcess();
                     if (var27.isActive()) {
                        this.trace(
                           "BUILD",
                           var22,
                           (var27.isPaused() ? "builderPaused " : "")
                              + "layer="
                              + (this.currentLayerIndex + 1)
                              + "/"
                              + this.layerYLevels.size()
                              + "(Y="
                              + this.currentCeilingY
                              + ")"
                        );
                        if (var27.isPaused()) {
                           this.tickPaused(var22, var27);
                        } else {
                           this.pausedTicks = 0;
                           this.builderIdleTicks = 0;
                           this.checkFloating(var22);
                           this.watchBuild(var22);
                        }
                     } else if (this.finishProcess != null && this.finishProcess.isEngaged()) {
                        this.builderIdleTicks = 0;
                     } else {
                        boolean var31 = this.isLayerStructureComplete(this.currentCeilingY);
                        boolean var35 = this.layerHasStructuralBlocks(this.currentCeilingY);
                        int var40 = var31 && var35 ? 2 : 30;
                        if (++this.builderIdleTicks >= var40) {
                           ArrayList var45 = new ArrayList();

                           for (class_2338 var10 : this.skipped) {
                              if (var10.method_10264() <= this.currentCeilingY && this.worthRetrying(var10)) {
                                 var45.add(var10);
                              }
                           }

                           if (!var45.isEmpty() && this.retryRounds < 2) {
                              this.retryRounds++;
                              AutoBuildFarm.chat(
                                 "Retrying "
                                    + var45.size()
                                    + " skipped position(s) on layer Y="
                                    + this.currentCeilingY
                                    + " (round "
                                    + this.retryRounds
                                    + "/2)\u2026"
                              );
                              DebugLog.detail("retry round " + this.retryRounds + " over " + positions(var45));
                              this.skipped.removeAll(var45);
                              this.floatSkipped.removeAll(var45);
                              this.stuckSkipped.removeAll(var45);
                              this.recentBuildPositions.clear();
                              this.warnedPaused = false;
                              this.pausedTicks = 0;
                              this.buildStallTicks = 0;
                              this.buildStallReports = 0;
                              this.lastFeet = null;
                              this.issueBuild(var22);
                           } else {
                              if (!this.skipped.isEmpty()) {
                                 DebugLog.detail("never built on layer Y=" + this.currentCeilingY + ": " + positions(this.skipped));
                              }

                              List var49 = this.missingPositionsOnLayer(this.currentCeilingY);
                              if (!var49.isEmpty()) {
                                 class_1792 var50 = this.findFirstMissingBlockOnLayer(var49);
                                 DebugLog.detail("Layer Y=" + this.currentCeilingY + " structure incomplete, first missing item=" + var50);
                                 this.diagnoseMissing(this.currentCeilingY, var49);
                                 ArrayList var11 = new ArrayList();

                                 for (class_2338 var13 : var49) {
                                    class_2680 var14 = this.desiredStateAt(var13);
                                    if (var14 != null) {
                                       class_1792 var15 = SkipSchematic.isIce(var14.method_26204())
                                          ? class_1802.field_8410
                                          : var14.method_26204().method_8389();
                                       if (var15 != class_1802.field_8162 && !var11.contains(var15)) {
                                          int var16 = InventoryHelper.count(var1.field_1724, var15);
                                          if (var16 == 0 || !RestockController.isQuotaSatisfied(var15, var16)) {
                                             var11.add(var15);
                                          }
                                       }
                                    }
                                 }

                                 int var53 = InventoryHelper.count(var1.field_1724, class_1802.field_20412);
                                 if (var53 < 32 && !var11.contains(class_1802.field_20412)) {
                                    var11.add(class_1802.field_20412);
                                 }

                                 if (!var11.isEmpty()) {
                                    String var57 = var11.stream().map(RestockController::getItemDisplayName).collect(Collectors.joining(", "));
                                    if (var1.method_1542()) {
                                       if (!this.warnedPaused) {
                                          this.warnedPaused = true;
                                          AutoBuildFarm.chat(
                                             "Layer Y="
                                                + this.currentCeilingY
                                                + " ch\u01b0a ho\u00e0n th\u00e0nh: thi\u1ebfu nguy\u00ean li\u1ec7u ("
                                                + var57
                                                + ") trong Singleplayer. Vui l\u00f2ng l\u1ea5y th\u00eam v\u00e0 g\u00f5 /buildfarm resume."
                                          );
                                       }

                                       return;
                                    }

                                    AutoBuildFarm.chat(
                                       "Layer Y="
                                          + this.currentCeilingY
                                          + " ch\u01b0a ho\u00e0n th\u00e0nh: thi\u1ebfu "
                                          + var57
                                          + " \u2014 t\u1ef1 \u0111\u1ed9ng l\u1ea5y qua /order\u2026"
                                    );
                                    RestockController.getInstance()
                                       .startRestockSequence(
                                          var11,
                                          () -> {
                                             AutoBuildFarm.chat(
                                                "\u2714 \u0110\u00e3 b\u1ed5 sung "
                                                   + var57
                                                   + "! Ti\u1ebfp t\u1ee5c x\u00e2y d\u1ef1ng layer Y="
                                                   + this.currentCeilingY
                                                   + "\u2026"
                                             );
                                             this.skipped.removeIf(arg -> arg.method_10264() <= this.currentCeilingY);
                                             this.floatSkipped.removeIf(arg -> arg.method_10264() <= this.currentCeilingY);
                                             this.stuckSkipped.removeIf(arg -> arg.method_10264() <= this.currentCeilingY);
                                             this.recentBuildPositions.clear();
                                             this.issueBuild(var22);
                                          }
                                       );
                                    return;
                                 }

                                 if (this.onlyOrphansMissing(var49)) {
                                    DebugLog.detail(
                                       "layer Y="
                                          + this.currentCeilingY
                                          + " missing only orphan block(s): "
                                          + positions(var49)
                                          + " \u2014 advancing, they return once a neighbour exists"
                                    );
                                    AutoBuildFarm.chat(
                                       "Layer Y="
                                          + this.currentCeilingY
                                          + " c\u00f2n "
                                          + var49.size()
                                          + " kh\u1ed1i ch\u01b0a c\u00f3 m\u1eb7t t\u1ef1a \u2014 l\u00ean t\u1ea7ng tr\u00ean, s\u1ebd t\u1ef1 quay l\u1ea1i \u0111\u1eb7t khi c\u00f3 h\u00e0ng x\u00f3m."
                                    );
                                 } else {
                                    LinkedHashSet var55 = new LinkedHashSet(var49);
                                    if (var55.equals(this.lastMissingSet)) {
                                       this.fruitlessRounds++;
                                    } else {
                                       this.fruitlessRounds = 0;
                                       this.lastMissingSet = var55;
                                    }

                                    if (this.fruitlessRounds >= 2) {
                                       AutoBuildFarm.chat(
                                          "\u26a0\ufe0f Layer Y="
                                             + this.currentCeilingY
                                             + " c\u00f2n "
                                             + var49.size()
                                             + " kh\u1ed1i v\u00e0 "
                                             + this.retryRounds
                                             + " l\u1ea7n x\u00e2y l\u1ea1i kh\u00f4ng \u0111\u1ed5i \u0111\u01b0\u1ee3c g\u00ec \u2014 b\u1ecf qua, \u0111i ti\u1ebfp."
                                       );
                                       DebugLog.detail(
                                          "giving up on Y="
                                             + this.currentCeilingY
                                             + " after "
                                             + this.fruitlessRounds
                                             + " identical rebuild rounds over "
                                             + positions(var49)
                                       );
                                    } else {
                                       if (this.retryRounds < 6) {
                                          this.retryRounds++;
                                          AutoBuildFarm.chat(
                                             "Layer Y="
                                                + this.currentCeilingY
                                                + " ch\u01b0a \u0111\u1eb7t \u0111\u1ee7 kh\u1ed1i \u2014 ti\u1ebfp t\u1ee5c x\u00e2y d\u1ef1ng l\u1ea1i (l\u1ea7n "
                                                + this.retryRounds
                                                + "/6)\u2026"
                                          );
                                          this.skipped.removeIf(arg -> arg.method_10264() <= this.currentCeilingY);
                                          this.floatSkipped.removeIf(arg -> arg.method_10264() <= this.currentCeilingY);
                                          this.stuckSkipped.removeIf(arg -> arg.method_10264() <= this.currentCeilingY);
                                          this.recentBuildPositions.clear();
                                          this.warnedPaused = false;
                                          this.pausedTicks = 0;
                                          this.buildStallTicks = 0;
                                          this.buildStallReports = 0;
                                          this.lastFeet = null;
                                          this.issueBuild(var22);
                                          return;
                                       }

                                       AutoBuildFarm.chat(
                                          "\u26a0\ufe0f C\u1ea3nh b\u00e1o: Layer Y="
                                             + this.currentCeilingY
                                             + " c\u00f2n kh\u1ed1i ch\u01b0a \u0111\u1eb7t \u0111\u01b0\u1ee3c sau "
                                             + this.retryRounds
                                             + " l\u1ea7n th\u1eed."
                                       );
                                    }
                                 }
                              }

                              int var51 = this.rescanUnwaterloggedLeaves(this.currentCeilingY);
                              if (var51 > 0) {
                                 AutoBuildFarm.chat(
                                    "Rescan: ph\u00e1t hi\u1ec7n "
                                       + var51
                                       + " kh\u1ed1i l\u00e1 c\u1ea7n \u0111\u1ed5 n\u01b0\u1edbc \u1edf t\u1ea7ng Y="
                                       + this.currentCeilingY
                                       + "\u2026"
                                 );
                              }

                              int var52 = this.rescanUnpouredLava(this.currentCeilingY);
                              if (var52 > 0) {
                                 AutoBuildFarm.chat(
                                    "Rescan: ph\u00e1t hi\u1ec7n "
                                       + var52
                                       + " \u00f4 lava ch\u01b0a \u0111\u1ed5 \u1edf t\u1ea7ng Y="
                                       + this.currentCeilingY
                                       + "\u2026"
                                 );
                              }

                              int var54 = this.countDoableUnfinishedLava(this.currentCeilingY);
                              if ((this.finishProcess == null || !this.finishProcess.hasDoableWorkAtOrBelow(this.currentCeilingY)) && var54 <= 0) {
                                 this.advanceLayer(var22);
                              } else {
                                 AutoBuildFarm.chat(
                                    "Layer "
                                       + (this.currentLayerIndex + 1)
                                       + "/"
                                       + this.layerYLevels.size()
                                       + " (Y="
                                       + this.currentCeilingY
                                       + ") structure built. Finishing layer fluids ("
                                       + (var54 > 0 ? var54 + " lava remaining" : "fluids/redstone")
                                       + ")\u2026"
                                 );
                                 this.state = FarmBuildController.State.LAYER_FLUIDS;
                                 this.layerFluidsStallTicks = 0;
                                 this.lastRemainingFluids = -1;
                                 this.layerFluidsRetryRounds = 0;

                                 try {
                                    Settings var56 = BaritoneAPI.getSettings();
                                    var56.allowPlace.value = false;
                                    var56.allowPlaceInFluidsSource.value = false;
                                    var56.allowPlaceInFluidsFlow.value = false;
                                    var56.blockPlacementPenalty.value = 35.0;
                                 } catch (Throwable var17) {
                                 }

                                 this.finishProcess.beginLayerSweep(this.currentCeilingY);
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private void tickLayerFluids(IBaritone iBaritone) {
      class_310 var2 = class_310.method_1551();
      if (this.finishProcess != null && var2.field_1724 != null && var2.field_1687 != null) {
         this.trace(
            "LAYER_FLUIDS",
            iBaritone,
            "layer="
               + (this.currentLayerIndex + 1)
               + "/"
               + this.layerYLevels.size()
               + "(Y="
               + this.currentCeilingY
               + ") left="
               + this.finishProcess.remaining()
         );
         int var3 = this.countDoableUnfinishedLava(this.currentCeilingY);
         if (this.finishProcess.hasDoableWorkAtOrBelow(this.currentCeilingY) || var3 > 0) {
            if (this.finishProcess.needsFluidItem(class_1802.field_8705, this.currentCeilingY)
               && InventoryHelper.count(var2.field_1724, class_1802.field_8705) == 0
               && !RestockController.getInstance().isBusy()
               && RestockController.getInstance().canRequestRestock(class_1802.field_8705)) {
               RestockController.getInstance().requestRestock(class_1802.field_8705);
               return;
            }

            if ((this.finishProcess.needsFluidItem(class_1802.field_8187, this.currentCeilingY) || var3 > 0)
               && InventoryHelper.count(var2.field_1724, class_1802.field_8187) == 0
               && !RestockController.getInstance().isBusy()
               && RestockController.getInstance().canRequestRestock(class_1802.field_8187)) {
               RestockController.getInstance().requestRestock(class_1802.field_8187);
               return;
            }
         }

         if (this.finishProcess.hasDoableWorkAtOrBelow(this.currentCeilingY) && this.finishProcess.mode() != FinishProcess.Mode.OFF) {
            int var5 = this.finishProcess.remaining();
            if (this.lastRemainingFluids != -1 && var5 >= this.lastRemainingFluids) {
               this.layerFluidsStallTicks++;
               if (this.layerFluidsStallTicks > 500) {
                  if (var3 > 0 && this.layerFluidsRetryRounds < 8) {
                     this.layerFluidsRetryRounds++;
                     AutoBuildFarm.chat(
                        "\u26a0 T\u1ea7ng Y="
                           + this.currentCeilingY
                           + " c\u00f2n "
                           + var3
                           + " \u00f4 lava ch\u01b0a \u0111\u1ed5 \u2014 qu\u00e9t l\u1ea1i v\u00e0 ti\u1ebfp t\u1ee5c ho\u00e0n th\u00e0nh (l\u1ea7n "
                           + this.layerFluidsRetryRounds
                           + "/8)\u2026"
                     );
                     this.layerFluidsStallTicks = 0;
                     this.lastRemainingFluids = -1;
                     this.rescanUnpouredLava(this.currentCeilingY);
                     if (InventoryHelper.count(var2.field_1724, class_1802.field_8187) == 0
                        && !RestockController.getInstance().isBusy()
                        && RestockController.getInstance().canRequestRestock(class_1802.field_8187)) {
                        RestockController.getInstance().requestRestock(class_1802.field_8187);
                     }

                     this.finishProcess.beginLayerSweep(this.currentCeilingY);
                     return;
                  }

                  AutoBuildFarm.chat(
                     "\u26a0 Qu\u00e1 th\u1eddi gian kh\u00f4ng ho\u00e0n th\u00e0nh th\u00eam ch\u1ea5t l\u1ecfng \u1edf t\u1ea7ng Y="
                        + this.currentCeilingY
                        + "; chuy\u1ec3n sang t\u1ea7ng ti\u1ebfp theo (s\u1ebd qu\u00e9t l\u1ea1i khi ho\u00e0n th\u00e0nh farm)."
                  );
                  this.layerFluidsStallTicks = 0;
                  this.lastRemainingFluids = -1;
                  this.layerFluidsRetryRounds = 0;
                  this.finishProcess.standDown();
                  this.advanceLayer(iBaritone);
                  return;
               }
            } else {
               this.lastRemainingFluids = var5;
               this.layerFluidsStallTicks = 0;
               this.layerFluidsRetryRounds = 0;
            }

            this.finishProcess.rearm();
         } else if (var3 > 0 && this.layerFluidsRetryRounds < 8) {
            this.layerFluidsRetryRounds++;
            AutoBuildFarm.chat(
               "\u26a0 T\u1ea7ng Y="
                  + this.currentCeilingY
                  + " c\u00f2n "
                  + var3
                  + " \u00f4 lava ch\u01b0a \u0111\u1ed5 \u2014 qu\u00e9t l\u1ea1i v\u00e0 ti\u1ebfp t\u1ee5c ho\u00e0n th\u00e0nh (l\u1ea7n "
                  + this.layerFluidsRetryRounds
                  + "/8)\u2026"
            );
            this.rescanUnpouredLava(this.currentCeilingY);
            if (InventoryHelper.count(var2.field_1724, class_1802.field_8187) == 0
               && !RestockController.getInstance().isBusy()
               && RestockController.getInstance().canRequestRestock(class_1802.field_8187)) {
               RestockController.getInstance().requestRestock(class_1802.field_8187);
            } else {
               this.finishProcess.beginLayerSweep(this.currentCeilingY);
            }
         } else {
            int var4 = this.countUnfinishedLava(this.currentCeilingY);
            if (var4 > 0 && var3 > 0 && this.layerFluidsRetryRounds < 8) {
               this.layerFluidsRetryRounds++;
               AutoBuildFarm.chat(
                  "\u26a0 T\u1ea7ng Y="
                     + this.currentCeilingY
                     + " v\u1eabn c\u00f2n "
                     + var3
                     + " \u00f4 lava ch\u01b0a \u0111\u1ed5 \u2014 ti\u1ebfp t\u1ee5c ho\u00e0n th\u00e0nh tr\u01b0\u1edbc khi l\u00ean t\u1ea7ng m\u1edbi\u2026"
               );
               this.rescanUnpouredLava(this.currentCeilingY);
               this.finishProcess.beginLayerSweep(this.currentCeilingY);
            } else {
               if (var4 > 0) {
                  AutoBuildFarm.chat(
                     "\u2714 Layer Y="
                        + this.currentCeilingY
                        + " ho\u00e0n th\u00e0nh! ("
                        + var4
                        + " \u00f4 lava \u0111\u00e3 \u0111\u00f3ng kh\u1ed1i/kh\u00f4ng th\u1ec3 \u0111\u1ed5 th\u00eam, ti\u1ebfp t\u1ee5c t\u1ea7ng ti\u1ebfp theo)"
                  );
               } else {
                  AutoBuildFarm.chat("\u2714 Layer Y=" + this.currentCeilingY + " fluids & redstone complete!");
               }

               this.advanceLayer(iBaritone);
            }
         }
      }
   }

   private void advanceLayer(IBaritone iBaritone) {
      this.currentLayerIndex++;
      this.retryRounds = 0;
      this.lastMissingSet = Set.of();
      this.fruitlessRounds = 0;
      this.builderIdleTicks = 0;
      this.floatingGoal = null;
      this.floatingChecks = 0;
      this.buildStallTicks = 0;
      this.buildStallReports = 0;
      this.layerFluidsStallTicks = 0;
      this.lastRemainingFluids = -1;
      this.layerFluidsRetryRounds = 0;
      this.lastFeet = null;
      this.pausedTicks = 0;
      this.warnedPaused = false;
      this.lastRemainingScanTime = 0L;
      if (this.rollbacksSeen > 0) {
         AutoBuildFarm.chat(
            "\u00a7eLayer Y="
               + this.currentCeilingY
               + ": "
               + this.rollbacksSeen
               + " kh\u1ed1i b\u1ecb m\u1ea5t sau khi \u0111\u1eb7t \u2014 xem log \u0111\u1ec3 bi\u1ebft server t\u1eeb ch\u1ed1i hay bot t\u1ef1 ph\u00e1."
         );
      }

      this.rollbacksSeen = 0;
      this.rollbacksLogged = 0;
      this.correctSince.clear();
      if (this.currentLayerIndex < this.layerYLevels.size()) {
         this.currentCeilingY = this.layerYLevels.get(this.currentLayerIndex);
         AutoBuildFarm.chat(
            "Starting layer "
               + (this.currentLayerIndex + 1)
               + "/"
               + this.layerYLevels.size()
               + " (Y="
               + this.currentCeilingY
               + ")"
               + this.layerSummary(this.currentCeilingY)
               + "\u2026"
         );
         this.state = FarmBuildController.State.BUILDING;
         if (this.finishProcess != null) {
            this.finishProcess.resumeOpportunistic(this.currentCeilingY);
         }

         this.issueBuild(iBaritone);
      } else {
         AutoBuildFarm.chat("All layers built! Sweeping up what is left\u2026");
         this.state = FarmBuildController.State.FINISHING;
         this.beginFinishing();
      }
   }

   private boolean checkBuildingMaterials(IBaritone iBaritone) {
      class_310 var2 = class_310.method_1551();
      if (var2 != null && var2.field_1724 != null && !var2.method_1542() && !RestockController.getInstance().isBusy()) {
         RestockController.QuotaEntry var3 = RestockController.getInstance().findExhaustedItem(var2.field_1724);
         if (var3 == null) {
            return false;
         }

         if (var3.item() == class_1802.field_8705 && InventoryHelper.count(var2.field_1724, class_1802.field_8705) > 0) {
            InventoryHelper.ensureHotbarSupplied(var2, class_1802.field_8705);
            return false;
         }

         IBuilderProcess var4 = iBaritone != null ? iBaritone.getBuilderProcess() : null;
         if (var4 != null && var4.isActive() && !var4.isPaused()) {
            var4.pause();
         }

         AutoBuildFarm.chat("Thi\u1ebfu " + var3.displayName() + " \u2014 t\u1ef1 \u0111\u1ed9ng l\u1ea5y qua /order\u2026");
         RestockController.getInstance().requestRestock(var3.item(), () -> {
            InventoryHelper.ensureHotbarSupplied(var2, var3.item());
            if (iBaritone != null && iBaritone.getBuilderProcess().isActive() && iBaritone.getBuilderProcess().isPaused()) {
               iBaritone.getBuilderProcess().resume();
            }
         });
         return true;
      } else {
         return false;
      }
   }

   private void tickPaused(IBaritone iBaritone, IBuilderProcess iBuilderProcess) {
      class_310 var3 = class_310.method_1551();
      if (var3 != null && var3.field_1724 != null) {
         RestockController.QuotaEntry var4 = RestockController.getInstance().findExhaustedItem(var3.field_1724);
         if (var4 != null) {
            if (var3.method_1542()) {
               if (!this.warnedPaused) {
                  this.warnedPaused = true;
                  AutoBuildFarm.chat(
                     "Baritone thi\u1ebfu nguy\u00ean li\u1ec7u ("
                        + var4.displayName()
                        + ") trong Singleplayer. Vui l\u00f2ng l\u1ea5y nguy\u00ean li\u1ec7u v\u00e0o t\u00fai \u0111\u1ed3 v\u00e0 g\u00f5 #resume."
                  );
               }

               if (++this.pausedTicks > 300) {
                  iBuilderProcess.onLostControl();
                  AutoBuildFarm.chat(
                     "H\u1ebft th\u1eddi gian ch\u1edd b\u1ed5 sung nguy\u00ean li\u1ec7u ("
                        + var4.displayName()
                        + ") \u2014 d\u1eebng x\u00e2y d\u1ef1ng v\u00e0 qu\u00e9t ho\u00e0n thi\u1ec7n."
                  );
                  this.state = FarmBuildController.State.FINISHING;
                  this.beginFinishing();
               }

               return;
            }

            AutoBuildFarm.chat("Baritone thi\u1ebfu nguy\u00ean li\u1ec7u (" + var4.displayName() + ") \u2014 t\u1ef1 \u0111\u1ed9ng l\u1ea5y qua /order\u2026");
            RestockController.getInstance().requestRestock(var4.item());
            this.pausedTicks = 0;
            return;
         }

         class_1792 var5 = this.findFirstMissingBlockOnLayer(this.currentCeilingY);
         if (var5 != null && InventoryHelper.count(var3.field_1724, var5) == 0) {
            if (var3.method_1542()) {
               if (!this.warnedPaused) {
                  this.warnedPaused = true;
                  AutoBuildFarm.chat(
                     "Baritone thi\u1ebfu nguy\u00ean li\u1ec7u ("
                        + RestockController.getItemDisplayName(var5)
                        + ") cho layer Y="
                        + this.currentCeilingY
                        + ". Vui l\u00f2ng b\u1ed5 sung v\u00e0o t\u00fai \u0111\u1ed3 v\u00e0 g\u00f5 #resume."
                  );
               }

               return;
            }

            AutoBuildFarm.chat(
               "Baritone thi\u1ebfu nguy\u00ean li\u1ec7u ("
                  + RestockController.getItemDisplayName(var5)
                  + ") cho layer Y="
                  + this.currentCeilingY
                  + " \u2014 t\u1ef1 \u0111\u1ed9ng l\u1ea5y qua /order\u2026"
            );
            RestockController.getInstance().requestRestock(var5);
            this.pausedTicks = 0;
            return;
         }
      }

      if (++this.pausedTicks > 300) {
         iBuilderProcess.onLostControl();
         AutoBuildFarm.chat("Baritone paused too long \u2014 skipping to finishing pass.");
         this.state = FarmBuildController.State.FINISHING;
         this.beginFinishing();
      }
   }

   private void trace(String string, IBaritone iBaritone, String string2) {
      if (++this.traceTicks % 20 == 0) {
         class_310 var4 = class_310.method_1551();
         if (var4.field_1724 != null) {
            IPathingBehavior var5 = iBaritone.getPathingBehavior();
            StringBuilder var6 = new StringBuilder(string);
            var6.append(" @")
               .append(var4.field_1724.method_24515().method_23854())
               .append(" ctl=")
               .append(iBaritone.getPathingControlManager().mostRecentInControl().<String>map(IBaritoneProcess::displayName).orElse("nobody"))
               .append('/')
               .append(
                  iBaritone.getPathingControlManager().mostRecentCommand().map(pathingCommand -> String.valueOf(pathingCommand.commandType)).orElse("none")
               )
               .append(var5.isPathing() ? " pathing" : " idle")
               .append(var5.getInProgress().isPresent() ? " calculating" : "")
               .append(" goal=")
               .append(var5.getGoal())
               .append(this.describeGoal(var5.getGoal()));
            if (this.finishProcess != null) {
               var6.append(" | finish=").append(this.finishProcess.mode()).append('/').append(this.finishProcess.remaining()).append(" left");
            }

            if (!string2.isEmpty()) {
               var6.append(" | ").append(string2);
            }

            DebugLog.detail(var6.toString());
         }
      }
   }

   private void watchBuild(IBaritone iBaritone) {
      class_310 var2 = class_310.method_1551();
      if (var2 != null && var2.field_1724 != null) {
         class_2338 var3 = var2.field_1724.method_24515();
         int var4 = this.finishProcess != null ? this.finishProcess.completed() : 0;
         int var5 = this.correctSince.size();
         if (var5 == this.lastPlacedCount && var4 == this.lastCompletedTasks) {
            if (++this.positionSampleTimer >= 10) {
               this.positionSampleTimer = 0;
               this.recentBuildPositions.addLast(var3);

               while (this.recentBuildPositions.size() > 16) {
                  this.recentBuildPositions.removeFirst();
               }
            }

            if (this.recentBuildPositions.size() >= 6 && isOscillatingLocally(this.recentBuildPositions)) {
               DebugLog.detail(
                  "Local oscillation detected around " + var3.method_23854() + " across " + this.recentBuildPositions.size() + " samples with 0 blocks placed."
               );
               this.handleOscillationOrStall(iBaritone, true);
            } else {
               this.buildStallTicks++;
               if (this.buildStallTicks % 60 == 0) {
                  this.buildStallReports++;
                  if (this.buildStallTicks >= 600) {
                     this.buildStallTicks = 0;
                     AutoBuildFarm.chat(
                        "\u00a7cQu\u00e1 tr\u00ecnh x\u00e2y b\u1ecb k\u1eb9t/\u0111\u1ee9ng y\u00ean qu\u00e1 30s -> T\u1ef1 \u0111\u1ed9ng k\u1ebft n\u1ed1i l\u1ea1i (Auto Rejoin)\u2026"
                     );
                     AutoRejoinHandler.getInstance().trigger("K\u1eb9t ti\u1ebfn tr\u00ecnh x\u00e2y qu\u00e1 30 gi\u00e2y");
                  } else {
                     IPathingBehavior var6 = iBaritone.getPathingBehavior();
                     String var7 = iBaritone.getPathingControlManager().mostRecentInControl().<String>map(IBaritoneProcess::displayName).orElse("nobody");
                     String var8 = iBaritone.getPathingControlManager()
                        .mostRecentCommand()
                        .map(pathingCommand -> String.valueOf(pathingCommand.commandType))
                        .orElse("none");
                     String var9 = "\u2026 build stuck "
                        + this.buildStallTicks / 20
                        + "s @ "
                        + var3.method_10263()
                        + ","
                        + var3.method_10264()
                        + ","
                        + var3.method_10260()
                        + " \u2014 in control: "
                        + var7
                        + " ("
                        + var8
                        + "), pathing: "
                        + (var6.isPathing() ? "yes" : "no")
                        + (var6.getInProgress().isPresent() ? ", calculating" : "")
                        + ", goal: "
                        + var6.getGoal()
                        + this.describeGoal(var6.getGoal());
                     DebugLog.detail(this.describeFrozenBuilder(iBaritone, var2));
                     if (this.buildStallReports <= 8) {
                        AutoBuildFarm.chat(var9);
                     } else {
                        DebugLog.detail(var9);
                     }

                     if (this.finishProcess != null) {
                        this.finishProcess.diagnoseNow();
                     }

                     if (this.checkBuildingMaterials(iBaritone)) {
                        this.buildStallTicks = 0;
                        this.buildStallReports = 0;
                        this.recentBuildPositions.clear();
                     } else {
                        this.handleOscillationOrStall(iBaritone, false);
                     }
                  }
               }
            }
         } else {
            this.lastPlacedCount = var5;
            this.lastCompletedTasks = var4;
            this.lastStationaryPos = var3;
            this.lastFeet = var3;
            this.buildStallTicks = 0;
            this.buildStallReports = 0;
            this.recentBuildPositions.clear();
         }
      }
   }

   private String describeFrozenBuilder(IBaritone iBaritone, class_310 arg) {
      StringBuilder var3 = new StringBuilder("    frozen: ");
      IInputOverrideHandler var4 = iBaritone.getInputOverrideHandler();
      StringBuilder var5 = new StringBuilder();

      for (Input var9 : new Input[]{Input.CLICK_LEFT, Input.CLICK_RIGHT, Input.SNEAK, Input.MOVE_FORWARD, Input.MOVE_BACK, Input.JUMP}) {
         if (var4.isInputForcedDown(var9)) {
            var5.append(var5.length() == 0 ? "" : "+").append(var9);
         }
      }

      var3.append("baritone holding [").append(var5.length() == 0 ? "nothing" : var5).append(']');
      var3.append(", hand=").append(arg.field_1724.method_6047().method_7909());
      class_239 var10 = arg.field_1765;
      if (var10 instanceof class_3965 var11 && var10.method_17783() == class_240.field_1332) {
         class_2338 var13 = var11.method_17777();
         var3.append(", aiming at ")
            .append(var13.method_10263())
            .append(',')
            .append(var13.method_10264())
            .append(',')
            .append(var13.method_10260())
            .append('=')
            .append(arg.field_1687.method_8320(var13).method_26204().method_8389())
            .append(" side=")
            .append(var11.method_17780());
      } else {
         var3.append(", aiming at nothing");
      }

      var3.append(", onGround=").append(arg.field_1724.method_24828()).append(", inWater=").append(arg.field_1724.method_5799());
      class_2338 var12 = arg.field_1724.method_24515();
      var3.append(", feet=")
         .append(describeForWater(arg, var12))
         .append(", below=")
         .append(describeForWater(arg, var12.method_10074()))
         .append(", head=")
         .append(describeForWater(arg, var12.method_10084()));
      return var3.toString();
   }

   private static String describeForWater(class_310 arg, class_2338 arg2) {
      class_2680 var2 = arg.field_1687.method_8320(arg2);
      String var3 = String.valueOf(var2.method_26204().method_8389());
      if (var2.method_28498(class_2741.field_12508) && (Boolean)var2.method_11654(class_2741.field_12508)) {
         var3 = var3 + "[waterlogged]";
      }

      if (!var2.method_26227().method_15769()) {
         var3 = var3 + "+" + (var2.method_26227().method_15767(class_3486.field_15518) ? "lava" : "water");
      }

      return var3;
   }

   private static boolean isOscillatingLocally(Collection<class_2338> collection) {
      if (collection.size() < 6) {
         return false;
      }

      int var1 = Integer.MAX_VALUE;
      int var2 = Integer.MIN_VALUE;
      int var3 = Integer.MAX_VALUE;
      int var4 = Integer.MIN_VALUE;
      int var5 = Integer.MAX_VALUE;
      int var6 = Integer.MIN_VALUE;
      HashSet var7 = new HashSet();

      for (class_2338 var9 : collection) {
         var1 = Math.min(var1, var9.method_10263());
         var2 = Math.max(var2, var9.method_10263());
         var3 = Math.min(var3, var9.method_10264());
         var4 = Math.max(var4, var9.method_10264());
         var5 = Math.min(var5, var9.method_10260());
         var6 = Math.max(var6, var9.method_10260());
         var7.add(var9);
      }

      return var2 - var1 <= 4 && var4 - var3 <= 2 && var6 - var5 <= 4 && var7.size() >= 2 && var7.size() <= 4;
   }

   private void tryPillarUp(IBaritone iBaritone, class_310 arg) {
      if (arg.field_1724 != null && arg.field_1687 != null) {
         class_2338 var3 = arg.field_1724.method_24515();
         class_2680 var4 = arg.field_1687.method_8320(var3.method_10086(2));
         if (!var4.method_26215() && var4.method_26212(arg.field_1687, var3.method_10086(2))) {
            DebugLog.detail("tryPillarUp blocked: solid block above head at " + var3.method_10086(2).method_23854());
         } else {
            int var5 = InventoryHelper.count(arg.field_1724, class_1802.field_20412);
            if (var5 > 0) {
               InventoryHelper.ensureHotbarSupplied(arg, class_1802.field_20412);
               int var6 = InventoryHelper.findInHotbar(arg.field_1724, class_1802.field_20412);
               if (var6 >= 0) {
                  InventoryHelper.selectHotbarSlot(arg, var6);
               }
            } else {
               int var9 = InventoryHelper.count(arg.field_1724, class_1802.field_8831);
               if (var9 <= 0) {
                  if (!RestockController.getInstance().isBusy()) {
                     RestockController.getInstance().requestRestock(class_1802.field_20412);
                  }

                  return;
               }

               InventoryHelper.ensureHotbarSupplied(arg, class_1802.field_8831);
               int var7 = InventoryHelper.findInHotbar(arg.field_1724, class_1802.field_8831);
               if (var7 >= 0) {
                  InventoryHelper.selectHotbarSlot(arg, var7);
               }
            }

            try {
               iBaritone.getInputOverrideHandler().clearAllKeys();
               iBaritone.getPathingBehavior().cancelEverything();
            } catch (Throwable var8) {
            }

            if (arg.field_1724.method_24828() || arg.field_1724.method_5799()) {
               arg.field_1724.method_6043();
               this.elevatorTicks = 1;
               this.elevatorTargetPos = var3;
               DebugLog.detail("tryPillarUp jumped at " + var3.method_23854() + ", elevator primed.");
            }
         }
      }
   }

   private boolean placeBlockUnderFeet(class_310 arg, class_2338 arg2) {
      if (arg.field_1687 != null && arg.field_1724 != null && arg.field_1761 != null) {
         class_2680 var3 = arg.field_1687.method_8320(arg2);
         if (!var3.method_26215() && !var3.method_45474()) {
            return true;
         }

         class_2338 var4 = arg2.method_10074();
         class_2680 var5 = arg.field_1687.method_8320(var4);
         if (!var5.method_26215() && var5.method_26212(arg.field_1687, var4)) {
            class_3965 var14 = new class_3965(
               new class_243(arg2.method_10263() + 0.5, arg2.method_10264(), arg2.method_10260() + 0.5), class_2350.field_11036, var4, false
            );
            class_1269 var15 = arg.field_1761.method_2896(arg.field_1724, class_1268.field_5808, var14);
            return var15.method_23665();
         }

         for (class_2350 var9 : class_2350.values()) {
            if (var9 != class_2350.field_11036 && var9 != class_2350.field_11033) {
               class_2338 var10 = arg2.method_10093(var9);
               class_2680 var11 = arg.field_1687.method_8320(var10);
               if (!var11.method_26215() && var11.method_26212(arg.field_1687, var10)) {
                  class_3965 var12 = new class_3965(
                     new class_243(
                        arg2.method_10263() + 0.5 + var9.method_10148() * 0.5, arg2.method_10264() + 0.5, arg2.method_10260() + 0.5 + var9.method_10165() * 0.5
                     ),
                     var9.method_10153(),
                     var10,
                     false
                  );
                  class_1269 var13 = arg.field_1761.method_2896(arg.field_1724, class_1268.field_5808, var12);
                  if (var13.method_23665()) {
                     return true;
                  }
               }
            }
         }

         return false;
      } else {
         return false;
      }
   }

   private boolean isMissingInWorld(class_2338 arg) {
      if (this.schematic != null && this.origin != null) {
         class_310 var2 = class_310.method_1551();
         if (var2 != null && var2.field_1687 != null) {
            int var3 = arg.method_10263() - this.origin.method_10263();
            int var4 = arg.method_10264() - this.origin.method_10264();
            int var5 = arg.method_10260() - this.origin.method_10260();
            if (var3 >= 0 && var3 < this.schematic.widthX() && var4 >= 0 && var4 < this.schematic.heightY() && var5 >= 0 && var5 < this.schematic.lengthZ()) {
               class_2680 var6 = this.schematic.getDirect(var3, var4, var5);
               if (var6 != null && !var6.method_26215()) {
                  class_2248 var7 = var6.method_26204();
                  if (var7 != class_2246.field_10382
                     && var7 != class_2246.field_10164
                     && var7 != class_2246.field_10243
                     && var7 != class_2246.field_10543
                     && var7 != class_2246.field_10369) {
                     class_2680 var8 = var2.field_1687.method_8320(arg);
                     return SkipSchematic.isIce(var7) ? !SkipSchematic.isGlass(var8.method_26204()) : var8.method_26204() != var7;
                  } else {
                     return false;
                  }
               } else {
                  return false;
               }
            } else {
               return false;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private void handleOscillationOrStall(IBaritone iBaritone, boolean bl) {
      class_310 var3 = class_310.method_1551();
      if (var3 != null && var3.field_1724 != null) {
         class_2338 var4 = var3.field_1724.method_24515();
         IPathingBehavior var5 = iBaritone.getPathingBehavior();
         if (this.checkBuildingMaterials(iBaritone)) {
            this.buildStallTicks = 0;
            this.buildStallReports = 0;
            this.recentBuildPositions.clear();
         } else if (var4.method_10264() <= this.currentCeilingY - 1) {
            AutoBuildFarm.chat(
               "\u00a7e\u26a0 Bot b\u1ecb t\u1ee5t xu\u1ed1ng t\u1ea7ng th\u1ea5p h\u01a1n (Y="
                  + var4.method_10264()
                  + " < "
                  + this.currentCeilingY
                  + ") \u2014 n\u1edbi l\u1ecfng penalty & k\u00edch ho\u1ea1t nh\u1ea3y \u0111\u1eb7t kh\u1ed1i (pillar up)\u2026"
            );
            DebugLog.detail(
               "feet Y=" + var4.method_10264() + " <= currentCeilingY - 1 (" + (this.currentCeilingY - 1) + "), relaxing penalties and calling tryPillarUp."
            );

            try {
               Settings var17 = BaritoneAPI.getSettings();
               var17.blockPlacementPenalty.value = 1.0;
               var17.allowPlace.value = true;
               var17.allowParkour.value = true;
               var17.allowParkourAscend.value = true;
               var17.allowParkourPlace.value = true;
            } catch (Throwable var13) {
            }

            this.buildStallTicks = 0;
            this.buildStallReports = 0;
            this.recentBuildPositions.clear();
            this.tryPillarUp(iBaritone, var3);
         } else {
            if (!bl && this.buildStallReports == 1 && this.override != null) {
               boolean var6 = this.override.relaxPlacementPenalty();
               boolean var7 = this.override.relaxBlocksToAvoid();
               if (var6 || var7) {
                  AutoBuildFarm.chat("\u2026 loosening pathfinding (scaffolding & avoidance relaxed).");
                  return;
               }
            }

            ArrayList var16 = new ArrayList();
            class_239 var18 = var3.field_1765;
            if (var18 instanceof class_3965 var8 && var18.method_17783() == class_240.field_1332) {
               class_2338 var9 = var8.method_17777();
               if (var9.method_10264() <= this.currentCeilingY && !this.skipped.contains(var9)) {
                  var16.add(var9);
               }
            }

            class_2338[] var19 = new class_2338[]{var4, var4.method_10084(), var4.method_10074()};

            for (class_2338 var12 : var19) {
               if (var12.method_10264() <= this.currentCeilingY && this.isMissingInWorld(var12) && !this.skipped.contains(var12) && !var16.contains(var12)) {
                  var16.add(var12);
               }
            }

            try {
               var5.getPath().ifPresent(iPath -> {
                  Goal var3x = iPath.getGoal();
                  if (var3x != null) {
                     for (class_2338 var5x : goalTargetBlocks(var3x)) {
                        if (!this.skipped.contains(var5x) && !var16.contains(var5x)) {
                           var16.add(var5x);
                        }
                     }
                  }
               });
            } catch (Throwable var15) {
            }

            for (class_2338 var25 : goalTargetBlocks(var5.getGoal())) {
               if (!this.skipped.contains(var25) && !var16.contains(var25)) {
                  var16.add(var25);
               }
            }

            for (int var22 = -4; var22 <= 4; var22++) {
               for (int var26 = -2; var26 <= 2; var26++) {
                  for (int var29 = -4; var29 <= 4; var29++) {
                     class_2338 var32 = var4.method_10069(var22, var26, var29);
                     if (var32.method_10264() <= this.currentCeilingY
                        && this.isMissingInWorld(var32)
                        && !this.skipped.contains(var32)
                        && !var16.contains(var32)) {
                        var16.add(var32);
                     }
                  }
               }
            }

            var16.sort(Comparator.comparingDouble(arg2 -> arg2.method_10262(var4)));
            if (var16.isEmpty()) {
               List var23 = this.missingPositionsOnLayer(this.currentCeilingY);
               if (!var23.isEmpty()) {
                  ArrayList var27 = new ArrayList(var23);
                  var27.removeIf(this.skipped::contains);
                  var27.sort(Comparator.comparingDouble(arg2 -> arg2.method_10262(var4)));
                  if (!var27.isEmpty()) {
                     var16.add((class_2338)var27.get(0));
                  }
               }
            }

            int var24 = 0;
            class_2338 var28 = null;

            for (class_2338 var33 : var16) {
               if (this.skipped.add(var33)) {
                  this.stuckSkipped.add(var33);
                  if (var28 == null) {
                     var28 = var33;
                  }

                  if (++var24 >= 2) {
                     break;
                  }
               }
            }

            try {
               iBaritone.getInputOverrideHandler().clearAllKeys();
               iBaritone.getPathingBehavior().cancelEverything();
               if (var3.field_1724.method_24828()) {
                  var3.field_1724.method_6043();
               }
            } catch (Throwable var14) {
            }

            this.buildStallTicks = 0;
            this.buildStallReports = 0;
            this.recentBuildPositions.clear();
            if (var28 != null) {
               String var31 = bl ? "bot \u0111i qua l\u1ea1i t\u1ea1i " + var4.method_23854() : "k\u1eb9t t\u1ea1i " + var4.method_23854();
               AutoBuildFarm.chat(
                  "\u23f3 Ph\u00e1t hi\u1ec7n "
                     + var31
                     + " \u2014 t\u1ea1m ho\u00e3n kh\u1ed1i "
                     + var28.method_23854()
                     + " \u0111\u1ec3 ti\u1ebfp t\u1ee5c c\u00e1c kh\u1ed1i kh\u00e1c (s\u1ebd quay l\u1ea1i ho\u00e0n thi\u1ec7n)."
               );
               DebugLog.detail(
                  "Unstick "
                     + (bl ? "OSCILLATION" : "STALL")
                     + " at "
                     + var4.method_23854()
                     + ", skipped: "
                     + var28.method_23854()
                     + ", total skipped="
                     + this.skipped.size()
               );
            } else {
               DebugLog.detail("Unstick triggered at " + var4.method_23854() + " with no new candidates to skip; re-issuing build");
            }

            this.issueBuild(iBaritone);
         }
      }
   }

   private void checkFloating(IBaritone iBaritone) {
      if (++this.floatTicks % 20 == 0) {
         if (!this.unskipPlaceable(iBaritone)) {
            IPathingBehavior var2 = iBaritone.getPathingBehavior();
            List var3 = this.floatingTargets(var2.getGoal());
            class_2338 var4 = !var3.isEmpty() && !var2.isPathing() ? (class_2338)var3.get(0) : null;
            if (var4 != null && var4.equals(this.floatingGoal)) {
               int var5 = neighbourhoodLoaded(var4) ? 2 : 6;
               if (++this.floatingChecks >= var5) {
                  this.floatingGoal = null;
                  this.floatingChecks = 0;
                  ArrayList var6 = new ArrayList();
                  collectLeafGoals(var2.getGoal(), var6, 0);
                  boolean var7 = !var6.isEmpty() && var6.size() == var3.size();
                  List var8 = var7 ? var3 : List.of(var4);
                  int var9 = 0;

                  for (class_2338 var11 : var8) {
                     if (this.skipped.add(var11)) {
                        this.floatSkipped.add(var11);
                        var9++;
                     }
                  }

                  if (var9 != 0) {
                     this.buildStallTicks = 0;
                     AutoBuildFarm.chat(
                        "\u2026 "
                           + (var8.size() == 1 ? var4.method_23854() : var8.size() + " positions")
                           + " hanging in the air with nothing to place against \u2014 skipping until neighbours are up."
                     );
                     DebugLog.detail("floating skip " + positions(var8) + ", set now " + positions(this.skipped));
                     this.issueBuild(iBaritone);
                  }
               }
            } else {
               this.floatingGoal = var4;
               this.floatingChecks = var4 == null ? 0 : 1;
            }
         }
      }
   }

   private boolean unskipPlaceable(IBaritone iBaritone) {
      if (this.floatSkipped.isEmpty()) {
         return false;
      }

      ArrayList var2 = new ArrayList();

      for (class_2338 var4 : this.floatSkipped) {
         if (hasFaceToPlaceAgainst(var4)) {
            var2.add(var4);
         }
      }

      if (var2.isEmpty()) {
         return false;
      }

      this.floatSkipped.removeAll(var2);
      this.skipped.removeAll(var2);
      this.buildStallTicks = 0;
      AutoBuildFarm.chat(
         "\u2026 " + ((class_2338)var2.get(0)).method_23854() + " has something to build against now \u2014 putting " + var2.size() + " position(s) back in."
      );
      DebugLog.detail("unskip " + positions(var2) + ", skip set now " + positions(this.skipped));
      this.issueBuild(iBaritone);
      return true;
   }

   private List<class_2338> floatingTargets(Object object) {
      ArrayList var2 = new ArrayList();
      collectLeafGoals(object, var2, 0);
      ArrayList var3 = new ArrayList();

      for (Goal var5 : var2) {
         if (var5 instanceof IGoalRenderPos var6 && var5.getClass().getSimpleName().contains("GoalPlace")) {
            class_2338 var7 = var6.getGoalPos().method_10074();
            if (!hasFaceToPlaceAgainst(var7)) {
               var3.add(var7);
            }
         }
      }

      return var3;
   }

   private static boolean neighbourhoodLoaded(class_2338 arg) {
      class_310 var1 = class_310.method_1551();
      if (var1.field_1687 == null) {
         return false;
      }

      for (class_2350 var3 : class_2353.field_11062) {
         class_2338 var4 = arg.method_10093(var3);
         if (var1.field_1687.method_2935().method_21730(var4.method_10263() >> 4, var4.method_10260() >> 4) == null) {
            return false;
         }
      }

      return var1.field_1687.method_2935().method_21730(arg.method_10263() >> 4, arg.method_10260() >> 4) != null;
   }

   private static boolean hasFaceToPlaceAgainst(class_2338 arg) {
      class_310 var1 = class_310.method_1551();
      if (var1.field_1687 == null) {
         return true;
      }

      for (class_2350 var5 : class_2350.values()) {
         if (var5 != class_2350.field_11036) {
            class_2338 var6 = arg.method_10093(var5);
            class_2680 var7 = var1.field_1687.method_8320(var6);
            if (!var7.method_26215()
               && !var7.method_45474()
               && var7.method_26204() != class_2246.field_10382
               && var7.method_26204() != class_2246.field_10164
               && !var7.method_26218(var1.field_1687, var6).method_1110()) {
               return true;
            }
         }
      }

      return false;
   }

   private void issueBuild(IBaritone iBaritone) {
      this.builderIdleTicks = 0;
      if (this.schematic != null && this.origin != null) {
         iBaritone.getBuilderProcess().build("farm", new SkipSchematic(this.schematic, this.origin, this.skipped, this.currentCeilingY), this.origin);
         if (iBaritone.getBuilderProcess().isPaused()) {
            iBaritone.getBuilderProcess().resume();
         }
      } else {
         iBaritone.getBuilderProcess().buildOpenLitematic(this.placementIndex);
      }
   }

   private static List<Integer> collectLayers(IStaticSchematic iStaticSchematic, class_2382 arg, List<FinishTask> list) {
      TreeSet var3 = new TreeSet();
      int var4 = arg.method_10264();

      for (int var5 = 0; var5 < iStaticSchematic.heightY(); var5++) {
         boolean var6 = false;

         for (int var7 = 0; var7 < iStaticSchematic.widthX(); var7++) {
            for (int var8 = 0; var8 < iStaticSchematic.lengthZ(); var8++) {
               class_2680 var9 = iStaticSchematic.getDirect(var7, var5, var8);
               if (var9 != null
                  && !var9.method_26215()
                  && var9.method_26204() != class_2246.field_10243
                  && var9.method_26204() != class_2246.field_10543
                  && var9.method_26204() != class_2246.field_10369) {
                  var6 = true;
                  break;
               }
            }

            if (var6) {
               break;
            }
         }

         if (var6) {
            var3.add(var4 + var5);
         }
      }

      for (FinishTask var11 : list) {
         var3.add(var11.pos().method_10264());
      }

      return new ArrayList<>(var3);
   }

   private static List<class_2338> goalTargetBlocks(Object object) {
      ArrayList var1 = new ArrayList();
      collectLeafGoals(object, var1, 0);
      ArrayList var2 = new ArrayList();

      for (Goal var4 : var1) {
         if (var4 instanceof IGoalRenderPos var5) {
            class_2338 var6 = var5.getGoalPos();
            var2.add(var4.getClass().getSimpleName().contains("GoalPlace") ? var6.method_10074() : var6);
         }
      }

      return var2;
   }

   private static String positions(Collection<class_2338> collection) {
      StringBuilder var1 = new StringBuilder("[");

      for (class_2338 var3 : collection) {
         var1.append(var1.length() > 1 ? "; " : "").append(var3.method_23854());
      }

      return var1.append(']').toString();
   }

   private String describeGoal(Object object) {
      ArrayList var2 = new ArrayList();
      collectLeafGoals(object, var2, 0);
      StringBuilder var3 = new StringBuilder();

      for (int var4 = 0; var4 < Math.min(2, var2.size()); var4++) {
         if (var2.get(var4) instanceof IGoalRenderPos var5) {
            class_2338 var7 = var5.getGoalPos();
            var3.append(" | stand ")
               .append(var7.method_23854())
               .append(": floor=")
               .append(describeBlock(var7.method_10074()))
               .append(", feet=")
               .append(describeBlock(var7))
               .append(", head=")
               .append(describeBlock(var7.method_10084()));
         }
      }

      return var3.toString();
   }

   private static String describeBlock(class_2338 arg) {
      class_310 var1 = class_310.method_1551();
      if (var1.field_1687 == null) {
         return "?";
      }

      class_2680 var2 = var1.field_1687.method_8320(arg);
      String var3 = class_7923.field_41175.method_10221(var2.method_26204()).method_12832();
      return var2.method_26227().method_15769() ? var3 : var3 + "+fluid";
   }

   private static void collectLeafGoals(Object object, List<Goal> list, int i) {
      if (object != null && i <= 4 && list.size() < 64) {
         if (object instanceof IGoalRenderPos) {
            list.add((Goal)object);
         } else if (object instanceof GoalComposite var14) {
            for (Goal var18 : var14.goals()) {
               collectLeafGoals(var18, list, i + 1);
            }
         } else if (object instanceof Goal) {
            for (Field var6 : object.getClass().getDeclaredFields()) {
               try {
                  var6.setAccessible(true);
                  Object var7 = var6.get(object);
                  if (var7 instanceof Object[] var8) {
                     for (Object var12 : var8) {
                        collectLeafGoals(var12, list, i + 1);
                     }
                  } else {
                     collectLeafGoals(var7, list, i + 1);
                  }
               } catch (ReflectiveOperationException | RuntimeException var13) {
               }
            }
         }
      }
   }

   private void tickFinishing() {
      class_310 var1 = class_310.method_1551();
      if (this.finishProcess != null && var1.field_1724 != null && var1.field_1687 != null) {
         IBaritone var2 = baritone();
         if (var2 != null) {
            this.trace("SWEEP", var2, "stall=" + this.stallTicks + "t");
         }

         int var3 = this.finishProcess.remaining();
         if (var3 != this.lastRemaining) {
            this.lastRemaining = var3;
            this.stallTicks = 0;
         } else if (++this.stallTicks > 1200) {
            this.finishProcess.abort("stuck for 60s with " + var3 + " left \u2014 is something blocking the way?");
            return;
         }

         this.finishProcess.rearm();
      }
   }

   private void beginFinishing() {
      IBaritone var1 = baritone();
      if (var1 != null) {
         int var2 = this.rescanUnwaterloggedLeaves(Integer.MAX_VALUE);
         if (var2 > 0) {
            AutoBuildFarm.chat(
               "Rescan: ph\u00e1t hi\u1ec7n "
                  + var2
                  + " kh\u1ed1i l\u00e1 ch\u01b0a c\u00f3 n\u01b0\u1edbc \u2014 \u0111ang ti\u1ebfn h\u00e0nh \u0111\u1ed5 n\u01b0\u1edbc\u2026"
            );
         }

         this.plan = mergePlans(this.plan, this.rescan());
         if (this.plan.isEmpty()) {
            AutoBuildFarm.chat("Nothing to finish \u2014 no fluids or redstone timings in this schematic.");
            this.state = FarmBuildController.State.IDLE;
            this.restoreSettings();
         } else {
            if (this.override == null) {
               this.override = FarmBuildController.BuildSettingsOverride.apply(this.plan);
            }

            this.lastRemaining = -1;
            this.stallTicks = 0;
            this.state = FarmBuildController.State.FINISHING;
            FinishProcess var3 = this.ensureProcess(var1);
            if (var3.mode() == FinishProcess.Mode.OFF) {
               var3.start(new ArrayList<>(this.plan), this::onFinishingDone);
            } else {
               var3.retryAbandoned();
               var3.addTasks(this.plan);
            }

            var3.rearm();
            AutoBuildFarm.chat("Left to finish: " + var3.remaining() + " position(s).");
            var3.beginSweep();
         }
      }
   }

   private void onFinishingDone(FinishProcess.Result result) {
      this.state = FarmBuildController.State.IDLE;
      this.restoreSettings();
      if (result.clean()) {
         AutoBuildFarm.chat("Farm complete \u2014 " + result.completed() + " position(s) finished.");
      } else if (result.message() != null) {
         AutoBuildFarm.chat("Finishing stopped after " + result.completed() + " position(s): " + result.message());
      } else {
         AutoBuildFarm.chat(
            "Finished " + result.completed() + " position(s), " + result.abandoned().size() + " position(s) skipped. /buildfarm resume to retry them."
         );
      }
   }

   public int rescanUnwaterloggedLeaves(int i) {
      if (this.schematic != null && this.origin != null) {
         class_310 var2 = class_310.method_1551();
         if (var2 != null && var2.field_1687 != null) {
            int var3 = this.schematic.widthX();
            int var4 = this.schematic.heightY();
            int var5 = this.schematic.lengthZ();
            ArrayList var6 = new ArrayList();

            for (int var7 = 0; var7 < var4; var7++) {
               int var8 = this.origin.method_10264() + var7;
               if (var8 <= i) {
                  for (int var9 = 0; var9 < var3; var9++) {
                     for (int var10 = 0; var10 < var5; var10++) {
                        class_2338 var11 = new class_2338(this.origin.method_10263() + var9, var8, this.origin.method_10260() + var10);
                        class_2680 var12 = var2.field_1687.method_8320(var11);
                        if (var12.method_26204() instanceof class_2397
                           && this.isWaterlogDesired(var11)
                           && var12.method_28498(class_2741.field_12508)
                           && !(Boolean)var12.method_11654(class_2741.field_12508)) {
                           class_2680 var13 = this.desiredStateAt(var11);
                           var6.add(new FinishTask(FinishTask.Type.WATERLOG, var11, var13 != null ? var13 : var12));
                        }
                     }
                  }
               }
            }

            if (!var6.isEmpty()) {
               IBaritone var14 = baritone();
               if (var14 != null) {
                  FinishProcess var15 = this.ensureProcess(var14);
                  var15.addTasks(var6);

                  for (FinishTask var17 : var6) {
                     var15.markLeafSeen(var17.pos());
                  }

                  this.plan = mergePlans(this.plan, var6);
                  DebugLog.detail("rescanUnwaterloggedLeaves: queued " + var6.size() + " dry leaf task(s) up to Y=" + i);
               }
            }

            return var6.size();
         } else {
            return 0;
         }
      } else {
         return 0;
      }
   }

   public int countUnfinishedLava(int i) {
      if (this.plan == null) {
         return 0;
      }

      class_310 var2 = class_310.method_1551();
      if (var2 != null && var2.field_1687 != null) {
         int var3 = 0;

         for (FinishTask var5 : this.plan) {
            if (var5.type() == FinishTask.Type.LAVA_SOURCE && var5.pos().method_10264() <= i && !var5.satisfied(var2.field_1687)) {
               var3++;
            }
         }

         return var3;
      } else {
         return 0;
      }
   }

   public int countDoableUnfinishedLava(int i) {
      if (this.plan == null) {
         return 0;
      }

      class_310 var2 = class_310.method_1551();
      if (var2 != null && var2.field_1687 != null) {
         int var3 = 0;

         for (FinishTask var5 : this.plan) {
            if (var5.type() == FinishTask.Type.LAVA_SOURCE && var5.pos().method_10264() <= i && !var5.satisfied(var2.field_1687) && var5.ready(var2.field_1687)
               )
             {
               var3++;
            }
         }

         return var3;
      } else {
         return 0;
      }
   }

   public int rescanUnpouredLava(int i) {
      if (this.plan == null) {
         return 0;
      }

      class_310 var2 = class_310.method_1551();
      if (var2 != null && var2.field_1687 != null) {
         ArrayList var3 = new ArrayList();

         for (FinishTask var5 : this.plan) {
            if (var5.type() == FinishTask.Type.LAVA_SOURCE && var5.pos().method_10264() <= i && !var5.satisfied(var2.field_1687) && var5.ready(var2.field_1687)
               )
             {
               var3.add(var5);
            }
         }

         if (!var3.isEmpty()) {
            IBaritone var6 = baritone();
            if (var6 != null) {
               FinishProcess var7 = this.ensureProcess(var6);
               var7.retrySpecificTasks(var3);
               DebugLog.detail("rescanUnpouredLava: re-queued " + var3.size() + " unpoured lava task(s) up to Y=" + i);
            }
         }

         return var3.size();
      } else {
         return 0;
      }
   }

   private List<FinishTask> rescan() {
      Optional var1 = LitematicaBridge.load(this.placementIndex);
      List var2 = new ArrayList<>(
         var1.<List<? extends FinishTask>>map(placement -> PlanScanner.scan(placement.schematic(), placement.origin())).orElse(List.of())
      );
      class_310 var3 = class_310.method_1551();
      if (var3 != null && var3.field_1687 != null && this.origin != null && this.schematic != null) {
         int var4 = this.schematic.widthX();
         int var5 = this.schematic.heightY();
         int var6 = this.schematic.lengthZ();
         ArrayList var7 = new ArrayList();

         for (int var8 = 0; var8 < var5; var8++) {
            int var9 = this.origin.method_10264() + var8;

            for (int var10 = 0; var10 < var4; var10++) {
               for (int var11 = 0; var11 < var6; var11++) {
                  class_2338 var12 = new class_2338(this.origin.method_10263() + var10, var9, this.origin.method_10260() + var11);
                  class_2680 var13 = var3.field_1687.method_8320(var12);
                  if (var13.method_26204() instanceof class_2397
                     && this.isWaterlogDesired(var12)
                     && var13.method_28498(class_2741.field_12508)
                     && !(Boolean)var13.method_11654(class_2741.field_12508)) {
                     class_2680 var14 = this.desiredStateAt(var12);
                     var7.add(new FinishTask(FinishTask.Type.WATERLOG, var12, var14 != null ? var14 : var13));
                  }
               }
            }
         }

         if (!var7.isEmpty()) {
            var2 = mergePlans(var2, var7);
         }
      }

      return var2;
   }

   private static List<FinishTask> mergePlans(List<FinishTask> list, List<FinishTask> list2) {
      if (list.isEmpty()) {
         return list2;
      }

      if (list2.isEmpty()) {
         return list;
      }

      LinkedHashSet var2 = new LinkedHashSet(list);
      var2.addAll(list2);
      return new ArrayList<>(var2);
   }

   private FinishProcess ensureProcess(IBaritone iBaritone) {
      if (this.finishProcess == null || this.boundTo != iBaritone) {
         this.finishProcess = new FinishProcess(iBaritone);
         iBaritone.getPathingControlManager().registerProcess(this.finishProcess);
         this.boundTo = iBaritone;
      }

      return this.finishProcess;
   }

   private void restoreSettings() {
      if (this.override != null) {
         this.override.restore();
         this.override = null;
      }
   }

   private void reportBucketBudget() {
      class_310 var1 = class_310.method_1551();
      class_746 var2 = var1.field_1724;
      if (var2 != null) {
         int var3 = 0;
         int var4 = 0;

         for (FinishTask var6 : this.plan) {
            class_1792 var7 = var6.requiredItem();
            if (var7 == class_1802.field_8705) {
               var3++;
            } else if (var7 == class_1802.field_8187) {
               var4++;
            }
         }

         if (var3 != 0 || var4 != 0) {
            int var8 = InventoryHelper.count(var2, class_1802.field_8705);
            int var9 = InventoryHelper.count(var2, class_1802.field_8187);
            AutoBuildFarm.chat(
               "Buckets \u2014 water "
                  + var8
                  + "/"
                  + var3
                  + ", lava "
                  + var9
                  + "/"
                  + var4
                  + (var8 >= var3 && var9 >= var4 ? "" : " (short; the pass will stop and tell you when it runs dry)")
            );
         }
      }
   }

   private static IBaritone baritone() {
      try {
         return BaritoneAPI.getProvider().getPrimaryBaritone();
      } catch (Throwable var1) {
         AutoBuildFarm.LOG.warn("Baritone unavailable", var1);
         return null;
      }
   }

   public static float getPlaceReach() {
      return FarmConfig.placeReach;
   }

   public static void setPlaceReach(float f) {
      FarmConfig.placeReach = Math.max(1.5F, Math.min(5.0F, f));
      FarmConfig.save();
      FarmConfig.applyToBaritone();
      FinishProcess.REACH = FarmConfig.placeReach;
      AutoBuildFarm.chat("Kho\u1ea3ng c\u00e1ch \u0111\u1eb7t block (reach) \u0111\u1eb7t th\u00e0nh " + FarmConfig.placeReach + " blocks.");
   }

   public static int getLeafPlaceSpeed() {
      return FarmConfig.leafPlaceSpeed;
   }

   public static void setLeafPlaceSpeed(int i) {
      FarmConfig.leafPlaceSpeed = Math.max(1, i);
      FarmConfig.save();
      AutoBuildFarm.chat(
         "T\u1ed1c \u0111\u1ed9 \u0111\u1eb7t l\u00e1 (leaf speed) \u0111\u1eb7t th\u00e0nh "
            + FarmConfig.leafPlaceSpeed
            + " ticks ("
            + FarmConfig.leafPlaceSpeed * 50
            + "ms/block)."
      );
   }

   public static int getPlaceSpeed() {
      return FarmConfig.placeSpeed;
   }

   public static void setPlaceSpeed(int i) {
      FarmConfig.placeSpeed = Math.max(0, i);
      FarmConfig.save();
      FarmConfig.applyToBaritone();
      AutoBuildFarm.chat(
         "Block placement speed set to "
            + FarmConfig.placeSpeed
            + " ticks ("
            + (FarmConfig.placeSpeed == 0 ? "instant" : FarmConfig.placeSpeed * 50 + "ms")
            + " per placement)."
      );
   }

   private boolean isTargetingLeaves(IBaritone iBaritone) {
      if (this.schematic != null && this.origin != null && iBaritone != null) {
         try {
            Goal var2 = iBaritone.getPathingBehavior().getGoal();
            if (var2 == null) {
               return false;
            }

            ArrayList var3 = new ArrayList();
            collectLeafGoals(var2, var3, 0);

            for (Goal var5 : var3) {
               if (var5 instanceof IGoalRenderPos var6) {
                  class_2338 var7 = var6.getGoalPos();
                  int var8 = var7.method_10263() - this.origin.method_10263();
                  int var9 = var7.method_10264() - this.origin.method_10264();
                  int var10 = var7.method_10260() - this.origin.method_10260();

                  for (int var11 = -1; var11 <= 1; var11++) {
                     int var12 = var9 + var11;
                     if (var8 >= 0
                        && var8 < this.schematic.widthX()
                        && var12 >= 0
                        && var12 < this.schematic.heightY()
                        && var10 >= 0
                        && var10 < this.schematic.lengthZ()) {
                        class_2680 var13 = this.schematic.desiredState(var8, var12, var10, null, null);
                        if (var13 != null && var13.method_26204() instanceof class_2397) {
                           return true;
                        }
                     }
                  }
               }
            }
         } catch (Throwable var14) {
         }

         return false;
      } else {
         return false;
      }
   }

   private record BuildSettingsOverride(
      List<class_2248> skipBlocks,
      List<class_2248> buildIgnoreBlocks,
      boolean buildIgnoreExisting,
      List<class_2248> blocksToDisallowBreaking,
      List<String> ignoreProperties,
      boolean ignoreDirection,
      Map<class_2248, List<class_2248>> substitutes,
      Map<class_2248, List<class_2248>> validSubstitutes,
      List<class_2248> blocksToAvoid,
      List<class_1792> throwawayItems,
      int rightClickSpeed,
      double blockPlacementPenalty,
      int incorrectSize,
      class_2470 schematicRotation,
      class_2415 schematicMirror,
      boolean assumeWalkOnWater,
      boolean allowPlace,
      boolean allowPlaceInFluidsSource,
      boolean allowPlaceInFluidsFlow,
      boolean allowParkour,
      boolean allowParkourAscend,
      boolean allowParkourPlace,
      boolean allowDiagonalDescend,
      boolean allowDiagonalAscend,
      boolean allowDownward,
      double walkOnWaterOnePenalty,
      int maxFallHeightNoWater,
      float blockReachDistance
   ) {
      private static <T> List<T> safeList(List<T> list) {
         if (list == null) {
            return new ArrayList<>();
         }

         ArrayList var1 = new ArrayList();

         for (Object var3 : list) {
            if (var3 != null) {
               var1.add(var3);
            }
         }

         return var1;
      }

      private static <K, V> Map<K, V> safeMap(Map<K, V> map) {
         return map != null ? new HashMap<>(map) : new HashMap<>();
      }

      static FarmBuildController.BuildSettingsOverride apply(List<FinishTask> list) {
         Settings var1 = BaritoneAPI.getSettings();
         boolean var2 = false;

         try {
            var2 = (Boolean)var1.buildIgnoreExisting.value;
         } catch (Throwable var63) {
         }

         List var3 = safeList((List)var1.buildIgnoreBlocks.value);
         List var4 = safeList((List)var1.blocksToDisallowBreaking.value);
         float var5 = 4.5F;

         try {
            if (var1.blockReachDistance != null && var1.blockReachDistance.value != null) {
               var5 = (Float)var1.blockReachDistance.value;
            }
         } catch (Throwable var62) {
         }

         boolean var6 = false;

         try {
            var6 = (Boolean)var1.assumeWalkOnWater.value;
         } catch (Throwable var61) {
         }

         boolean var7 = true;

         try {
            var7 = (Boolean)var1.allowPlace.value;
         } catch (Throwable var60) {
         }

         boolean var8 = false;

         try {
            var8 = (Boolean)var1.allowPlaceInFluidsSource.value;
         } catch (Throwable var59) {
         }

         boolean var9 = false;

         try {
            var9 = (Boolean)var1.allowPlaceInFluidsFlow.value;
         } catch (Throwable var58) {
         }

         boolean var10 = false;

         try {
            var10 = (Boolean)var1.allowParkour.value;
         } catch (Throwable var57) {
         }

         boolean var11 = false;

         try {
            var11 = (Boolean)var1.allowParkourAscend.value;
         } catch (Throwable var56) {
         }

         boolean var12 = false;

         try {
            var12 = (Boolean)var1.allowParkourPlace.value;
         } catch (Throwable var55) {
         }

         boolean var13 = false;

         try {
            var13 = (Boolean)var1.allowDiagonalDescend.value;
         } catch (Throwable var54) {
         }

         boolean var14 = false;

         try {
            var14 = (Boolean)var1.allowDiagonalAscend.value;
         } catch (Throwable var53) {
         }

         boolean var15 = false;

         try {
            var15 = (Boolean)var1.allowDownward.value;
         } catch (Throwable var52) {
         }

         double var16 = 1.0;

         try {
            var16 = (Double)var1.walkOnWaterOnePenalty.value;
         } catch (Throwable var51) {
         }

         int var18 = 3;

         try {
            if (var1.maxFallHeightNoWater != null && var1.maxFallHeightNoWater.value != null) {
               var18 = (Integer)var1.maxFallHeightNoWater.value;
            }
         } catch (Throwable var50) {
         }

         FarmBuildController.BuildSettingsOverride var19 = new FarmBuildController.BuildSettingsOverride(
            safeList((List<class_2248>)var1.buildSkipBlocks.value),
            var3,
            var2,
            var4,
            safeList((List<String>)var1.buildIgnoreProperties.value),
            (Boolean)var1.buildIgnoreDirection.value,
            safeMap((Map<class_2248, List<class_2248>>)var1.buildSubstitutes.value),
            safeMap((Map<class_2248, List<class_2248>>)var1.buildValidSubstitutes.value),
            safeList((List<class_2248>)var1.blocksToAvoid.value),
            safeList((List<class_1792>)var1.acceptableThrowawayItems.value),
            (Integer)var1.rightClickSpeed.value,
            (Double)var1.blockPlacementPenalty.value,
            (Integer)var1.incorrectSize.value,
            (class_2470)var1.buildSchematicRotation.value,
            (class_2415)var1.buildSchematicMirror.value,
            var6,
            var7,
            var8,
            var9,
            var10,
            var11,
            var12,
            var13,
            var14,
            var15,
            var16,
            var18,
            var5
         );

         try {
            var1.buildIgnoreExisting.value = true;
         } catch (Throwable var49) {
         }

         try {
            var1.smoothLook.value = false;
         } catch (Throwable var48) {
         }

         try {
            var1.incorrectSize.value = Math.max((Integer)var1.incorrectSize.value, 2000);
         } catch (Throwable var47) {
         }

         try {
            var1.buildSchematicRotation.value = class_2470.field_11467;
         } catch (Throwable var46) {
         }

         try {
            var1.buildSchematicMirror.value = class_2415.field_11302;
         } catch (Throwable var45) {
         }

         try {
            var1.assumeWalkOnWater.value = true;
         } catch (Throwable var44) {
         }

         try {
            var1.allowPlace.value = true;
         } catch (Throwable var43) {
         }

         try {
            var1.allowPlaceInFluidsSource.value = false;
         } catch (Throwable var42) {
         }

         try {
            var1.allowPlaceInFluidsFlow.value = false;
         } catch (Throwable var41) {
         }

         try {
            var1.allowParkour.value = true;
         } catch (Throwable var40) {
         }

         try {
            var1.allowParkourAscend.value = true;
         } catch (Throwable var39) {
         }

         try {
            var1.allowParkourPlace.value = true;
         } catch (Throwable var38) {
         }

         try {
            var1.allowDiagonalDescend.value = true;
         } catch (Throwable var37) {
         }

         try {
            var1.allowDiagonalAscend.value = true;
         } catch (Throwable var36) {
         }

         try {
            var1.allowDownward.value = true;
         } catch (Throwable var35) {
         }

         try {
            var1.walkOnWaterOnePenalty.value = 1.0;
         } catch (Throwable var34) {
         }

         try {
            if (var1.maxFallHeightNoWater != null) {
               int var20 = var1.maxFallHeightNoWater.value != null ? (Integer)var1.maxFallHeightNoWater.value : 3;
               var1.maxFallHeightNoWater.value = Math.min(var20, 3);
            }
         } catch (Throwable var33) {
         }

         ArrayList var65 = new ArrayList((Collection)var1.acceptableThrowawayItems.value);
         var65.remove(class_1802.field_8535);
         var65.remove(class_1802.field_8554);
         var65.remove(class_1802.field_8281);
         var65.remove(class_1802.field_22421);
         class_310 var21 = class_310.method_1551();
         if (var21.field_1724 != null) {
            for (class_1792 var25 : FinishProcess.SCAFFOLD_ITEMS) {
               if (var25 != class_1802.field_8281
                  && var25 != class_1802.field_22421
                  && var25 != class_1802.field_8535
                  && var25 != class_1802.field_8554
                  && InventoryHelper.count(var21.field_1724, var25) > 0) {
                  addIfMissing(var65, var25);
               }
            }
         }

         var1.acceptableThrowawayItems.value = var65;
         ArrayList var66 = new ArrayList((Collection)var1.blocksToAvoid.value);
         var1.blocksToAvoid.value = var66;
         ArrayList var67 = new ArrayList((Collection)var1.buildSkipBlocks.value);
         addIfMissing(var67, class_2246.field_10382);
         addIfMissing(var67, class_2246.field_10164);
         addIfMissing(var67, class_2246.field_10243);
         addIfMissing(var67, class_2246.field_10543);
         addIfMissing(var67, class_2246.field_10369);
         var1.buildSkipBlocks.value = var67;
         ArrayList var68 = new ArrayList((Collection)var1.buildIgnoreBlocks.value);
         addIfMissing(var68, class_2246.field_10382);
         addIfMissing(var68, class_2246.field_10164);
         addIfMissing(var68, class_2246.field_10243);
         addIfMissing(var68, class_2246.field_10543);
         addIfMissing(var68, class_2246.field_10369);
         var1.buildIgnoreBlocks.value = var68;
         ArrayList var69 = new ArrayList((Collection)var1.blocksToDisallowBreaking.value);
         addIfMissing(var69, class_2246.field_10503);
         addIfMissing(var69, class_2246.field_9988);
         addIfMissing(var69, class_2246.field_10539);
         addIfMissing(var69, class_2246.field_10335);
         addIfMissing(var69, class_2246.field_10098);
         addIfMissing(var69, class_2246.field_10035);
         addIfMissing(var69, class_2246.field_37551);
         addIfMissing(var69, class_2246.field_42731);
         addIfMissing(var69, class_2246.field_28673);
         addIfMissing(var69, class_2246.field_28674);
         addIfMissing(var69, class_2246.field_10540);
         addIfMissing(var69, class_2246.field_22423);
         addIfMissing(var69, class_2246.field_10033);
         addIfMissing(var69, class_2246.field_27115);
         var1.buildIgnoreDirection.value = true;
         ArrayList var26 = new ArrayList((Collection)var1.buildIgnoreProperties.value);
         String[] var27 = new String[]{
            "waterlogged",
            "distance",
            "persistent",
            "delay",
            "mode",
            "facing",
            "axis",
            "half",
            "shape",
            "hinge",
            "open",
            "powered",
            "power",
            "lit",
            "face",
            "attachment",
            "conditional",
            "triggered",
            "locked",
            "extended",
            "enabled",
            "crafting",
            "orientation",
            "rotation",
            "instrument",
            "note",
            "type",
            "layers",
            "stage",
            "age",
            "level",
            "snowy",
            "disarmed",
            "attached",
            "berries",
            "bloom",
            "can_summon",
            "shrieking",
            "sculk_sensor_phase",
            "tilt",
            "unstable",
            "charges",
            "dusted",
            "hatch",
            "eggs",
            "pickles",
            "candles",
            "bites",
            "honey_level",
            "down",
            "up",
            "north",
            "south",
            "east",
            "west",
            "bottom",
            "hanging",
            "signal_fire",
            "eye",
            "drag",
            "vertical_direction",
            "thickness",
            "short",
            "leaves"
         };

         for (String var31 : var27) {
            addIfMissing(var26, var31);
         }

         try {
            for (class_2248 var72 : class_7923.field_41175) {
               for (class_2769 var78 : var72.method_9595().method_11659()) {
                  addIfMissing(var26, var78.method_11899());
               }
            }
         } catch (Throwable var64) {
         }

         var1.buildIgnoreProperties.value = var26;
         List var71 = List.of(class_2246.field_9997, class_2246.field_10087, class_2246.field_10033, class_2246.field_10555, class_2246.field_9996);

         for (class_2248 var76 : var71) {
            addIfMissing(var69, var76);
         }

         var1.blocksToDisallowBreaking.value = var69;
         HashMap var74 = new HashMap((Map)var1.buildSubstitutes.value);
         var74.put(class_2246.field_10225, var71);
         var74.put(class_2246.field_10384, var71);
         var74.put(class_2246.field_10295, var71);
         var74.put(class_2246.field_10110, var71);
         var1.buildSubstitutes.value = var74;
         HashMap var77 = new HashMap((Map)var1.buildValidSubstitutes.value);
         var77.put(class_2246.field_10225, var71);
         var77.put(class_2246.field_10384, var71);
         var77.put(class_2246.field_10295, var71);
         var77.put(class_2246.field_10110, var71);
         var77.put(class_2246.field_9997, var71);
         var1.buildValidSubstitutes.value = var77;

         try {
            var1.blockReachDistance.value = FarmConfig.placeReach;
         } catch (Throwable var32) {
         }

         FinishProcess.REACH = FarmConfig.placeReach;
         var1.rightClickSpeed.value = FarmConfig.placeSpeed;
         var1.blockPlacementPenalty.value = Math.max((Double)var1.blockPlacementPenalty.value, 35.0);
         return var19;
      }

      boolean relaxPlacementPenalty() {
         Settings var1 = BaritoneAPI.getSettings();
         if ((Double)var1.blockPlacementPenalty.value <= this.blockPlacementPenalty) {
            return false;
         }

         var1.blockPlacementPenalty.value = this.blockPlacementPenalty;
         return true;
      }

      boolean relaxBlocksToAvoid() {
         Settings var1 = BaritoneAPI.getSettings();
         if (((List)var1.blocksToAvoid.value).size() <= this.blocksToAvoid.size()) {
            return false;
         }

         var1.blocksToAvoid.value = new ArrayList<>(this.blocksToAvoid);
         return true;
      }

      void restore() {
         Settings var1 = BaritoneAPI.getSettings();

         try {
            var1.buildIgnoreExisting.value = this.buildIgnoreExisting;
         } catch (Throwable var32) {
         }

         try {
            var1.buildIgnoreBlocks.value = new ArrayList<>(this.buildIgnoreBlocks);
         } catch (Throwable var31) {
         }

         try {
            var1.blocksToDisallowBreaking.value = new ArrayList<>(this.blocksToDisallowBreaking);
         } catch (Throwable var30) {
         }

         try {
            var1.buildSkipBlocks.value = new ArrayList<>(this.skipBlocks);
         } catch (Throwable var29) {
         }

         try {
            var1.buildIgnoreProperties.value = new ArrayList<>(this.ignoreProperties);
         } catch (Throwable var28) {
         }

         try {
            var1.buildIgnoreDirection.value = this.ignoreDirection;
         } catch (Throwable var27) {
         }

         try {
            var1.buildSubstitutes.value = new HashMap<>(this.substitutes);
         } catch (Throwable var26) {
         }

         try {
            var1.buildValidSubstitutes.value = new HashMap<>(this.validSubstitutes);
         } catch (Throwable var25) {
         }

         try {
            var1.blocksToAvoid.value = new ArrayList<>(this.blocksToAvoid);
         } catch (Throwable var24) {
         }

         try {
            var1.acceptableThrowawayItems.value = new ArrayList<>(this.throwawayItems);
         } catch (Throwable var23) {
         }

         try {
            var1.rightClickSpeed.value = FarmConfig.placeSpeed;
         } catch (Throwable var22) {
         }

         try {
            var1.blockPlacementPenalty.value = this.blockPlacementPenalty;
         } catch (Throwable var21) {
         }

         try {
            var1.incorrectSize.value = this.incorrectSize;
         } catch (Throwable var20) {
         }

         try {
            var1.buildSchematicRotation.value = this.schematicRotation;
         } catch (Throwable var19) {
         }

         try {
            var1.buildSchematicMirror.value = this.schematicMirror;
         } catch (Throwable var18) {
         }

         try {
            var1.assumeWalkOnWater.value = this.assumeWalkOnWater;
         } catch (Throwable var17) {
         }

         try {
            var1.allowPlace.value = this.allowPlace;
         } catch (Throwable var16) {
         }

         try {
            var1.allowPlaceInFluidsSource.value = this.allowPlaceInFluidsSource;
         } catch (Throwable var15) {
         }

         try {
            var1.allowPlaceInFluidsFlow.value = this.allowPlaceInFluidsFlow;
         } catch (Throwable var14) {
         }

         try {
            var1.allowParkour.value = this.allowParkour;
         } catch (Throwable var13) {
         }

         try {
            var1.allowParkourAscend.value = this.allowParkourAscend;
         } catch (Throwable var12) {
         }

         try {
            var1.allowParkourPlace.value = this.allowParkourPlace;
         } catch (Throwable var11) {
         }

         try {
            var1.allowDiagonalDescend.value = this.allowDiagonalDescend;
         } catch (Throwable var10) {
         }

         try {
            var1.allowDiagonalAscend.value = this.allowDiagonalAscend;
         } catch (Throwable var9) {
         }

         try {
            var1.allowDownward.value = this.allowDownward;
         } catch (Throwable var8) {
         }

         try {
            var1.walkOnWaterOnePenalty.value = this.walkOnWaterOnePenalty;
         } catch (Throwable var7) {
         }

         try {
            var1.maxFallHeightNoWater.value = this.maxFallHeightNoWater;
         } catch (Throwable var6) {
         }

         try {
            var1.blockReachDistance.value = FarmConfig.placeReach;
         } catch (Throwable var5) {
         }

         try {
            FinishProcess.REACH = FarmConfig.placeReach;
         } catch (Throwable var4) {
         }

         try {
            var1.smoothLook.value = false;
         } catch (Throwable var3) {
         }
      }

      private static <T> void addIfMissing(List<T> list, T object) {
         if (!list.contains(object)) {
            list.add(object);
         }
      }
   }

   public enum State {
      IDLE,
      INITIAL_RESTOCK,
      BUILDING,
      LAYER_FLUIDS,
      FINISHING;
   }
}
