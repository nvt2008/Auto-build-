package com.autobuildfarm.command;

import com.autobuildfarm.AutoBuildFarm;
import com.autobuildfarm.AutoRejoinHandler;
import com.autobuildfarm.DebugLog;
import com.autobuildfarm.FarmBuildController;
import com.autobuildfarm.eat.AutoEatController;
import com.autobuildfarm.litematica.LitematicaBridge;
import com.autobuildfarm.order.BucketDisposal;
import com.autobuildfarm.order.RestockController;
import com.autobuildfarm.security.IpGuard;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.class_310;

public final class BuildFarmCommand {
   private BuildFarmCommand() {
   }

   public static void register(CommandDispatcher<FabricClientCommandSource> commandDispatcher) {
      commandDispatcher.register(
         (LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)ClientCommandManager.literal(
                                                                  "buildfarm"
                                                               )
                                                               .then(
                                                                  ((LiteralArgumentBuilder)ClientCommandManager.literal("start").executes(commandContext -> {
                                                                     if (!checkLicense()) {
                                                                        return 0;
                                                                     }

                                                                     int var1 = LitematicaBridge.getClosestPlacementIndex();
                                                                     FarmBuildController.INSTANCE.start(var1);
                                                                     return 1;
                                                                  })).then(
                                                                     ClientCommandManager.argument("placement", IntegerArgumentType.integer(0))
                                                                        .executes(commandContext -> {
                                                                           if (!checkLicense()) {
                                                                              return 0;
                                                                           }

                                                                           FarmBuildController.INSTANCE
                                                                              .start(IntegerArgumentType.getInteger(commandContext, "placement"));
                                                                           return 1;
                                                                        })
                                                                  )
                                                               ))
                                                            .then(ClientCommandManager.literal("list").executes(commandContext -> {
                                                               LitematicaBridge.printPlacementList();
                                                               return 1;
                                                            })))
                                                         .then(ClientCommandManager.literal("resume").executes(commandContext -> {
                                                            if (!checkLicense()) {
                                                               return 0;
                                                            }

                                                            FarmBuildController.INSTANCE.resumeFinish();
                                                            return 1;
                                                         })))
                                                      .then(ClientCommandManager.literal("rejoin").executes(commandContext -> {
                                                         AutoRejoinHandler.getInstance().trigger("L\u1ec7nh ng\u01b0\u1eddi d\u00f9ng /buildfarm rejoin");
                                                         return 1;
                                                      })))
                                                   .then(ClientCommandManager.literal("cancel").executes(commandContext -> {
                                                      FarmBuildController.INSTANCE.cancel();
                                                      return 1;
                                                   })))
                                                .then(ClientCommandManager.literal("log").executes(commandContext -> {
                                                   AutoBuildFarm.chat("Debug log: " + DebugLog.location());
                                                   return 1;
                                                })))
                                             .then(ClientCommandManager.literal("status").executes(commandContext -> {
                                                FarmBuildController.INSTANCE.printStatus();
                                                return 1;
                                             })))
                                          .then(
                                             ((LiteralArgumentBuilder)ClientCommandManager.literal("speed")
                                                   .then(
                                                      ClientCommandManager.argument("ticks", IntegerArgumentType.integer(0, 40)).executes(commandContext -> {
                                                         int var1 = IntegerArgumentType.getInteger(commandContext, "ticks");
                                                         FarmBuildController.setPlaceSpeed(var1);
                                                         return 1;
                                                      })
                                                   ))
                                                .executes(
                                                   commandContext -> {
                                                      AutoBuildFarm.chat(
                                                         "Current placement speed: "
                                                            + FarmBuildController.getPlaceSpeed()
                                                            + " ticks per block (use /buildfarm speed <ticks>, e.g. 1=very fast, 4=normal, 5-6=safe/laggy servers)."
                                                      );
                                                      return 1;
                                                   }
                                                )
                                          ))
                                       .then(
                                          ((LiteralArgumentBuilder)ClientCommandManager.literal("delay")
                                                .then(ClientCommandManager.argument("ticks", IntegerArgumentType.integer(0, 40)).executes(commandContext -> {
                                                   int var1 = IntegerArgumentType.getInteger(commandContext, "ticks");
                                                   FarmBuildController.setPlaceSpeed(var1);
                                                   return 1;
                                                })))
                                             .executes(
                                                commandContext -> {
                                                   AutoBuildFarm.chat(
                                                      "Current placement delay: "
                                                         + FarmBuildController.getPlaceSpeed()
                                                         + " ticks per block (use /buildfarm delay <ticks>, e.g. 1=very fast, 4=normal, 5-6=safe/laggy servers)."
                                                   );
                                                   return 1;
                                                }
                                             )
                                       ))
                                    .then(
                                       ((LiteralArgumentBuilder)ClientCommandManager.literal("reach")
                                             .then(
                                                ClientCommandManager.argument("distance", FloatArgumentType.floatArg(1.5F, 5.0F)).executes(commandContext -> {
                                                   float var1 = FloatArgumentType.getFloat(commandContext, "distance");
                                                   FarmBuildController.setPlaceReach(var1);
                                                   return 1;
                                                })
                                             ))
                                          .executes(
                                             commandContext -> {
                                                AutoBuildFarm.chat(
                                                   "Kho\u1ea3ng c\u00e1ch \u0111\u1eb7t block hi\u1ec7n t\u1ea1i (reach): "
                                                      + FarmBuildController.getPlaceReach()
                                                      + " blocks (d\u00f9ng /buildfarm reach <s\u1ed1>, m\u1eb7c \u0111\u1ecbnh 3.3)."
                                                );
                                                return 1;
                                             }
                                          )
                                    ))
                                 .then(
                                    ((LiteralArgumentBuilder)ClientCommandManager.literal("leafspeed")
                                          .then(ClientCommandManager.argument("ticks", IntegerArgumentType.integer(1, 40)).executes(commandContext -> {
                                             int var1 = IntegerArgumentType.getInteger(commandContext, "ticks");
                                             FarmBuildController.setLeafPlaceSpeed(var1);
                                             return 1;
                                          })))
                                       .executes(
                                          commandContext -> {
                                             AutoBuildFarm.chat(
                                                "T\u1ed1c \u0111\u1ed9 \u0111\u1eb7t l\u00e1 hi\u1ec7n t\u1ea1i (leaf speed): "
                                                   + FarmBuildController.getLeafPlaceSpeed()
                                                   + " ticks ("
                                                   + FarmBuildController.getLeafPlaceSpeed() * 50
                                                   + "ms/block) (d\u00f9ng /buildfarm leafspeed <ticks>, m\u1eb7c \u0111\u1ecbnh 8)."
                                             );
                                             return 1;
                                          }
                                       )
                                 ))
                              .then(
                                 ((LiteralArgumentBuilder)ClientCommandManager.literal("leavespeed")
                                       .then(ClientCommandManager.argument("ticks", IntegerArgumentType.integer(1, 40)).executes(commandContext -> {
                                          int var1 = IntegerArgumentType.getInteger(commandContext, "ticks");
                                          FarmBuildController.setLeafPlaceSpeed(var1);
                                          return 1;
                                       })))
                                    .executes(
                                       commandContext -> {
                                          AutoBuildFarm.chat(
                                             "T\u1ed1c \u0111\u1ed9 \u0111\u1eb7t l\u00e1 hi\u1ec7n t\u1ea1i (leaf speed): "
                                                + FarmBuildController.getLeafPlaceSpeed()
                                                + " ticks ("
                                                + FarmBuildController.getLeafPlaceSpeed() * 50
                                                + "ms/block) (d\u00f9ng /buildfarm leavespeed <ticks>, m\u1eb7c \u0111\u1ecbnh 8)."
                                          );
                                          return 1;
                                       }
                                    )
                              ))
                           .then(ClientCommandManager.literal("scan").executes(commandContext -> {
                              class_310 var1 = class_310.method_1551();
                              if (var1 != null && var1.field_1724 != null) {
                                 RestockController.QuotaEntry var2 = RestockController.getInstance().findExhaustedItem(var1.field_1724);
                                 if (var2 != null) {
                                    RestockController.getInstance().requestRestock(var2.item());
                                 } else {
                                    AutoBuildFarm.chat("\u2714 T\u00fai \u0111\u1ed3 \u0111\u00e3 \u0111\u1ea7y \u0111\u1ee7 nguy\u00ean li\u1ec7u.");
                                 }
                              }

                              return 1;
                           })))
                        .then(ClientCommandManager.literal("restock").executes(commandContext -> {
                           class_310 var1 = class_310.method_1551();
                           if (var1 != null && var1.field_1724 != null) {
                              RestockController.QuotaEntry var2 = RestockController.getInstance().findExhaustedItem(var1.field_1724);
                              if (var2 != null) {
                                 RestockController.getInstance().requestRestock(var2.item());
                              } else {
                                 AutoBuildFarm.chat("\u2714 T\u00fai \u0111\u1ed3 \u0111\u00e3 \u0111\u1ea7y \u0111\u1ee7 nguy\u00ean li\u1ec7u.");
                              }
                           }

                           return 1;
                        })))
                     .then(ClientCommandManager.literal("dumpbuckets").executes(commandContext -> {
                        class_310 var1 = class_310.method_1551();
                        BucketDisposal.getInstance().start(var1);
                        return 1;
                     })))
                  .then(ClientCommandManager.literal("sell").executes(commandContext -> {
                     class_310 var1 = class_310.method_1551();
                     BucketDisposal.getInstance().start(var1);
                     return 1;
                  })))
               .then(
                  ((LiteralArgumentBuilder)((LiteralArgumentBuilder)ClientCommandManager.literal("autoeat")
                           .then(ClientCommandManager.literal("toggle").executes(commandContext -> {
                              boolean var1 = AutoEatController.getInstance().isEnabled();
                              AutoEatController.getInstance().setEnabled(!var1);
                              AutoBuildFarm.chat("Auto Eat: " + (!var1 ? "\u00a7aB\u1eacT" : "\u00a7cT\u1eaeT"));
                              return 1;
                           })))
                        .then(ClientCommandManager.argument("threshold", IntegerArgumentType.integer(1, 19)).executes(commandContext -> {
                           int var1 = IntegerArgumentType.getInteger(commandContext, "threshold");
                           AutoEatController.getInstance().setHungerThreshold(var1);
                           AutoBuildFarm.chat(
                              "\u0110\u00e3 \u0111\u1eb7t ng\u01b0\u1ee1ng Auto Eat: " + var1 + "/20 (" + var1 / 2 + " c\u1ee5c \u0111\u00f3i)."
                           );
                           return 1;
                        })))
                     .executes(
                        commandContext -> {
                           AutoEatController var1 = AutoEatController.getInstance();
                           AutoBuildFarm.chat(
                              "Auto Eat: "
                                 + (var1.isEnabled() ? "\u00a7aB\u1eacT" : "\u00a7cT\u1eaeT")
                                 + " (K\u00edch ho\u1ea1t khi thanh \u0111\u00f3i <= "
                                 + var1.getHungerThreshold()
                                 + "/20, t\u1ee9c c\u00f2n "
                                 + var1.getHungerThreshold() / 2
                                 + " c\u1ee5c \u0111\u00f3i / t\u1ee5t "
                                 + (10 - var1.getHungerThreshold() / 2)
                                 + " c\u1ee5c)."
                           );
                           AutoBuildFarm.chat("D\u00f9ng: /buildfarm autoeat [toggle | 1-19 (m\u1eb7c \u0111\u1ecbnh 16)]");
                           return 1;
                        }
                     )
               ))
            .executes(commandContext -> {
               FarmBuildController.INSTANCE.printStatus();
               return 1;
            })
      );
   }

   private static boolean checkLicense() {
      return IpGuard.isAllowed();
   }
}
