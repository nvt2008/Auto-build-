package com.autobuildfarm.order;

import java.util.Locale;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2960;

@Environment(EnvType.CLIENT)
public final class ItemStackUtil {
   private ItemStackUtil() {
   }

   public static boolean isExpBottle(String string) {
      if (string == null) {
         return false;
      }

      String var1 = string.trim().toLowerCase(Locale.ROOT).replace('_', ' ').replace("'", "").replace("\u2019", "");
      if ((var1 = var1.replaceAll("\\s+", " ")).startsWith("minecraft:")) {
         var1 = var1.substring("minecraft:".length());
      }

      return var1.equals("experience bottle") || var1.equals("exp bottle") || var1.equals("bottle o enchanting") || var1.equals("bottle of enchanting");
   }

   public static class_2960 toIdentifier(String string) {
      if (string == null || string.isBlank()) {
         return null;
      }

      if (isExpBottle(string)) {
         return class_2960.method_60655("minecraft", "experience_bottle");
      }

      String var1 = string.trim().toLowerCase(Locale.ROOT).replace(' ', '_');
      if (var1.startsWith("minecraft:")) {
         var1 = var1.substring("minecraft:".length());
      }

      if (var1.startsWith("block_of_")) {
         String var2 = var1.substring("block_of_".length());
         if (var2.equals("lapis_lazuli")) {
            var2 = "lapis";
         }

         var1 = var2 + "_block";
      }

      return class_2960.method_12829("minecraft:" + var1);
   }

   public static String normalizeName(String string) {
      if (string == null) {
         return "";
      }

      String var1 = string.replaceAll("\u00a7[0-9a-fk-orA-FK-OR]", "").toLowerCase(Locale.ROOT);
      StringBuilder var2 = new StringBuilder(var1.length());

      for (int var3 = 0; var3 < var1.length(); var3++) {
         char var4 = var1.charAt(var3);
         if (var4 < 128 && Character.isLetterOrDigit(var4)) {
            var2.append(var4);
         } else {
            var2.append(' ');
         }
      }

      return var2.toString().replaceAll("\\s+", " ").trim();
   }

   public static String singularize(String string) {
      if (string == null) {
         return "";
      } else if (string.endsWith("ves")) {
         return string.substring(0, string.length() - 3) + "f";
      } else if (string.endsWith("es") && string.length() > 3) {
         return string.substring(0, string.length() - 2);
      } else {
         return string.endsWith("s") && !string.endsWith("ss") && string.length() > 2 ? string.substring(0, string.length() - 1) : string;
      }
   }

   public static boolean itemsMatch(String string, String string2) {
      if (string == null || string2 == null) {
         return false;
      }

      if (isExpBottle(string) && isExpBottle(string2)) {
         return true;
      }

      String var2 = normalizeName(string);
      String var3 = normalizeName(string2);
      if (var2.isEmpty() || var3.isEmpty()) {
         return false;
      }

      if (var2.equals(var3)) {
         return true;
      }

      if (singularize(var2).equals(singularize(var3))) {
         return true;
      }

      boolean var4 = var2.contains("enchanted");
      boolean var5 = var3.contains("enchanted");
      if (var4 != var5) {
         return false;
      }

      boolean var6 = var2.contains("raw");
      boolean var7 = var3.contains("raw");
      if (var6 != var7) {
         return false;
      }

      class_2960 var8 = toIdentifier(string);
      class_2960 var9 = toIdentifier(string2);
      return var8 != null && var8.equals(var9);
   }

   public static double parsePriceOrAmount(String string) {
      if (string == null) {
         return 0.0;
      }

      String var1 = string.replaceAll("\u00a7[0-9a-fk-orA-FK-OR]", "").replace("$", "").replace(",", "").replace(" ", "").trim().toLowerCase(Locale.ROOT);
      if (var1.isEmpty()) {
         return 0.0;
      }

      try {
         if (var1.endsWith("b")) {
            return Double.parseDouble(var1.substring(0, var1.length() - 1)) * 1.0E9;
         } else if (var1.endsWith("m")) {
            return Double.parseDouble(var1.substring(0, var1.length() - 1)) * 1000000.0;
         } else {
            return var1.endsWith("k") ? Double.parseDouble(var1.substring(0, var1.length() - 1)) * 1000.0 : Double.parseDouble(var1);
         }
      } catch (NumberFormatException var3) {
         return 0.0;
      }
   }
}
