package com.autobuildfarm.order;

import baritone.api.BaritoneAPI;
import baritone.api.IBaritone;
import com.autobuildfarm.AutoBuildFarm;
import com.autobuildfarm.place.InventoryHelper;
import java.util.ArrayList;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_465;
import net.minecraft.class_490;
import net.minecraft.class_746;

public final class BucketDisposal {
   private static final BucketDisposal INSTANCE = new BucketDisposal();
   public static final int BUCKET_THRESHOLD = 8;
   private BucketDisposal.State state = BucketDisposal.State.IDLE;
   private long stateEnterTime = 0L;
   private int attempts = 0;
   private Runnable onComplete = null;

   public static BucketDisposal getInstance() {
      return INSTANCE;
   }

   private BucketDisposal() {
   }

   public boolean isBusy() {
      return this.state != BucketDisposal.State.IDLE;
   }

   public boolean needsDisposal(class_746 arg) {
      return arg == null ? false : InventoryHelper.count(arg, class_1802.field_8550) >= 8;
   }

   public void start(class_310 arg) {
      this.start(arg, null);
   }

   public void start(class_310 arg, Runnable runnable) {
      if (arg != null && arg.field_1724 != null) {
         this.onComplete = runnable;
         this.attempts = 0;
         haltMovement(arg);
         this.transition(BucketDisposal.State.WAIT_GROUND);
      }
   }

   public static void haltMovement(class_310 arg) {
      try {
         IBaritone var1 = BaritoneAPI.getProvider().getPrimaryBaritone();
         if (var1 != null) {
            var1.getInputOverrideHandler().clearAllKeys();
            var1.getPathingBehavior().cancelEverything();
         }
      } catch (Throwable var2) {
      }

      if (arg != null && arg.field_1724 != null) {
         arg.field_1724.method_18800(0.0, arg.field_1724.method_18798().field_1351, 0.0);
      }
   }

   public void reset() {
      this.state = BucketDisposal.State.IDLE;
      this.onComplete = null;
      this.attempts = 0;
   }

   private void transition(BucketDisposal.State state) {
      this.state = state;
      this.stateEnterTime = System.currentTimeMillis();
   }

   public void tick(class_310 arg) {
      GuiAutomator.getInstance().tick();
      if (this.state != BucketDisposal.State.IDLE && arg != null && arg.field_1724 != null) {
         haltMovement(arg);
         long var2 = System.currentTimeMillis() - this.stateEnterTime;
         switch (this.state) {
            case WAIT_GROUND:
               haltMovement(arg);
               if (arg.field_1724.method_24828() || var2 >= 800L) {
                  this.transition(BucketDisposal.State.SEND_COMMAND);
               }
               break;
            case SEND_COMMAND:
               AutoBuildFarm.chat("\u0110ang m\u1edf /sell \u0111\u1ec3 b\u00e1n x\u00f4 r\u1ed7ng gi\u1ea3i ph\u00f3ng t\u00fai \u0111\u1ed3\u2026");
               GuiAutomator.getInstance().queueCommand("sell", 400L);
               this.transition(BucketDisposal.State.WAIT_SELL_GUI);
               break;
            case WAIT_SELL_GUI:
               if (arg.field_1755 instanceof class_465 var17 && var17.method_17577() != null && var17.method_17577().field_7761.size() > 36) {
                  this.transition(BucketDisposal.State.SHIFT_CLICK_BUCKETS);
                  return;
               }

               if (var2 > 4000L) {
                  this.attempts++;
                  if (this.attempts < 3) {
                     AutoBuildFarm.chat(
                        "\u00a7eKh\u00f4ng m\u1edf \u0111\u01b0\u1ee3c menu /sell (l\u1ea7n "
                           + this.attempts
                           + "/3) -> B\u1ea5m E m\u1edf t\u00fai \u0111\u1ed3 r\u1ed3i t\u1eaft \u0111\u1ec3 reset menu server\u2026"
                     );
                     this.transition(BucketDisposal.State.RESET_INVENTORY_OPEN);
                  } else {
                     this.attempts = 0;
                     AutoBuildFarm.chat("Kh\u00f4ng m\u1edf \u0111\u01b0\u1ee3c menu /sell sau 3 l\u1ea7n th\u1eed, hu\u1ef7 b\u00e1n x\u00f4.");
                     this.finish();
                  }
               }
               break;
            case SHIFT_CLICK_BUCKETS:
               if (!(arg.field_1755 instanceof class_465 var5)) {
                  this.transition(BucketDisposal.State.WAIT_FINISH);
                  return;
               }

               class_1703 var6 = var5.method_17577();
               int var7 = var6.field_7761.size();
               int var8 = var7 - 36;
               if (var8 <= 0) {
                  this.transition(BucketDisposal.State.WAIT_FINISH);
                  return;
               }

               ArrayList var9 = new ArrayList();

               for (int var10 = var8; var10 < var7; var10++) {
                  class_1799 var11 = ((class_1735)var6.field_7761.get(var10)).method_7677();
                  if (!var11.method_7960() && var11.method_31574(class_1802.field_8550)) {
                     var9.add(var10);
                  }
               }

               if (var9.isEmpty()) {
                  AutoBuildFarm.chat("Kh\u00f4ng c\u00f2n x\u00f4 r\u1ed7ng n\u00e0o trong t\u00fai \u0111\u1ed3.");
                  GuiAutomator.getInstance().queueAction(() -> {
                     class_310 var0 = class_310.method_1551();
                     if (var0.field_1724 != null) {
                        var0.field_1724.method_7346();
                     }
                  }, 100L);
                  this.transition(BucketDisposal.State.WAIT_FINISH);
                  return;
               }

               AutoBuildFarm.chat("\u2714 \u0110ang shift-click t\u1eebng x\u00f4 r\u1ed7ng (" + var9.size() + " x\u00f4) v\u00e0o /sell\u2026");
               long var18 = 100L;

               for (int var12 = 0; var12 < var9.size(); var12++) {
                  int var13 = (Integer)var9.get(var12);
                  long var14 = var12 == var9.size() - 1 ? 250L : var18;
                  GuiAutomator.getInstance().shiftClickIfBucket(var13, var14);
               }

               GuiAutomator.getInstance().queueAction(() -> {
                  class_310 var0 = class_310.method_1551();
                  if (var0.field_1724 != null) {
                     var0.field_1724.method_7346();
                  }
               }, 300L);
               this.transition(BucketDisposal.State.WAIT_FINISH);
               break;
            case RESET_INVENTORY_OPEN:
               if (arg.field_1724 != null) {
                  if (arg.field_1755 != null) {
                     arg.field_1724.method_7346();
                     arg.method_1507(null);
                  }

                  arg.method_1507(new class_490(arg.field_1724));
               }

               this.transition(BucketDisposal.State.RESET_INVENTORY_CLOSE);
               break;
            case RESET_INVENTORY_CLOSE:
               if (var2 >= 300L) {
                  if (arg.field_1724 != null) {
                     arg.field_1724.method_7346();
                  }

                  arg.method_1507(null);
                  this.transition(BucketDisposal.State.SEND_COMMAND);
               }
               break;
            case WAIT_FINISH:
               if (GuiAutomator.getInstance().isIdle()) {
                  if (arg.field_1755 == null) {
                     AutoBuildFarm.chat("\u2714 \u0110\u00e3 b\u00e1n x\u00f4 r\u1ed7ng th\u00e0nh c\u00f4ng qua /sell!");
                     this.finish();
                  } else if (var2 > 3000L) {
                     if (arg.field_1724 != null) {
                        arg.field_1724.method_7346();
                     }

                     this.finish();
                  }
               }
         }
      }
   }

   private void finish() {
      this.state = BucketDisposal.State.IDLE;
      if (this.onComplete != null) {
         Runnable var1 = this.onComplete;
         this.onComplete = null;
         var1.run();
      }
   }

   public enum State {
      IDLE,
      WAIT_GROUND,
      SEND_COMMAND,
      WAIT_SELL_GUI,
      SHIFT_CLICK_BUCKETS,
      RESET_INVENTORY_OPEN,
      RESET_INVENTORY_CLOSE,
      WAIT_FINISH;
   }
}
