package com.autobuildfarm.order;

import baritone.api.BaritoneAPI;
import baritone.api.IBaritone;
import com.autobuildfarm.AutoBuildFarm;
import com.autobuildfarm.DebugLog;
import com.autobuildfarm.FarmBuildController;
import com.autobuildfarm.place.InventoryHelper;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_476;
import net.minecraft.class_490;
import net.minecraft.class_746;
import net.minecraft.class_7923;
import net.minecraft.class_9290;
import net.minecraft.class_9334;

@Environment(EnvType.CLIENT)
public final class RestockController {
   private static final RestockController INSTANCE = new RestockController();
   public static final List<RestockController.QuotaEntry> TARGET_ITEMS = List.of(
      new RestockController.QuotaEntry(class_1802.field_8705, 6, "X\u00f4 n\u01b0\u1edbc"),
      new RestockController.QuotaEntry(class_1802.field_8187, 12, "X\u00f4 lava"),
      new RestockController.QuotaEntry(class_1802.field_8281, 192, "H\u1eafc di\u1ec7n th\u1ea1ch (Obsidian)"),
      new RestockController.QuotaEntry(class_1802.field_17503, 192, "L\u00e1 s\u1ed3i (Oak Leaves)"),
      new RestockController.QuotaEntry(class_1802.field_20412, 192, "\u0110\u00e1 cu\u1ed9i (Cobblestone)"),
      new RestockController.QuotaEntry(class_1802.field_8410, 64, "K\u00ednh (Stained Glass)"),
      new RestockController.QuotaEntry(class_1802.field_28860, 192, "Deepslate Tiles")
   );
   private static final Pattern ORDER_PROGRESS = Pattern.compile("(?i)([\\d,\\.]+[KkMmBb]?)\\s*/\\s*([\\d,\\.]+[KkMmBb]?)");
   private RestockController.BotState state = RestockController.BotState.IDLE;
   private long stateEnteredAt = 0L;
   private int collectMenuRetries = 0;
   private int takeItemRetries = 0;
   private final Deque<class_1792> restockQueue = new ArrayDeque<>();
   private final Map<class_1792, Long> restockFailedUntil = new HashMap<>();
   private Runnable onRestockComplete = null;
   private class_1792 currentTargetItem = null;

   public static RestockController getInstance() {
      return INSTANCE;
   }

   private RestockController() {
   }

   public boolean isBusy() {
      return this.state != RestockController.BotState.IDLE;
   }

   public void clearFailureCooldowns() {
      this.restockFailedUntil.clear();
   }

   public boolean canRequestRestock(class_1792 arg) {
      if (arg == null) {
         return false;
      }

      Long var2 = this.restockFailedUntil.get(arg);
      return var2 == null || System.currentTimeMillis() >= var2;
   }

   public class_1792 getCurrentTargetItem() {
      return this.currentTargetItem;
   }

   private void transition(RestockController.BotState botState) {
      this.state = botState;
      this.stateEnteredAt = System.currentTimeMillis();
      DebugLog.line("RESTOCK_STATE -> " + botState);
   }

   public RestockController.QuotaEntry findExhaustedItem(class_746 arg) {
      if (arg == null) {
         return null;
      }

      if (InventoryHelper.count(arg, class_1802.field_20412) < 32 && this.canRequestRestock(class_1802.field_20412)) {
         return new RestockController.QuotaEntry(class_1802.field_20412, 192, "\u0110\u00e1 cu\u1ed9i (Cobblestone)");
      }

      for (RestockController.QuotaEntry var3 : TARGET_ITEMS) {
         if (var3.item() != class_1802.field_20412
            && var3.item() != class_1802.field_8187
            && InventoryHelper.count(arg, var3.item()) == 0
            && FarmBuildController.INSTANCE.countRemainingNeeded(var3.item()) != 0
            && this.canRequestRestock(var3.item())) {
            return var3;
         }
      }

      for (class_1792 var5 : FarmBuildController.INSTANCE.getRequiredItemsInSchematic()) {
         if (var5 != class_1802.field_8162
            && var5 != class_1802.field_20412
            && var5 != class_1802.field_8187
            && InventoryHelper.count(arg, var5) == 0
            && FarmBuildController.INSTANCE.countRemainingNeeded(var5) != 0
            && this.canRequestRestock(var5)) {
            return new RestockController.QuotaEntry(var5, 64, getItemDisplayName(var5));
         }
      }

      return null;
   }

   public void startRestockSequence(List<class_1792> list, Runnable runnable) {
      if (list != null && !list.isEmpty()) {
         if (this.state == RestockController.BotState.IDLE) {
            this.restockQueue.clear();

            for (class_1792 var4 : list) {
               if (!this.restockQueue.contains(var4) && this.canRequestRestock(var4)) {
                  this.restockQueue.add(var4);
               }
            }

            if (this.restockQueue.isEmpty()) {
               if (runnable != null) {
                  runnable.run();
               }
            } else {
               this.onRestockComplete = runnable;
               this.processNextInQueue();
            }
         }
      } else {
         if (runnable != null) {
            runnable.run();
         }
      }
   }

   public boolean requestRestock(class_1792 arg) {
      return this.requestRestock(arg, null);
   }

   public boolean requestRestock(class_1792 arg, Runnable runnable) {
      if (arg == null || this.state != RestockController.BotState.IDLE) {
         return false;
      }

      if (!this.canRequestRestock(arg)) {
         return false;
      }

      this.startRestockSequence(List.of(arg), runnable);
      return true;
   }

   private void processNextInQueue() {
      class_310 var1 = class_310.method_1551();

      while (!this.restockQueue.isEmpty()) {
         class_1792 var2 = this.restockQueue.peek();
         int var3 = var1 != null && var1.field_1724 != null ? InventoryHelper.count(var1.field_1724, var2) : 0;
         if (!isQuotaSatisfied(var2, var3)) {
            int var4 = FarmBuildController.INSTANCE.countRemainingNeeded(var2);
            if (var2 == class_1802.field_20412 || var2 == class_1802.field_8705 || var4 != 0) {
               this.currentTargetItem = var2;
               this.collectMenuRetries = 0;
               this.takeItemRetries = 0;
               if (var1 != null) {
                  haltMovement(var1);
               }

               this.transition(RestockController.BotState.WAIT_GROUND);
               return;
            }

            this.restockQueue.poll();
         } else {
            this.restockQueue.poll();
         }
      }

      this.finishRestock();
   }

   public static void haltMovement(class_310 arg) {
      try {
         IBaritone var1 = BaritoneAPI.getProvider().getPrimaryBaritone();
         if (var1 != null) {
            var1.getInputOverrideHandler().clearAllKeys();
            var1.getPathingBehavior().cancelEverything();
         }
      } catch (Throwable var2) {
      }

      if (arg != null && arg.field_1724 != null) {
         arg.field_1724.method_18800(0.0, arg.field_1724.method_18798().field_1351, 0.0);
      }
   }

   private void finishRestock() {
      this.state = RestockController.BotState.IDLE;
      this.currentTargetItem = null;
      IBaritone var1 = BaritoneAPI.getProvider().getPrimaryBaritone();
      if (var1 != null && var1.getBuilderProcess().isActive() && var1.getBuilderProcess().isPaused()) {
         AutoBuildFarm.chat(
            "\u2714 \u0110\u00e3 b\u1ed5 sung nguy\u00ean li\u1ec7u! Ti\u1ebfp t\u1ee5c qu\u00e1 tr\u00ecnh x\u00e2y d\u1ef1ng v\u1edbi Baritone\u2026"
         );
         var1.getBuilderProcess().resume();
      }

      if (this.onRestockComplete != null) {
         Runnable var2 = this.onRestockComplete;
         this.onRestockComplete = null;
         var2.run();
      }
   }

   public static boolean isOrderMainMenuTitle(String string) {
      if (string == null || string.isBlank()) {
         return false;
      } else {
         return !isYourOrdersTitle(string) && !isEditOrderTitle(string) && !isCollectItemsTitle(string)
            ? string.startsWith("orders")
               || string.startsWith("\u0111\u01a1n h\u00e0ng")
               || string.startsWith("don hang")
               || string.contains("orders (page")
               || string.contains("\u0111\u01a1n h\u00e0ng (trang")
               || string.contains("don hang (trang")
               || string.contains("order")
               || string.contains("\u0111\u01a1n h\u00e0ng")
               || string.contains("don hang")
            : false;
      }
   }

   public static boolean isYourOrdersTitle(String string) {
      return string != null && !string.isBlank()
         ? string.contains("your orders")
            || string.contains("orders -> your orders")
            || string.contains("\u0111\u01a1n h\u00e0ng c\u1ee7a b\u1ea1n")
            || string.contains("don hang cua ban")
            || string.contains("\u0111\u01a1n c\u1ee7a b\u1ea1n")
            || string.contains("don cua ban")
            || string.contains("c\u1ee7a b\u1ea1n")
            || string.contains("cua ban")
         : false;
   }

   public static boolean isEditOrderTitle(String string) {
      if (string == null || string.isBlank()) {
         return false;
      } else {
         return isYourOrdersTitle(string)
            ? false
            : string.contains("edit order")
               || string.contains("ch\u1ec9nh s\u1eeda")
               || string.contains("chinh sua")
               || string.contains("chi ti\u1ebft")
               || string.contains("chi tiet");
      }
   }

   public static boolean isCollectItemsTitle(String string) {
      return string != null && !string.isBlank()
         ? string.contains("collect item") || string.contains("nh\u1eadn v\u1eadt ph\u1ea9m") || string.contains("nhan vat pham") || string.contains("kho")
         : false;
   }

   public void onScreenOpen(String string, class_437 arg) {
      if (this.state != RestockController.BotState.IDLE) {
         String var3 = string.toLowerCase(Locale.ROOT);
         DebugLog.line("SCREEN '" + string + "' | class=" + (arg != null ? arg.getClass().getSimpleName() : "null") + " | state=" + this.state);
         if (isOrderMainMenuTitle(var3) && this.state == RestockController.BotState.WAIT_COLLECT_ORDER_MENU) {
            this.transition(RestockController.BotState.CLICK_COLLECT_YOUR_ORDERS);
         } else if (!isYourOrdersTitle(var3)
            || this.state != RestockController.BotState.WAIT_COLLECT_YOUR_ORDERS
               && this.state != RestockController.BotState.WAIT_COLLECT_ORDER_MENU
               && this.state != RestockController.BotState.CLICK_COLLECT_YOUR_ORDERS) {
            if (isEditOrderTitle(var3) && this.state == RestockController.BotState.WAIT_EDIT_ORDER) {
               this.transition(RestockController.BotState.CLICK_COLLECT);
            } else if (isCollectItemsTitle(var3) && this.state == RestockController.BotState.WAIT_AFTER_COLLECT) {
               this.transition(RestockController.BotState.TAKE_COLLECTED_ITEMS);
            }
         } else {
            this.transition(RestockController.BotState.CLICK_COMPLETED_ORDER);
         }
      }
   }

   public void tick(class_310 arg) {
      if (this.state != RestockController.BotState.IDLE) {
         GuiAutomator.getInstance().tick();
         if (arg != null && arg.field_1724 != null) {
            haltMovement(arg);
            long var2 = System.currentTimeMillis() - this.stateEnteredAt;
            switch (this.state) {
               case WAIT_GROUND:
                  haltMovement(arg);
                  if (arg.field_1724.method_24828() || var2 >= 800L) {
                     this.transition(RestockController.BotState.OPEN_ORDERS_TO_COLLECT);
                  }
                  break;
               case OPEN_ORDERS_TO_COLLECT:
                  if (arg.method_1542()) {
                     AutoBuildFarm.chat("Ch\u01a1i \u0111\u01a1n (Singleplayer) kh\u00f4ng c\u00f3 l\u1ec7nh /order -> B\u1ecf qua ki\u1ec3m tra.");
                     this.finishRestock();
                     return;
                  }

                  if (arg.field_1755 != null) {
                     this.closeScreen(arg);
                  }

                  AutoBuildFarm.chat(
                     "\u0110ang m\u1edf /order \u0111\u1ec3 l\u1ea5y "
                        + getItemDisplayName(this.currentTargetItem)
                        + (this.collectMenuRetries > 0 ? " (th\u1eed l\u1ea1i l\u1ea7n " + this.collectMenuRetries + "/3)" : "")
                        + "\u2026"
                  );
                  GuiAutomator.getInstance().queueCommand("order", 400L);
                  this.transition(RestockController.BotState.WAIT_COLLECT_ORDER_MENU);
                  break;
               case WAIT_COLLECT_ORDER_MENU:
                  if (arg.field_1755 instanceof class_476 var29) {
                     String var40 = var29.method_25440().getString().toLowerCase(Locale.ROOT);
                     if (isYourOrdersTitle(var40)) {
                        this.collectMenuRetries = 0;
                        this.transition(RestockController.BotState.CLICK_COMPLETED_ORDER);
                        break;
                     }

                     if (isOrderMainMenuTitle(var40) && var2 >= 250L) {
                        this.transition(RestockController.BotState.CLICK_COLLECT_YOUR_ORDERS);
                        break;
                     }
                  }

                  if (var2 > 4000L) {
                     if (this.collectMenuRetries < 3) {
                        this.collectMenuRetries++;
                        AutoBuildFarm.chat(
                           "\u00a7eKh\u00f4ng th\u1ea5y menu /order sau 4s (l\u1ea7n "
                              + this.collectMenuRetries
                              + "/3) -> B\u1ea5m E m\u1edf t\u00fai \u0111\u1ed3 r\u1ed3i t\u1eaft \u0111\u1ec3 reset menu server\u2026"
                        );
                        DebugLog.line("Kh\u00f4ng th\u1ea5y menu /order \u0111\u1ec3 collect sau 4s -> th\u1eed l\u1ea1i l\u1ea7n " + this.collectMenuRetries);
                        this.transition(RestockController.BotState.RESET_INVENTORY_OPEN);
                     } else {
                        this.collectMenuRetries = 0;
                        this.abort("Kh\u00f4ng m\u1edf \u0111\u01b0\u1ee3c menu /order sau 3 l\u1ea7n th\u1eed.");
                     }
                  }
                  break;
               case CLICK_COLLECT_YOUR_ORDERS:
                  if (var2 >= 300L) {
                     int var28 = this.findYourOrdersSlot(arg);
                     if (var28 < 0) {
                        if (var2 > 2000L) {
                           DebugLog.line("COLLECT| kh\u00f4ng th\u1ea5y n\u00fat 'Your Orders' trong /order sau 2s -> \u0111\u00f3ng m\u00e0n.");
                           if (this.collectMenuRetries < 3) {
                              this.collectMenuRetries++;
                              AutoBuildFarm.chat(
                                 "\u00a7eKh\u00f4ng th\u1ea5y n\u00fat 'Your Orders' (l\u1ea7n "
                                    + this.collectMenuRetries
                                    + "/3) -> B\u1ea5m E m\u1edf t\u00fai \u0111\u1ed3 r\u1ed3i t\u1eaft \u0111\u1ec3 reset menu server\u2026"
                              );
                              this.transition(RestockController.BotState.RESET_INVENTORY_OPEN);
                           } else {
                              this.collectMenuRetries = 0;
                              this.closeScreen(arg);
                              this.abort("Kh\u00f4ng t\u00ecm th\u1ea5y n\u00fat 'Your Orders' trong menu /order.");
                           }
                        }
                     } else {
                        AutoBuildFarm.chat("B\u1ea5m 'Your Orders' (slot " + var28 + ") - ch\u1ec9 b\u1ea5m 1 l\u1ea7n, ch\u1edd GUI m\u1edf\u2026");
                        GuiAutomator.getInstance().clickSlot(var28, 250L);
                        this.transition(RestockController.BotState.WAIT_COLLECT_YOUR_ORDERS);
                     }
                  }
                  break;
               case WAIT_COLLECT_YOUR_ORDERS:
                  if (arg.field_1755 instanceof class_476 var27) {
                     String var38 = var27.method_25440().getString().toLowerCase(Locale.ROOT);
                     if (isYourOrdersTitle(var38)) {
                        this.collectMenuRetries = 0;
                        this.transition(RestockController.BotState.CLICK_COMPLETED_ORDER);
                        break;
                     }
                  }

                  if (var2 > 3000L) {
                     if (this.collectMenuRetries < 3) {
                        this.collectMenuRetries++;
                        AutoBuildFarm.chat(
                           "\u00a7eCh\u1edd 3s ch\u01b0a m\u1edf 'Your Orders' (l\u1ea7n "
                              + this.collectMenuRetries
                              + "/3) -> B\u1ea5m E m\u1edf t\u00fai \u0111\u1ed3 r\u1ed3i t\u1eaft \u0111\u1ec3 reset menu server\u2026"
                        );
                        DebugLog.line("WAIT_COLLECT_YOUR_ORDERS timeout 3s -> reset inventory and retry /order");
                        this.transition(RestockController.BotState.RESET_INVENTORY_OPEN);
                     } else {
                        this.collectMenuRetries = 0;
                        this.closeScreen(arg);
                        this.abort("H\u1ebft th\u1eddi gian ch\u1edd m\u1edf 'Your Orders' sau 3 l\u1ea7n th\u1eed l\u1ea1i.");
                     }
                  }
                  break;
               case CLICK_COMPLETED_ORDER:
                  if (arg.field_1755 instanceof class_476 var36) {
                     class_1703 var44 = var36.method_17577();
                     int var47 = this.findCompletedOrderSlot(arg, this.currentTargetItem);
                     if (var47 >= 0) {
                        class_1799 var50 = ((class_1735)var44.field_7761.get(var47)).method_7677();
                        AutoBuildFarm.chat(
                           "\u2714 B\u1ea5m 1 l\u1ea7n v\u00e0o \u0111\u01a1n h\u00e0ng " + var50.method_7964().getString() + " (slot " + var47 + ")"
                        );
                        GuiAutomator.getInstance().clickSlot(var47, 250L);
                        this.transition(RestockController.BotState.WAIT_EDIT_ORDER);
                     } else if (var2 > 3000L) {
                        AutoBuildFarm.chat(
                           "Kh\u00f4ng t\u00ecm th\u1ea5y \u0111\u01a1n h\u00e0ng n\u00e0o c\u00f3 th\u1ec3 nh\u1eadn cho "
                              + getItemDisplayName(this.currentTargetItem)
                              + " trong 'Your Orders' sau 3s ch\u1edd."
                        );
                        if (this.currentTargetItem != null) {
                           this.restockFailedUntil.put(this.currentTargetItem, System.currentTimeMillis() + 60000L);
                        }

                        this.closeScreen(arg);
                        if (!this.restockQueue.isEmpty() && this.restockQueue.peek() == this.currentTargetItem) {
                           this.restockQueue.poll();
                        }

                        this.transition(RestockController.BotState.IDLE);
                        this.processNextInQueue();
                     }
                  } else if (var2 > 3000L) {
                     this.closeScreen(arg);
                     this.abort("Kh\u00f4ng \u1edf m\u00e0n h\u00ecnh 'Your Orders'.");
                  }
                  break;
               case WAIT_EDIT_ORDER:
                  if (arg.field_1755 instanceof class_476 var25) {
                     String var35 = var25.method_25440().getString().toLowerCase(Locale.ROOT);
                     if (isEditOrderTitle(var35)) {
                        this.transition(RestockController.BotState.CLICK_COLLECT);
                        break;
                     }
                  }

                  if (var2 > 8000L) {
                     this.abort("H\u1ebft th\u1eddi gian ch\u1edd m\u1edf 'Edit Order'.");
                  }
                  break;
               case CLICK_COLLECT:
                  int var24 = this.findSlotByKeywords(arg, "collect", "claim", "nhan", "nh\u1eadn", "l\u1ea5y");
                  if (var24 < 0 && arg.field_1755 instanceof class_476 var33) {
                     class_1703 var43 = var33.method_17577();
                     int var46 = var43.field_7761.size() - 36;

                     for (int var49 = 0; var49 < var46; var49++) {
                        class_1799 var51 = ((class_1735)var43.field_7761.get(var49)).method_7677();
                        if (var51.method_31574(class_1802.field_8106)) {
                           var24 = var49;
                           break;
                        }
                     }
                  }

                  if (var24 < 0) {
                     var24 = 16;
                  }

                  AutoBuildFarm.chat("\u2714 B\u1ea5m Collect (r\u01b0\u01a1ng slot " + var24 + ") \u0111\u1ec3 nh\u1eadn item!");
                  GuiAutomator.getInstance().clickSlot(var24, 250L);
                  this.transition(RestockController.BotState.WAIT_AFTER_COLLECT);
                  break;
               case WAIT_AFTER_COLLECT:
                  if (arg.field_1755 instanceof class_476 var23) {
                     String var32 = var23.method_25440().getString().toLowerCase(Locale.ROOT);
                     if (isCollectItemsTitle(var32)) {
                        this.transition(RestockController.BotState.TAKE_COLLECTED_ITEMS);
                        break;
                     }
                  }

                  if (var2 > 4000L && GuiAutomator.getInstance().isIdle()) {
                     DebugLog.line("COLLECT| kh\u00f4ng th\u1ea5y m\u00e0n 'Collect Items' -> ki\u1ec3m tra t\u00fai");
                     this.closeScreen(arg);
                     this.transition(RestockController.BotState.WAIT_TAKE_ITEMS);
                  }
                  break;
               case TAKE_COLLECTED_ITEMS:
                  if (!(arg.field_1755 instanceof class_476 var30)) {
                     this.transition(RestockController.BotState.WAIT_TAKE_ITEMS);
                     return;
                  }

                  class_1703 var41 = var30.method_17577();
                  int var45 = var41.field_7761.size() - 36;
                  int var48 = arg.field_1724 != null && this.currentTargetItem != null ? InventoryHelper.count(arg.field_1724, this.currentTargetItem) : 0;
                  int var9 = getTargetQuota(this.currentTargetItem);
                  int var10 = FarmBuildController.INSTANCE.countRemainingNeeded(this.currentTargetItem);
                  int var11 = this.currentTargetItem == class_1802.field_20412 ? var9 : (var10 > 0 && var10 < var9 ? var10 : var9);
                  int var12 = Math.max(0, var11 - var48);
                  int var13 = getAvailableCapacity(arg, this.currentTargetItem);
                  int var14 = Math.min(var12, var13);
                  DebugLog.line(
                     "COLLECT| "
                        + getItemDisplayName(this.currentTargetItem)
                        + " (hi\u1ec7n c\u00f3: "
                        + var48
                        + "/"
                        + var9
                        + ", th\u1ebf gi\u1edbi c\u1ea7n: "
                        + var10
                        + ", c\u1ea7n th\u00eam: "
                        + var12
                        + ", s\u1ee9c ch\u1ee9a t\u00fai: "
                        + var13
                        + ")"
                  );
                  if (var14 <= 0) {
                     if (var13 <= 0) {
                        AutoBuildFarm.chat(
                           "T\u00fai \u0111\u1ed3 \u0111\u00e3 \u0111\u1ea7y (kh\u00f4ng c\u00f2n \u00f4 tr\u1ed1ng an to\u00e0n), d\u1eebng nh\u1eadn "
                              + getItemDisplayName(this.currentTargetItem)
                              + " \u0111\u1ec3 tr\u00e1nh void \u0111\u1ed3!"
                        );
                     }

                     GuiAutomator.getInstance().queueAction(() -> this.closeScreen(arg), 300L);
                     this.transition(RestockController.BotState.WAIT_TAKE_ITEMS);
                     return;
                  }

                  int var15 = 0;
                  int var16 = 0;
                  long var17 = 120L;

                  for (int var19 = 0; var19 < var45 && var14 > 0; var19++) {
                     class_1799 var20 = ((class_1735)var41.field_7761.get(var19)).method_7677();
                     if (!var20.method_7960()
                        && !var20.method_7964().getString().isBlank()
                        && this.isOrderOfMine(var20)
                        && (this.currentTargetItem == null || isSameItem(var20, this.currentTargetItem))) {
                        int var21 = var20.method_7947();
                        GuiAutomator.getInstance().shiftClickSlot(var19, var17);
                        var15++;
                        var16 += var21;
                        var14 -= var21;
                        DebugLog.line(
                           "COLLECT| l\u1ea5y slot "
                              + var19
                              + " = "
                              + var20.method_7964().getString()
                              + " x"
                              + var21
                              + " (c\u00f2n \u0111\u01b0\u1ee3c ph\u00e9p l\u1ea5y: "
                              + Math.max(0, var14)
                              + ")"
                        );
                     }
                  }

                  if (var15 > 0) {
                     AutoBuildFarm.chat(
                        "\u2714 \u0110\u00e3 l\u1ea5y an to\u00e0n "
                           + var16
                           + " "
                           + getItemDisplayName(this.currentTargetItem)
                           + " ("
                           + var15
                           + " stack, t\u1ed5ng hi\u1ec7n c\u00f3: "
                           + (var48 + var16)
                           + "/"
                           + var9
                           + ")!"
                     );
                     this.takeItemRetries = 0;
                  } else {
                     this.takeItemRetries++;
                     AutoBuildFarm.chat(
                        "M\u00e0n Collect Items kh\u00f4ng c\u00f3 "
                           + getItemDisplayName(this.currentTargetItem)
                           + " ho\u1eb7c t\u00fai \u0111\u1ed3 \u0111\u00e3 \u0111\u1ea7y (l\u1ea7n th\u1eed "
                           + this.takeItemRetries
                           + "/3)."
                     );
                     if (this.takeItemRetries >= 3 && this.currentTargetItem != null) {
                        this.restockFailedUntil.put(this.currentTargetItem, System.currentTimeMillis() + 30000L);
                     }
                  }

                  long var52 = var15 * var17 + 400L;
                  GuiAutomator.getInstance().queueAction(() -> this.closeScreen(arg), var52);
                  this.transition(RestockController.BotState.WAIT_TAKE_ITEMS);
                  break;
               case WAIT_TAKE_ITEMS:
                  if (var2 > 500L && GuiAutomator.getInstance().isIdle()) {
                     int var4 = arg.field_1724 != null && this.currentTargetItem != null ? InventoryHelper.count(arg.field_1724, this.currentTargetItem) : 0;
                     int var5 = getTargetQuota(this.currentTargetItem);
                     int var6 = FarmBuildController.INSTANCE.countRemainingNeeded(this.currentTargetItem);
                     int var7 = getAvailableCapacity(arg, this.currentTargetItem);
                     boolean var8;
                     if (this.currentTargetItem == class_1802.field_20412) {
                        var8 = var4 >= 128 || var7 <= 0 || this.takeItemRetries >= 3;
                     } else {
                        var8 = isQuotaSatisfied(this.currentTargetItem, var4) || var6 > 0 && var4 >= var6 || var7 <= 0 || this.takeItemRetries >= 3;
                     }

                     if (!var8) {
                        AutoBuildFarm.chat(
                           getItemDisplayName(this.currentTargetItem)
                              + " hi\u1ec7n c\u00f3 "
                              + var4
                              + "/"
                              + var5
                              + " -> Ti\u1ebfp t\u1ee5c l\u1ea5y trong order\u2026"
                        );
                        this.transition(RestockController.BotState.OPEN_ORDERS_TO_COLLECT);
                     } else {
                        if (!this.restockQueue.isEmpty() && this.restockQueue.peek() == this.currentTargetItem) {
                           this.restockQueue.poll();
                        }

                        this.transition(RestockController.BotState.FINISHING);
                     }
                  }
                  break;
               case RESET_INVENTORY_OPEN:
                  if (arg.field_1724 != null) {
                     if (arg.field_1755 != null) {
                        this.closeScreen(arg);
                     }

                     arg.method_1507(new class_490(arg.field_1724));
                  }

                  this.transition(RestockController.BotState.RESET_INVENTORY_CLOSE);
                  break;
               case RESET_INVENTORY_CLOSE:
                  if (var2 >= 300L) {
                     this.closeScreen(arg);
                     this.transition(RestockController.BotState.OPEN_ORDERS_TO_COLLECT);
                  }
                  break;
               case FINISHING:
                  if (var2 >= 300L) {
                     this.processNextInQueue();
                  }
            }
         } else {
            this.abort("M\u1ea5t k\u1ebft n\u1ed1i ng\u01b0\u1eddi ch\u01a1i.");
         }
      }
   }

   private void abort(String string) {
      AutoBuildFarm.chat("D\u1eebng t\u1ef1 \u0111\u1ed9ng nh\u1eadn h\u00e0ng: " + string);
      GuiAutomator.getInstance().clearQueue();
      class_310 var2 = class_310.method_1551();
      this.closeScreen(var2);
      if (this.currentTargetItem != null) {
         this.restockFailedUntil.put(this.currentTargetItem, System.currentTimeMillis() + 30000L);
      }

      this.restockQueue.clear();
      this.state = RestockController.BotState.IDLE;
      this.currentTargetItem = null;
      if (this.onRestockComplete != null) {
         Runnable var3 = this.onRestockComplete;
         this.onRestockComplete = null;
         var3.run();
      }
   }

   private void closeScreen(class_310 arg) {
      if (arg != null) {
         if (arg.field_1724 != null) {
            arg.field_1724.method_7346();
         }

         if (arg.field_1755 != null) {
            arg.method_1507(null);
         }
      }
   }

   private int findYourOrdersSlot(class_310 arg) {
      if (!(arg.field_1755 instanceof class_476 var2)) {
         return -1;
      } else {
         class_1703 var8 = var2.method_17577();
         int var4 = var8.field_7761.size() - 36;

         for (int var5 = 0; var5 < var4; var5++) {
            class_1799 var6 = ((class_1735)var8.field_7761.get(var5)).method_7677();
            if (!var6.method_7960()) {
               String var7 = var6.method_7964().getString().toLowerCase(Locale.ROOT);
               if (isYourOrdersTitle(var7)
                  || var7.contains("your orders")
                  || var7.equals("your orders")
                  || var7.contains("don hang")
                  || var7.contains("\u0111\u01a1n h\u00e0ng")) {
                  return var5;
               }

               if (var6.method_31574(class_1802.field_8106)) {
                  return var5;
               }
            }
         }

         return var4 > 51 ? 51 : -1;
      }
   }

   private int findYourOrdersSlotStrict(class_310 arg) {
      if (arg.field_1755 instanceof class_476 var2) {
         class_1703 var9 = var2.method_17577();
         int var4 = var9.field_7761.size() - 36;
         int var5 = -1;

         for (int var6 = 0; var6 < var4; var6++) {
            class_1799 var7 = ((class_1735)var9.field_7761.get(var6)).method_7677();
            if (!var7.method_7960()) {
               String var8 = var7.method_7964().getString().toLowerCase(Locale.ROOT);
               if (var5 < 0 && isYourOrdersTitle(var8)) {
                  var5 = var6;
               }
            }
         }

         return var5;
      } else {
         return -1;
      }
   }

   private int findSlotByKeywords(class_310 arg, String... strings) {
      if (!(arg.field_1755 instanceof class_476 var3)) {
         return -1;
      } else {
         class_1703 var17 = var3.method_17577();
         int var5 = var17.field_7761.size() - 36;

         for (int var6 = 0; var6 < var5; var6++) {
            class_1799 var7 = ((class_1735)var17.field_7761.get(var6)).method_7677();
            if (!var7.method_7960()) {
               String var8 = var7.method_7964().getString().toLowerCase(Locale.ROOT);

               for (String var12 : strings) {
                  if (var8.contains(var12.toLowerCase(Locale.ROOT))) {
                     return var6;
                  }
               }

               class_9290 var18 = (class_9290)var7.method_58694(class_9334.field_49632);
               if (var18 != null) {
                  for (class_2561 var20 : var18.comp_2400()) {
                     String var21 = var20.getString().toLowerCase(Locale.ROOT);

                     for (String var16 : strings) {
                        if (var21.contains(var16.toLowerCase(Locale.ROOT))) {
                           return var6;
                        }
                     }
                  }
               }
            }
         }

         return -1;
      }
   }

   private boolean isOrderOfMine(class_1799 arg) {
      if (arg != null && !arg.method_7960()) {
         class_2960 var2 = class_7923.field_41178.method_10221(arg.method_7909());
         String var3 = var2 != null ? var2.toString().toLowerCase(Locale.ROOT) : "";
         if (!var3.contains("hopper")
            && !var3.contains("arrow")
            && !var3.contains("barrier")
            && !var3.contains("sign")
            && !var3.contains("chest")
            && !var3.contains("book")) {
            if (var3.contains("stained_glass_pane")) {
               class_9290 var4 = (class_9290)arg.method_58694(class_9334.field_49632);
               if (var4 == null || var4.comp_2400().isEmpty()) {
                  return false;
               }
            }

            return true;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private int findCompletedOrderSlot(class_310 arg, class_1792 arg2) {
      if (!(arg.field_1755 instanceof class_476 var3)) {
         return -1;
      } else {
         class_1703 var11 = var3.method_17577();
         int var5 = var11.field_7761.size() - 36;
         ArrayList var6 = new ArrayList();

         for (int var7 = 0; var7 < var5; var7++) {
            class_1799 var8 = ((class_1735)var11.field_7761.get(var7)).method_7677();
            if (!var8.method_7960() && this.isOrderOfMine(var8)) {
               RestockController.OrderProgressInfo var9 = getOrderProgressInfo(var8);
               String var10 = var8.method_7964().getString();
               if (var9.isCollectable) {
                  var6.add(new RestockController.CollectCandidate(var7, var8, var9, var10));
                  DebugLog.line(
                     "COLLECT| ph\u00e1t hi\u1ec7n \u0111\u01a1n c\u00f3 th\u1ec3 nh\u1eadn \u1edf slot "
                        + var7
                        + ": "
                        + var10
                        + " (got="
                        + var9.got
                        + ", need="
                        + var9.need
                        + ")"
                  );
               }
            }
         }

         if (var6.isEmpty()) {
            return -1;
         }

         if (arg2 != null) {
            for (RestockController.CollectCandidate var15 : var6) {
               if (isSameItem(var15.stack, arg2)) {
                  return var15.slot;
               }
            }

            return -1;
         } else {
            for (RestockController.CollectCandidate var14 : var6) {
               for (RestockController.QuotaEntry var17 : TARGET_ITEMS) {
                  if (isSameItem(var14.stack, var17.item())) {
                     return var14.slot;
                  }
               }
            }

            return -1;
         }
      }
   }

   public static boolean isSameItem(class_1799 arg, class_1792 arg2) {
      if (arg == null || arg.method_7960() || arg2 == null) {
         return false;
      }

      if (arg.method_31574(arg2)) {
         return true;
      }

      class_2960 var2 = class_7923.field_41178.method_10221(arg.method_7909());
      class_2960 var3 = class_7923.field_41178.method_10221(arg2);
      if (var3.equals(var2)) {
         return true;
      }

      if (isStainedGlassItem(arg2) && isStainedGlassItem(arg.method_7909())) {
         return true;
      }

      String var4 = arg.method_7964().getString();
      String var5 = arg2.method_63680().getString();
      if (ItemStackUtil.itemsMatch(var4, var5)) {
         return true;
      }

      for (RestockController.QuotaEntry var7 : TARGET_ITEMS) {
         if (var7.item() == arg2 && ItemStackUtil.itemsMatch(var4, var7.displayName())) {
            return true;
         }
      }

      if (isStainedGlassItem(arg2)) {
         String var8 = var4.toLowerCase(Locale.ROOT);
         if (var8.contains("stained glass") || var8.contains("kinh") || var8.contains("k\u00ednh")) {
            return true;
         }
      }

      return false;
   }

   public static boolean isStainedGlassItem(class_1792 arg) {
      if (arg == null) {
         return false;
      }

      class_2960 var1 = class_7923.field_41178.method_10221(arg);
      return var1 == null ? false : var1.method_12832().contains("stained_glass");
   }

   public static RestockController.OrderProgressInfo getOrderProgressInfo(class_1799 arg) {
      if (arg != null && !arg.method_7960()) {
         String var1 = arg.method_7964().getString().toLowerCase(Locale.ROOT);
         boolean var2 = var1.contains("completed")
            || var1.contains("ready to collect")
            || var1.contains("click to collect")
            || var1.contains("ho\u00e0n t\u1ea5t")
            || var1.contains("ho\u00e0n th\u00e0nh")
            || var1.contains("nh\u1eadn");
         class_9290 var3 = (class_9290)arg.method_58694(class_9334.field_49632);
         boolean var4 = false;
         boolean var5 = false;
         double var6 = 0.0;
         double var8 = 0.0;
         if (var3 != null) {
            for (class_2561 var11 : var3.comp_2400()) {
               String var12 = var11.getString().toLowerCase(Locale.ROOT);
               if (var12.contains("cancel") || var12.contains("hu\u1ef7") || var12.contains("h\u1ee7y")) {
                  var4 = true;
               }

               if (var12.contains("order completed")
                  || var12.contains("ready to collect")
                  || var12.contains("click to collect")
                  || var12.contains("click to claim")
                  || var12.contains("items to collect")
                  || var12.contains("collect items")
                  || var12.contains("claim items")
                  || var12.contains("ho\u00e0n t\u1ea5t")
                  || var12.contains("nh\u1eadn")
                  || var12.contains("claim")) {
                  var5 = true;
               }

               Matcher var13 = ORDER_PROGRESS.matcher(var11.getString());
               if (var13.find()) {
                  var6 = ItemStackUtil.parsePriceOrAmount(var13.group(1));
                  var8 = ItemStackUtil.parsePriceOrAmount(var13.group(2));
               }
            }
         }

         boolean var14 = var8 > 0.0 && var6 >= var8 || var2 || var5;
         boolean var15 = var14 || var4 && (var6 > 0.0 || var5 || var2 || var8 == 0.0) || var6 > 0.0 || var5 || var2;
         return new RestockController.OrderProgressInfo(var15, var4, var14, var6, var8);
      } else {
         return new RestockController.OrderProgressInfo(false, false, false, 0.0, 0.0);
      }
   }

   public static int getTargetQuota(class_1792 arg) {
      if (arg == null) {
         return 0;
      }

      for (RestockController.QuotaEntry var2 : TARGET_ITEMS) {
         if (var2.item() == arg) {
            return var2.targetQuota();
         }
      }

      return 64;
   }

   public static int countFreeInventorySlots(class_310 arg) {
      if (arg != null && arg.field_1724 != null) {
         class_1661 var1 = arg.field_1724.method_31548();
         int var2 = 0;

         for (int var3 = 0; var3 < 36; var3++) {
            if (var1.method_5438(var3).method_7960()) {
               var2++;
            }
         }

         return var2;
      } else {
         return 0;
      }
   }

   public static int getAvailableCapacity(class_310 arg, class_1792 arg2) {
      if (arg != null && arg.field_1724 != null && arg2 != null) {
         class_1661 var2 = arg.field_1724.method_31548();
         int var3 = arg2.method_7882();
         int var4 = 0;
         int var5 = 0;

         for (int var6 = 0; var6 < 36; var6++) {
            class_1799 var7 = var2.method_5438(var6);
            if (var7.method_7960()) {
               var5++;
            } else if (isSameItem(var7, arg2) && var7.method_7947() < var3) {
               var4 += var3 - var7.method_7947();
            }
         }

         int var8 = Math.max(0, var5 - 1);
         return var4 + var8 * var3;
      } else {
         return 0;
      }
   }

   public static boolean isQuotaSatisfied(class_1792 arg, int i) {
      if (arg == null) {
         return true;
      } else if (arg == class_1802.field_20412) {
         return i >= 128;
      } else {
         int var2 = FarmBuildController.INSTANCE.countRemainingNeeded(arg);
         if (var2 == 0) {
            return true;
         } else if (var2 > 0 && i >= var2) {
            return true;
         } else {
            int var3 = getTargetQuota(arg);
            int var4 = var2 > 0 && var2 < var3 ? var2 : var3;
            if (i >= var4) {
               return true;
            } else if (arg == class_1802.field_8705 || arg == class_1802.field_8187) {
               return i >= Math.min(4, var4);
            } else if (arg == class_1802.field_8410 || isStainedGlassItem(arg)) {
               return i >= Math.min(32, var4);
            } else {
               return i >= 128 ? true : i >= var4 - 32 && i >= 32;
            }
         }
      }
   }

   public static String getItemDisplayName(class_1792 arg) {
      if (arg == null) {
         return "V\u1eadt ph\u1ea9m";
      }

      for (RestockController.QuotaEntry var2 : TARGET_ITEMS) {
         if (var2.item() == arg) {
            return var2.displayName();
         }
      }

      return arg.method_63680().getString();
   }

   public enum BotState {
      IDLE,
      WAIT_GROUND,
      OPEN_ORDERS_TO_COLLECT,
      WAIT_COLLECT_ORDER_MENU,
      CLICK_COLLECT_YOUR_ORDERS,
      WAIT_COLLECT_YOUR_ORDERS,
      CLICK_COMPLETED_ORDER,
      WAIT_EDIT_ORDER,
      CLICK_COLLECT,
      WAIT_AFTER_COLLECT,
      TAKE_COLLECTED_ITEMS,
      WAIT_TAKE_ITEMS,
      RESET_INVENTORY_OPEN,
      RESET_INVENTORY_CLOSE,
      FINISHING;
   }

   private record CollectCandidate(int slot, class_1799 stack, RestockController.OrderProgressInfo info, String itemName) {
   }

   private record OrderProgressInfo(boolean isCollectable, boolean isCancelled, boolean isFull, double got, double need) {
   }

   public record QuotaEntry(class_1792 item, int targetQuota, String displayName) {
   }
}
