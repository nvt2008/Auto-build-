package com.autobuildfarm.order;

import java.util.ArrayDeque;
import java.util.Deque;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;

@Environment(EnvType.CLIENT)
public final class GuiAutomator {
   private static final GuiAutomator INSTANCE = new GuiAutomator();
   private final Deque<GuiAutomator.PendingAction> actionQueue = new ArrayDeque<>();
   private long nextActionTime = 0L;

   public static GuiAutomator getInstance() {
      return INSTANCE;
   }

   public void queueSlotClick(int i, int j, class_1713 arg, long l) {
      this.actionQueue.add(new GuiAutomator.PendingAction(l, () -> {
         class_310 var3 = class_310.method_1551();
         if (var3.field_1724 != null && var3.field_1724.field_7512 != null && var3.field_1761 != null) {
            System.out.println("[AutoBuildFarm GuiAutomator] Click slot " + i + " (syncId=" + var3.field_1724.field_7512.field_7763 + ")");
            var3.field_1761.method_2906(var3.field_1724.field_7512.field_7763, i, j, arg, var3.field_1724);
         }
      }));
   }

   public void clickSlot(int i) {
      this.clickSlot(i, 250L);
   }

   public void clickSlot(int i, long l) {
      this.queueSlotClick(i, 0, class_1713.field_7790, l);
   }

   public void shiftClickSlot(int i, long l) {
      this.queueSlotClick(i, 0, class_1713.field_7794, l);
   }

   public void shiftClickIfBucket(int i, long l) {
      this.actionQueue.add(new GuiAutomator.PendingAction(l, () -> {
         class_310 var1 = class_310.method_1551();
         if (var1.field_1724 != null && var1.field_1724.field_7512 != null && var1.field_1761 != null) {
            class_1703 var2 = var1.field_1724.field_7512;
            if (var2 != var1.field_1724.field_7498 && i >= 0 && i < var2.field_7761.size()) {
               class_1799 var3 = ((class_1735)var2.field_7761.get(i)).method_7677();
               if (!var3.method_7960() && var3.method_31574(class_1802.field_8550)) {
                  var1.field_1761.method_2906(var2.field_7763, i, 0, class_1713.field_7794, var1.field_1724);
               }
            }
         }
      }));
   }

   public void rightClickSlot(int i, long l) {
      this.queueSlotClick(i, 1, class_1713.field_7790, l);
   }

   public void pickupAllSlot(int i, long l) {
      this.queueSlotClick(i, 0, class_1713.field_7793, l);
   }

   public void queueCommand(String string, long l) {
      this.actionQueue.add(new GuiAutomator.PendingAction(l, () -> {
         class_310 var4 = class_310.method_1551();
         if (var4.field_1724 != null && var4.field_1724.field_3944 != null) {
            if (closeOpenContainer(var4)) {
               this.actionQueue.addFirst(new GuiAutomator.PendingAction(l, () -> sendCommand(string)));
            } else {
               sendCommand(string);
            }
         }
      }));
   }

   public void queueCloseContainer(long l) {
      this.actionQueue.add(new GuiAutomator.PendingAction(l, () -> {
         class_310 var0 = class_310.method_1551();
         if (var0 != null) {
            closeOpenContainer(var0);
         }
      }));
   }

   public void sendCommandNow(String string) {
      class_310 var2 = class_310.method_1551();
      if (var2 != null && var2.field_1724 != null) {
         long var3 = 500L;
         if (closeOpenContainer(var2)) {
            this.actionQueue.addFirst(new GuiAutomator.PendingAction(var3, () -> sendCommand(string)));
         } else {
            sendCommand(string);
         }
      }
   }

   private static void sendCommand(String string) {
      class_310 var1 = class_310.method_1551();
      if (var1.field_1724 != null && var1.field_1724.field_3944 != null) {
         String var2 = string.trim();
         if (var2.startsWith("/")) {
            var2 = var2.substring(1);
         }

         System.out.println("[AutoBuildFarm GuiAutomator] Sending chat command: /" + var2);
         var1.field_1724.field_3944.method_45730(var2);
      }
   }

   public static boolean closeOpenContainer(class_310 arg) {
      if (arg.field_1724 == null) {
         return false;
      } else {
         class_1703 var1 = arg.field_1724.field_7512;
         if (var1 != null && var1 != arg.field_1724.field_7498) {
            arg.field_1724.method_7346();
            System.out.println("[AutoBuildFarm GuiAutomator] \u0110\u00f3ng container \u0111ang m\u1edf (closeHandledScreen)");
            return true;
         } else {
            return false;
         }
      }
   }

   public void queueAction(Runnable runnable, long l) {
      this.actionQueue.add(new GuiAutomator.PendingAction(l, runnable));
   }

   public void clearQueue() {
      this.actionQueue.clear();
      this.nextActionTime = 0L;
   }

   public void tick() {
      if (!this.actionQueue.isEmpty()) {
         long var1 = System.currentTimeMillis();
         if (var1 >= this.nextActionTime) {
            GuiAutomator.PendingAction var3 = this.actionQueue.poll();
            if (var3 != null) {
               try {
                  var3.run();
               } catch (Exception var5) {
                  System.err.println("[AutoBuildFarm GuiAutomator] Error: " + var5.getMessage());
               }

               this.nextActionTime = var1 + var3.delayMs;
            }
         }
      }
   }

   public boolean isIdle() {
      return this.actionQueue.isEmpty() && System.currentTimeMillis() >= this.nextActionTime;
   }

   public int queueSize() {
      return this.actionQueue.size();
   }

   private static class PendingAction {
      final long delayMs;
      private final Runnable runnable;

      PendingAction(long l, Runnable runnable) {
         this.delayMs = l;
         this.runnable = runnable;
      }

      void run() {
         this.runnable.run();
      }
   }
}
