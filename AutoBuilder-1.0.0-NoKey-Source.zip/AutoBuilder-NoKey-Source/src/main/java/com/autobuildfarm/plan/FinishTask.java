package com.autobuildfarm.plan;

import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1922;
import net.minecraft.class_2286;
import net.minecraft.class_2338;
import net.minecraft.class_2397;
import net.minecraft.class_2462;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2747;
import net.minecraft.class_3610;
import net.minecraft.class_3612;

public final class FinishTask {
   private final FinishTask.Type type;
   private final class_2338 pos;
   private final class_2680 desired;

   public FinishTask(FinishTask.Type type, class_2338 arg, class_2680 arg2) {
      this.type = type;
      this.pos = arg;
      this.desired = arg2;
   }

   public FinishTask.Type type() {
      return this.type;
   }

   public class_2338 pos() {
      return this.pos;
   }

   public class_2680 desired() {
      return this.desired;
   }

   public boolean isFluid() {
      return this.type == FinishTask.Type.WATERLOG || this.type == FinishTask.Type.WATER_SOURCE || this.type == FinishTask.Type.LAVA_SOURCE;
   }

   public class_1792 requiredItem() {
      return switch (this.type) {
         case WATERLOG, WATER_SOURCE -> class_1802.field_8705;
         case LAVA_SOURCE -> class_1802.field_8187;
         default -> null;
      };
   }

   public boolean satisfied(class_1922 arg) {
      if (arg == null) {
         return false;
      }

      class_2680 var2 = arg.method_8320(this.pos);

      return switch (this.type) {
         case WATERLOG -> (
               var2.method_26204() == this.desired.method_26204()
                  || var2.method_26204() instanceof class_2397 && this.desired.method_26204() instanceof class_2397
            )
            && var2.method_28498(class_2741.field_12508)
            && var2.method_11654(class_2741.field_12508);
         case WATER_SOURCE -> this.isStill(var2, true);
         case LAVA_SOURCE -> this.isStill(var2, false);
         case REPEATER_DELAY -> var2.method_26204() instanceof class_2462
            && var2.method_28498(class_2741.field_12494)
            && ((Integer)var2.method_11654(class_2741.field_12494)).equals(this.desired.method_11654(class_2741.field_12494));
         case COMPARATOR_MODE -> var2.method_26204() instanceof class_2286
            && var2.method_28498(class_2741.field_12534)
            && var2.method_11654(class_2741.field_12534) == this.desired.method_11654(class_2741.field_12534);
      };
   }

   public boolean ready(class_1922 arg) {
      if (arg == null) {
         return false;
      }

      class_2680 var2 = arg.method_8320(this.pos);

      return switch (this.type) {
         case WATERLOG -> (
               var2.method_26204() == this.desired.method_26204()
                  || var2.method_26204() instanceof class_2397 && this.desired.method_26204() instanceof class_2397
            )
            && var2.method_28498(class_2741.field_12508)
            && !var2.method_11654(class_2741.field_12508);
         case WATER_SOURCE, LAVA_SOURCE -> var2.method_26215()
            || var2.method_45474()
            || !var2.method_26227().method_15769() && !var2.method_26227().method_15771();
         case REPEATER_DELAY -> var2.method_26204() instanceof class_2462;
         case COMPARATOR_MODE -> var2.method_26204() instanceof class_2286;
      };
   }

   public int remainingClicks(class_1922 arg) {
      class_2680 var2 = arg.method_8320(this.pos);
      if (this.type == FinishTask.Type.REPEATER_DELAY && var2.method_26204() instanceof class_2462) {
         int var5 = (Integer)this.desired.method_11654(class_2741.field_12494);
         int var6 = (Integer)var2.method_11654(class_2741.field_12494);
         return Math.floorMod(var5 - var6, 4);
      } else if (this.type == FinishTask.Type.COMPARATOR_MODE && var2.method_26204() instanceof class_2286) {
         class_2747 var3 = (class_2747)this.desired.method_11654(class_2741.field_12534);
         class_2747 var4 = (class_2747)var2.method_11654(class_2741.field_12534);
         return var3 == var4 ? 0 : 1;
      } else {
         return 0;
      }
   }

   private boolean isStill(class_2680 arg, boolean bl) {
      class_3610 var3 = arg.method_26227();
      if (!var3.method_15771()) {
         return false;
      } else {
         return bl ? var3.method_33659(class_3612.field_15910) : var3.method_33659(class_3612.field_15908);
      }
   }

   @Override
   public boolean equals(Object object) {
      return object instanceof FinishTask var2 && var2.type == this.type && var2.pos.equals(this.pos);
   }

   @Override
   public int hashCode() {
      return this.type.hashCode() * 31 + this.pos.hashCode();
   }

   @Override
   public String toString() {
      return this.type + "@" + this.pos.method_23854();
   }

   public enum Type {
      WATERLOG,
      WATER_SOURCE,
      LAVA_SOURCE,
      REPEATER_DELAY,
      COMPARATOR_MODE;
   }
}
