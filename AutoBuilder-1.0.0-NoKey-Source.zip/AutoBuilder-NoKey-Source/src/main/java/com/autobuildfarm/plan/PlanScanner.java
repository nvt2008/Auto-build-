package com.autobuildfarm.plan;

import baritone.api.schematic.IStaticSchematic;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_2246;
import net.minecraft.class_2286;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_2462;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2747;
import net.minecraft.class_3610;
import net.minecraft.class_3612;

public final class PlanScanner {
   private PlanScanner() {
   }

   public static List<FinishTask> scan(IStaticSchematic iStaticSchematic, class_2382 arg) {
      ArrayList var2 = new ArrayList();
      ArrayList var3 = new ArrayList();
      ArrayList var4 = new ArrayList();
      ArrayList var5 = new ArrayList();

      for (int var6 = 0; var6 < iStaticSchematic.widthX(); var6++) {
         for (int var7 = 0; var7 < iStaticSchematic.heightY(); var7++) {
            for (int var8 = 0; var8 < iStaticSchematic.lengthZ(); var8++) {
               class_2680 var9 = iStaticSchematic.getDirect(var6, var7, var8);
               if (var9 != null
                  && !var9.method_26215()
                  && var9.method_26204() != class_2246.field_10243
                  && var9.method_26204() != class_2246.field_10543
                  && var9.method_26204() != class_2246.field_10369) {
                  class_2338 var10 = new class_2338(arg.method_10263() + var6, arg.method_10264() + var7, arg.method_10260() + var8);
                  classify(var9, var10, var2, var3, var4, var5);
               }
            }
         }
      }

      Comparator var11 = Comparator.comparingInt(finishTask -> finishTask.pos().method_10264());
      var3.sort(var11);
      var4.sort(var11);
      ArrayList var12 = new ArrayList(var2.size() + var3.size() + var4.size() + var5.size());
      var12.addAll(var2);
      var12.addAll(var3);
      var12.addAll(var5);
      var12.addAll(var4);
      return var12;
   }

   private static void classify(class_2680 arg, class_2338 arg2, List<FinishTask> list, List<FinishTask> list2, List<FinishTask> list3, List<FinishTask> list4) {
      class_3610 var6 = arg.method_26227();
      if (arg.method_28498(class_2741.field_12508) && (Boolean)arg.method_11654(class_2741.field_12508)) {
         list.add(new FinishTask(FinishTask.Type.WATERLOG, arg2, arg));
      } else if (arg.method_26204() == class_2246.field_10164 || var6.method_15772() == class_3612.field_15908 || var6.method_15772() == class_3612.field_15907
         )
       {
         list3.add(new FinishTask(FinishTask.Type.LAVA_SOURCE, arg2, arg));
      } else if (var6.method_15771() && var6.method_33659(class_3612.field_15910)) {
         list2.add(new FinishTask(FinishTask.Type.WATER_SOURCE, arg2, arg));
      }

      if (arg.method_26204() instanceof class_2462 && arg.method_28498(class_2741.field_12494)) {
         if ((Integer)arg.method_11654(class_2741.field_12494) != 1) {
            list4.add(new FinishTask(FinishTask.Type.REPEATER_DELAY, arg2, arg));
         }
      } else if (arg.method_26204() instanceof class_2286
         && arg.method_28498(class_2741.field_12534)
         && arg.method_11654(class_2741.field_12534) != class_2747.field_12576) {
         list4.add(new FinishTask(FinishTask.Type.COMPARATOR_MODE, arg2, arg));
      }
   }

   public static String describe(List<FinishTask> list) {
      int var1 = 0;
      int var2 = 0;
      int var3 = 0;
      int var4 = 0;

      for (FinishTask var6 : list) {
         switch (var6.type()) {
            case WATERLOG:
               var1++;
               break;
            case WATER_SOURCE:
               var2++;
               break;
            case LAVA_SOURCE:
               var3++;
               break;
            default:
               var4++;
         }
      }

      return var1 + " waterlogged, " + var2 + " water source, " + var3 + " lava source, " + var4 + " repeater/comparator";
   }
}
