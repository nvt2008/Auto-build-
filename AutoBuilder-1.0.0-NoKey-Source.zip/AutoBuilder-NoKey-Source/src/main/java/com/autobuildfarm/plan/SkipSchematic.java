package com.autobuildfarm.plan;

import baritone.api.schematic.ISchematic;
import baritone.api.schematic.MaskSchematic;
import java.util.List;
import java.util.Set;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_7923;

public final class SkipSchematic extends MaskSchematic {
   public static final int NO_CEILING = Integer.MAX_VALUE;
   private final class_2382 origin;
   private final Set<class_2338> skipped;
   private final int ceilingY;

   public SkipSchematic(ISchematic iSchematic, class_2382 arg, Set<class_2338> set) {
      this(iSchematic, arg, set, Integer.MAX_VALUE);
   }

   public SkipSchematic(ISchematic iSchematic, class_2382 arg, Set<class_2338> set, int i) {
      super(iSchematic);
      this.origin = arg;
      this.skipped = set;
      this.ceilingY = i;
   }

   protected boolean partOfMask(int i, int j, int k, class_2680 arg) {
      int var5 = this.origin.method_10264() + j;
      return var5 > this.ceilingY ? false : !this.skipped.contains(new class_2338(this.origin.method_10263() + i, var5, this.origin.method_10260() + k));
   }

   public class_2680 desiredState(int i, int j, int k, class_2680 arg, List<class_2680> list) {
      try {
         class_2680 var6 = super.desiredState(i, j, k, arg, list);
         if (var6 != null) {
            class_2248 var7 = var6.method_26204();
            if (var7 == class_2246.field_10243 || var7 == class_2246.field_10543 || var7 == class_2246.field_10369) {
               return class_2246.field_10124.method_9564();
            }

            if (isIce(var7)) {
               return getGlassBlockToPlace().method_9564();
            }
         }

         return var6;
      } catch (Throwable var8) {
         return class_2246.field_10124.method_9564();
      }
   }

   public static boolean isIce(class_2248 arg) {
      return arg == null
         ? false
         : arg == class_2246.field_10225 || arg == class_2246.field_10384 || arg == class_2246.field_10295 || arg == class_2246.field_10110;
   }

   public static class_2248 getGlassBlockToPlace() {
      class_310 var0 = class_310.method_1551();
      if (var0 != null && var0.field_1724 != null) {
         class_1661 var1 = var0.field_1724.method_31548();

         for (int var2 = 0; var2 < var1.method_5439(); var2++) {
            class_1799 var3 = var1.method_5438(var2);
            if (!var3.method_7960()) {
               class_2248 var4 = class_2248.method_9503(var3.method_7909());
               if (isGlass(var4)) {
                  return var4;
               }
            }
         }
      }

      return class_2246.field_9997;
   }

   public static boolean isGlass(class_2248 arg) {
      if (arg == null) {
         return false;
      } else if (arg != class_2246.field_10033 && arg != class_2246.field_27115) {
         class_2960 var1 = class_7923.field_41175.method_10221(arg);
         return var1 != null && var1.method_12832().contains("stained_glass");
      } else {
         return true;
      }
   }
}
