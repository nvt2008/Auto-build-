package com.autobuildfarm;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import net.fabricmc.loader.api.FabricLoader;

public final class DebugLog {
   private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm:ss.SSS");
   private static Path file;
   private static boolean broken;

   private DebugLog() {
   }

   public static void begin(String string) {
      file = null;
      broken = false;

      try {
         Path var1 = path();
         Files.writeString(var1, "=== " + string + " \u2014 " + LocalTime.now().format(TIME) + " ===\n", StandardCharsets.UTF_8);
         file = var1;
      } catch (IOException | RuntimeException var2) {
         broken = true;
         AutoBuildFarm.LOG.warn("Could not open the debug log", var2);
      }
   }

   public static String location() {
      return file != null ? file.toString() : "(not writing a log)";
   }

   public static void line(String string) {
      write(string);
   }

   public static void detail(String string) {
      write("    " + string);
   }

   private static void write(String string) {
      if (!broken) {
         try {
            if (file == null) {
               file = path();
            }

            try (BufferedWriter var1 = Files.newBufferedWriter(file, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.APPEND)) {
               var1.write(LocalTime.now().format(TIME));
               var1.write(32);
               var1.write(string);
               var1.write(10);
            }
         } catch (IOException | RuntimeException var6) {
            broken = true;
            AutoBuildFarm.LOG.warn("Debug log write failed; giving up on it", var6);
         }
      }
   }

   private static Path path() {
      return FabricLoader.getInstance().getGameDir().resolve("autobuildfarm-debug.log");
   }
}
