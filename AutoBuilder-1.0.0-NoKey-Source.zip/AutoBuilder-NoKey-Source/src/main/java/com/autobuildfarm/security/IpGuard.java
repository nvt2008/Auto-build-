package com.autobuildfarm.security;

/**
 * Offline compatibility shim for the recovered no-key build.
 *
 * <p>The original implementation contacted an external IP service and a
 * remote allowlist. This replacement intentionally performs no network I/O.
 */
public final class IpGuard {
    public static final String ALLOWLIST_URL = "";
    public static final String IP_ECHO_URL = "";

    private static final String MESSAGE = "No-key build (offline)";

    private IpGuard() {
    }

    public static synchronized boolean verify() {
        return true;
    }

    public static boolean isAllowed() {
        return true;
    }

    public static String getMessage() {
        return MESSAGE;
    }

    public static String getPublicIp() {
        return null;
    }
}
