package com.autobuildfarm.security;

import java.nio.charset.StandardCharsets;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/**
 * Compatibility facade retained so the recovered classes keep their original
 * public method signatures. No key, HWID, IP allowlist, debugger check, or
 * remote request is used by this build.
 */
public final class SecurityGuard {
    public static final String SECRET_SIGNING_KEY = "";

    private SecurityGuard() {
    }

    public static boolean isRevoked() {
        return false;
    }

    public static boolean isAndroidEnvironment() {
        return false;
    }

    public static boolean isPhoneBuild() {
        return false;
    }

    public static void verify() {
        IpGuard.verify();
    }

    public static boolean isLicensed() {
        return true;
    }

    public static String getLicenseStatusMessage() {
        return "No-key build (offline)";
    }

    public static void warnIfNotLicensed() {
        // Intentionally empty: this build has no license gate.
    }

    public static String getMachineHwid() {
        return "NO_KEY_REQUIRED";
    }

    /**
     * Kept only for binary compatibility with callers compiled against the
     * original public API. It is not used for activation.
     */
    public static String computeHmac(String value, String key) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(key.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
        byte[] bytes = mac.doFinal(value.getBytes(StandardCharsets.UTF_8));
        StringBuilder result = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) {
            result.append(String.format("%02x", b));
        }
        return result.toString();
    }
}
