plugins {
    id("fabric-loom") version "1.14-SNAPSHOT"
}

group = "com.autobuildfarm"
version = "1.0.0-nokey"

base {
    archivesName.set("AutoBuilder-NoKey")
}

repositories {
    maven("https://maven.fabricmc.net/")
    maven("https://maven.meteordev.org/releases")
    maven("https://maven.meteordev.org/snapshots")
    mavenCentral()
}

dependencies {
    minecraft("com.mojang:minecraft:1.21.11")
    mappings("net.fabricmc:intermediary:1.21.11")
    modImplementation("net.fabricmc:fabric-loader:0.18.4")
    modImplementation("net.fabricmc.fabric-api:fabric-api:0.141.6+1.21.11")
    modCompileOnly("meteordevelopment:baritone:1.21.10-SNAPSHOT")
}

java {
    sourceCompatibility = JavaVersion.VERSION_21
    targetCompatibility = JavaVersion.VERSION_21
}

tasks.withType<JavaCompile>().configureEach {
    options.release.set(21)
    options.encoding = "UTF-8"
}

tasks.processResources {
    from("src/main/resources/MANIFEST.MF") {
        into("META-INF")
        rename { "MANIFEST.MF" }
    }
}
