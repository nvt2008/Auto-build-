# AutoBuilder No-Key — recovered source

This project was reconstructed from `autobuilder.jar` with Vineflower 1.12.0.
It targets Minecraft/Fabric 1.21.11 and Java 21.

## No-key changes

- Removed the runtime IP allowlist request.
- Removed key/HWID activation behavior.
- `SecurityGuard` and `IpGuard` retain compatible public methods, but always
  allow local use and perform no network request.
- All AutoBuilder gameplay classes and resources are otherwise preserved from
  the supplied JAR.

## Build

Install JDK 21, then run the included Gradle wrapper:

```bash
./gradlew build
```

The ready-to-use patched JAR supplied alongside this source was produced by
replacing only the two security classes in the original archive. This avoids
behavior changes that can be introduced by recompiling decompiled sources.

## Recovery note

Decompilation restores readable Java, not the author's exact original source:
comments, local variable names, formatting, and original build metadata cannot
be recovered byte-for-byte from a compiled JAR.
